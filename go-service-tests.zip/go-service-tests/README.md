# Game Round Service Tests
## Getting Started
If you need to install Eclipse, instructions will be found [here](https://techwiki/gaming/index.php?title=Testing_Microservices)

Once Eclipse is installed you will need to configure it to work with the code in this repository. Steps:
1. Create a local workspace directory and clone this repo into it
3. Launch Eclipse and when prompted, open the workspace directory
4. In *Package Explorer*, select *Import Projects...*
5. Expand the *Maven* node, select *Existing Maven Projects* and click *Next*
6. Enter the path to your local repo as the root directory and click *Finish*

Some points to note:
* With the workspace opened in Eclipse, you will be able to browse the filesystem with *Package Explorer*
* At present the tests assume that you are running a local instance of the [Game Round Service](https://gam-git-prod.lb.local/goweb/gam-gameround-svc)
* Tests are decorated with *Run All*, *Run* and *Debug* buttons, courtesy of the TestNG plugin. These may be used to run or debug tests
