package common;
import java.math.BigDecimal;
import java.math.BigInteger;

import org.testng.annotations.DataProvider;

import common.enumsconstants.ProductId;
import common.enumsconstants.ServiceErrors;
import common.enumsconstants.UsersId;

public class DataProviders {
	
	private final int regulatedGameId = 6403;
	private final int anyRegulatedGameId = -1;
	private final int cmscoreGameId = 2885;
	private final int anyCmscoreGameId = -1;
	
	@DataProvider(name = "nullZero")
	public Object[] nullZero() {
		return new Object[] {"null", "0"};
	}
	
	@DataProvider(name = "nullEmptyString")
	public Object[] nullOrEmptyString() {
		return new Object[] {"null", ""};
	}
	
	@DataProvider(name = "group1TransactionTypeProvider")
	public Object[][] getGroup1TransactionTypes() {
		return new Object[][] {
				{TransactionType.STAKE, regulatedGameId, cmscoreGameId},
				{TransactionType.FREE_SPIN_STAKE, regulatedGameId, cmscoreGameId},
				{TransactionType.GOLDEN_CHIP_STAKE, regulatedGameId, cmscoreGameId},
				{TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId},
				{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, anyRegulatedGameId, anyCmscoreGameId},
				{TransactionType.TRANSFER_TO_BINGO_BONUS_BALANCE, anyRegulatedGameId, anyCmscoreGameId},
				{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO, anyRegulatedGameId, anyCmscoreGameId},
				{TransactionType.POKER_BUY_CHIPS, anyRegulatedGameId, anyCmscoreGameId},
				{TransactionType.POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId},
				{TransactionType.POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId},
				{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER, anyRegulatedGameId, anyCmscoreGameId}
				};
	}
	
	@DataProvider(name = "group1TransactionTypeAmountProvider")
	public Object[][] getGroup1TransactionTypeAmount() {
		return new Object[][] {
			{TransactionType.STAKE, regulatedGameId, cmscoreGameId,"0.00","-1.00"},
			{TransactionType.FREE_SPIN_STAKE, regulatedGameId, cmscoreGameId,"0.00","-1.00"},
			{TransactionType.GOLDEN_CHIP_STAKE, regulatedGameId, cmscoreGameId,"0.00","-1.00"},
			{TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId,"0.00","-1.00"},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, anyRegulatedGameId, anyCmscoreGameId,"0.00","-1.00"},
			{TransactionType.TRANSFER_TO_BINGO_BONUS_BALANCE, anyRegulatedGameId, anyCmscoreGameId,"0.00","-1.00"},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO, anyRegulatedGameId, anyCmscoreGameId,"0.00","-1.00"},
			{TransactionType.POKER_BUY_CHIPS, anyRegulatedGameId, anyCmscoreGameId,"0.00","-1.00"},
			{TransactionType.POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId,"0.00","-1.00"},
			{TransactionType.POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId,"0.00","-1.00"},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER, anyRegulatedGameId, anyCmscoreGameId,"0.00","-1.00"}
		};
	}
	
	@DataProvider(name = "group3TransactionTypeAmountProvider")
	public Object[][] getGroup3TransactionTypeAmount() {
		return new Object[][] {
			{TransactionType.FREE_SPIN_RETURN, regulatedGameId, cmscoreGameId, "1", "1"},
			{TransactionType.GOLDEN_CHIP_RETURN, regulatedGameId, cmscoreGameId, "1", "1"},
			{TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "1", "1"},
			{TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_CASINO, anyRegulatedGameId, cmscoreGameId, "1", "1"},
			{TransactionType.TRANSFER_FROM_BINGO_BONUS_BALANCE, anyRegulatedGameId, cmscoreGameId, "1", "1"},
			{TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO, anyRegulatedGameId, cmscoreGameId, "1", "1"},
			{TransactionType.POKER_SELL_CHIPS, regulatedGameId, cmscoreGameId, "1", "1"},
			{TransactionType.POKER_TOURNAMENT_WIN, regulatedGameId, cmscoreGameId, "1", "1"},
			{TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_POKER, anyRegulatedGameId, cmscoreGameId, "1", "1"},
		};
	}
	
	@DataProvider(name = "group6TransactionTypeAmountProvider")
	public Object[][] getGroup6TransactionTypeAmount() {
		return new Object[][] {
			{TransactionType.VOID_STAKE, regulatedGameId, cmscoreGameId,"-0.00","-0.00"},
			{TransactionType.VOID_GAMING_STAKE, regulatedGameId, cmscoreGameId,"-0.00","-0.00"},
			{TransactionType.VOID_POKER_BUY_CHIPS, regulatedGameId, cmscoreGameId,"-0.00","-0.00"},
			{TransactionType.VOID_POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId,"-0.00","-0.00"},
			{TransactionType.VOID_POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId,"-0.00","-0.00"},
			{TransactionType.FREE_SPIN_RETURN, regulatedGameId, cmscoreGameId,"-0.00","-0.00"},
		};
	}
	
	@DataProvider(name = "externalBalanceChangeNegativeAmounts")
	public Object[][] externalBalanceChangeNegativeAmounts() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"},
			{ProductId.LIVE_CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"}
		};
	}
	
	@DataProvider(name = "handleGbtPositiveAmounts")
	public Object[][] handleGbtPositiveAmounts() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.STAKE},
			{ProductId.GAMES.getId(), TransactionType.FREE_SPIN_STAKE},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GOLDEN_CHIP_STAKE},
			{ProductId.GAMES.getId(), TransactionType.GAMING_STAKE},
			{ProductId.POKER.getId(), TransactionType.POKER_BUY_CHIPS},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_ENTRY},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_REBUY},
			{ProductId.BINGO.getId(), TransactionType.STAKE},
		};
	}
	
	@DataProvider(name = "handleGbtNegativeAmounts")
	public Object[][] handleGbtNegativeAmounts() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.RETURN, 1006, "Returns must use a positive real_amount"},
			{ProductId.GAMES.getId(), TransactionType.FREE_SPIN_RETURN, 1006, "Returns must use a positive real_amount"},
			{ProductId.GAMES.getId(), TransactionType.GOLDEN_CHIP_RETURN, 1006, "Returns must use a positive real_amount"},
			{ProductId.GAMES.getId(), TransactionType.GAMING_RETURN, 1006, "Returns must use a positive real_amount"},
			{ProductId.POKER.getId(), TransactionType.POKER_SELL_CHIPS, 1006, "Returns must use a positive real_amount"},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_WIN, 1006, "Returns must use a positive real_amount"},
			{ProductId.BINGO.getId(), TransactionType.RETURN, 1006, "Returns must use a positive real_amount"},
			{ProductId.CASINO.getId(), TransactionType.VOID_GAMING_STAKE, 1006, "Void stakes must use a positive real_amount"},
			{ProductId.GAMES.getId(), TransactionType.VOID_GAMING_STAKE, 1006, "Void stakes must use a positive real_amount"},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, 1006, "Void stakes must use a positive real_amount"},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, 1006, "Void stakes must use a positive real_amount"},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, 1006, "Void stakes must use a positive real_amount"},
			{ProductId.BINGO.getId(), TransactionType.VOID_STAKE, 1006, "Void stakes must use a positive real_amount"},
		};
	}
	
	@DataProvider(name = "externalBalanceChangePositiveAmounts")
	public Object[][] externalBalanceChangePositiveAmounts() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.VOID_GAMING_STAKE, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.CASINO.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "0.12", "0.12", "0", "0"},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "1", "1", "0", "0"},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_CASINO, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.LIVE_CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.POKER_SELL_CHIPS, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_WIN, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_POKER, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
		};
	}
	
	@DataProvider(name = "externalBalanceChangeErrors")
	public Object[][] externalBalanceChangeErrors() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.VOID_GAMING_STAKE, regulatedGameId, cmscoreGameId, "0.1", "-0.1", "0", "0", "Requested transfer amounts do not add up", 1006},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, regulatedGameId, cmscoreGameId, "0.2", "-0.1", "0", "0", "Requested transfer amounts do not add up", 1006},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "0.1", "-0.1", "0", "0", "Requested transfer amounts do not add up", 1006},
			{ProductId.GAMES.getId(), TransactionType.VOID_GAMING_STAKE, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.BINGO.getId(), TransactionType.VOID_POKER_BUY_CHIPS, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SLOTS.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SPORTSBOOK.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.GAMES.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.BINGO.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "0.12", "0.12", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SLOTS.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "1", "1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SPORTSBOOK.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_CASINO, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.GAMES.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.BINGO.getId(), TransactionType.POKER_SELL_CHIPS, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SLOTS.getId(), TransactionType.POKER_TOURNAMENT_WIN, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SPORTSBOOK.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_POKER, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.GAMES.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.BINGO.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SLOTS.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SPORTSBOOK.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.GAMES.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.BINGO.getId(), TransactionType.POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SLOTS.getId(), TransactionType.POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SPORTSBOOK.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.CASINO.getId(), TransactionType.VOID_GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Void stakes must use a positive real_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Void stakes must use a positive real_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Void stakes must use a positive real_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Void stakes must use a positive real_amount", 1006},
			{ProductId.CASINO.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "-0.12", "0.12", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "-1", "1", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.LIVE_CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.POKER_SELL_CHIPS, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_WIN, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_POKER, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.CASINO.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.2", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006},
			{ProductId.LIVE_CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006}
		};
	}
	
	@DataProvider(name = "externalBalanceChangeMissingParameters")
	public Object[][] externalBalanceChangeMissingParameters() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.VOID_GAMING_STAKE, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, "user_id", "Missing parameter: user_id", 7},
			{ProductId.CASINO.getId(), TransactionType.VOID_GAMING_STAKE, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, "token", "Missing parameter: token", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.CASINO.getId(), TransactionType.VOID_GAMING_STAKE, "action_type_id", "Invalid action_type_id", 1011},
			{ProductId.CASINO.getId(), TransactionType.GAMING_RETURN, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.POKER.getId(), TransactionType.GAMING_RETURN, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GAMING_RETURN, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_CASINO, "user_id", "Missing parameter: user_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_SELL_CHIPS, "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_WIN, "token", "Missing parameter: token", 7},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_POKER, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.CASINO.getId(), TransactionType.GAMING_RETURN, "action_type_id", "Invalid action_type_id", 1011},
			{ProductId.CASINO.getId(), TransactionType.GAMING_STAKE, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GAMING_STAKE, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.POKER.getId(), TransactionType.GAMING_STAKE, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, "user_id", "Missing parameter: user_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO,  "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_ENTRY, "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_REBUY, "token", "Missing parameter: token", 7},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.CASINO.getId(), TransactionType.GAMING_STAKE, "action_type_id", "Invalid action_type_id", 1011}
		};
	}
	
	@DataProvider(name = "handleGbtMissingParameters")
	public Object[][] handleGbtMissingParameters() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.VOID_STAKE, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_GAMING_STAKE, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, "user_id", "Missing parameter: user_id", 7},
			{ProductId.BINGO.getId(), TransactionType.VOID_STAKE, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.SLOTS.getId(), TransactionType.VOID_GAMING_STAKE, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.SPORTSBOOK.getId(), TransactionType.VOID_STAKE, "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, "token", "Missing parameter: token", 7},
			{ProductId.SPORTSBOOK.getId(), TransactionType.VOID_GAMING_STAKE, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.VOID_STAKE, "action_type_id", "Invalid action_type_id", 1011},
			{ProductId.CASINO.getId(), TransactionType.RETURN, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.GAMES.getId(), TransactionType.FREE_SPIN_RETURN, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.GAMES.getId(), TransactionType.GOLDEN_CHIP_RETURN, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.GAMES.getId(), TransactionType.GAMING_RETURN, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_SELL_CHIPS, "user_id", "Missing parameter: user_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_WIN, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.RETURN, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.SLOTS.getId(), TransactionType.GAMING_RETURN, "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.SPORTSBOOK.getId(), TransactionType.RETURN, "token", "Missing parameter: token", 7},
			{ProductId.CASINO.getId(), TransactionType.FREE_SPIN_RETURN, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.CASINO.getId(), TransactionType.GOLDEN_CHIP_RETURN, "action_type_id", "Invalid action_type_id", 1011},
			{ProductId.GAMES.getId(), TransactionType.GAMING_STAKE, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.CASINO.getId(), TransactionType.STAKE, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GOLDEN_CHIP_STAKE, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.GAMES.getId(), TransactionType.FREE_SPIN_STAKE, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_BUY_CHIPS, "user_id", "Missing parameter: user_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_ENTRY, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_REBUY,  "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.BINGO.getId(), TransactionType.STAKE, "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.GAMES.getId(), TransactionType.STAKE, "token", "Missing parameter: token", 7},
			{ProductId.SLOTS.getId(), TransactionType.STAKE, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.SPORTSBOOK.getId(), TransactionType.STAKE, "action_type_id", "Invalid action_type_id", 1011}
		};
	}
	
	@DataProvider(name = "handleStakeMissingParameters")
	public Object[][] handleStakeMissingParameters() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.STAKE, "token", "Missing parameter: token", 7},
			{ProductId.GAMES.getId(), TransactionType.FREE_SPIN_STAKE, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GOLDEN_CHIP_STAKE, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.SPORTSBOOK.getId(), TransactionType.GAMING_STAKE, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, "user_id", "Missing parameter: user_id", 7},
			{ProductId.BINGO.getId(), TransactionType.TRANSFER_TO_BINGO_BONUS_BALANCE, "user_id", "Missing parameter: user_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_BUY_CHIPS, "cmscore_game_id", "Missing parameter: cmscore_game_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_ENTRY, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_REBUY,  "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER,  "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.BINGO.getId(), TransactionType.STAKE, "currency_id", "Missing parameter: currency_id", 7},
		};
	}
	
	@DataProvider(name = "handleInstantGamesStakeMissingParameters")
	public Object[][] handleInstantGamesStakeMissingParameters() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_STAKE, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_STAKE, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_STAKE, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_STAKE, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_STAKE, "user_id", "Missing parameter: user_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_STAKE, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_STAKE, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_STAKE,  "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_STAKE,  "token", "Missing parameter: token", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_STAKE, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_STAKE, "action_type_id", "Invalid action_type_id", 1011},
		};
	}
	
	@DataProvider(name = "handleReturnMissingParameters")
	public Object[][] handleReturnMissingParameters() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.RETURN, "token", "Missing parameter: token", 7},
			{ProductId.CASINO.getId(), TransactionType.FREE_SPIN_RETURN, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.CASINO.getId(), TransactionType.GOLDEN_CHIP_RETURN, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_CASINO, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.BINGO.getId(), TransactionType.TRANSFER_FROM_BINGO_BONUS_BALANCE, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO, "user_id", "Missing parameter: user_id", 7},
			{ProductId.GAMES.getId(), TransactionType.GAMING_RETURN, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_SELL_CHIPS, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_WIN,  "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_POKER,  "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.BINGO.getId(), TransactionType.RETURN, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.CASINO.getId(), TransactionType.GOLDEN_CHIP_RETURN, "source_bet365_games_transaction_id", "Missing parameter: source_bet365_games_transaction_id", 7},
			{ProductId.GAMES.getId(), TransactionType.RETURN, "action_type_id", "Invalid action_type_id", 1011},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_RETURN, "token", "Missing parameter: token", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_RETURN, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_RETURN, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_RETURN, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_RETURN, "user_id", "Missing parameter: user_id", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_RETURN, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_RETURN, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_RETURN,  "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_RETURN,  "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_RETURN, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_RETURN, "source_bet365_games_transaction_id", "Missing parameter: source_bet365_games_transaction_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_RETURN, "action_type_id", "Invalid action_type_id", 1011},
		};
	}
	
	@DataProvider(name = "handlePrizeMissingParameters")
	public Object[][] handlePrizeMissingParameters() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.GAMING_PRIZE_AWARD, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.GAMES.getId(), TransactionType.GAMING_PRIZE_AWARD, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.CASINO.getId(), TransactionType.GAMING_PRIZE_AWARD, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.GAMES.getId(), TransactionType.GAMING_PRIZE_AWARD, "user_id", "Missing parameter: user_id", 7},
			{ProductId.POKER.getId(), TransactionType.GAMING_PRIZE_AWARD, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.SLOTS.getId(), TransactionType.GAMING_PRIZE_AWARD,  "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.GAMING_PRIZE_AWARD,  "token", "Missing parameter: token", 7},
			{ProductId.BINGO.getId(), TransactionType.GAMING_PRIZE_AWARD, "currency_id", "Missing parameter: currency_id", 7},
		};
	}
	
	@DataProvider(name = "handleVoidStake")
	public Object[][] handleVoidStake() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.VOID_STAKE, "token", "Missing parameter: token", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_GAMING_STAKE, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, "user_id", "Missing parameter: user_id", 7},
			{ProductId.BINGO.getId(), TransactionType.VOID_STAKE, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_STAKE, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_GAMING_STAKE,  "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_STAKE,  "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.BINGO.getId(), TransactionType.VOID_GAMING_STAKE, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_STAKE, "action_type_id", "Invalid action_type_id", 1011},
			{ProductId.CASINO.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "token", "Missing parameter: token", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.CASINO.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.CASINO.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "user_id", "Missing parameter: user_id", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.CASINO.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE,  "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.CASINO.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE,  "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.CASINO.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "action_type_id", "Invalid action_type_id", 1011},
		};
	}
	
	@DataProvider(name = "invalidTransferAmountProvider")
	public Object[][] getinvalidTransferAmounts() {
		return new Object[][] {
			{TransactionType.STAKE, regulatedGameId, cmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.FREE_SPIN_STAKE, regulatedGameId, cmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.GOLDEN_CHIP_STAKE, regulatedGameId, cmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, anyRegulatedGameId, anyCmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.TRANSFER_TO_BINGO_BONUS_BALANCE, anyRegulatedGameId, anyCmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO, anyRegulatedGameId, anyCmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.POKER_BUY_CHIPS, anyRegulatedGameId, anyCmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER, anyRegulatedGameId, anyCmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()}
			};
	}
	
	@DataProvider(name = "getUserBalance")
	public Object[][] getUserBalance() {
		return new Object[][] {
			{ProductId.GAMES, UsersId.GOSERVICE1, "0", "0", "0", false},
			{ProductId.GAMES, UsersId.GOSERVICE2, "80", "56", "0", true},
			{ProductId.CASINO, UsersId.GO_SVC_TESTS01, "70", "30", "30", true},
			{ProductId.LIVE_CASINO, UsersId.GO_SVC_TESTS01, "70", "0", "0", false},
			{ProductId.LIVE_CASINO_NATIVE, UsersId.GO_SVC_TESTS01, "70", "0", "0", false},
			{ProductId.POKER, UsersId.GOSERVICE2, "80", "0", "0", false},
			{ProductId.BINGO, UsersId.GOSERVICE2, "80", "0", "0", false},
			{ProductId.CASINO, UsersId.GOSERVICE3, "100", "6", "0", true},
			{ProductId.LIVE_CASINO, UsersId.GOSERVICE3, "100", "0", "0", true},
			{ProductId.GAMES, UsersId.GOSERVICE3, "100", "0", "0", false},
			{ProductId.POKER, UsersId.GO_SVC_TESTS02, "164.72", "0", "0", true},
			{ProductId.GAMES, UsersId.NOT_EXISTING, "0", "0", "0", false},
		};
	}
	
	@DataProvider(name = "getUserBalanceNotFoundUser")
	public Object[][] getUserBalanceNotFoundUser() {
		return new Object[][] {
			{ProductId.GAMES, UsersId.NOT_EXISTING, "0", "0", "0", false},
			{ProductId.CASINO, UsersId.NOT_EXISTING, "0", "0", "0", true},
			{ProductId.LIVE_CASINO, UsersId.NOT_EXISTING, "0", "0", "0", false},
			{ProductId.POKER, UsersId.NOT_EXISTING, "0", "0", "0", false},
			{ProductId.BINGO, UsersId.NOT_EXISTING, "0", "0", "0", false},
		};
	}
	
	@DataProvider(name = "UserIdSuccess")
	public Object[][] UserIdSuccess() {
		return new Object[][] {
			{2147483647}	
		};
	}
	@DataProvider(name = "setWeekStartDaySuccess")
	public Object[][] setWeekStartDaySuccess() {
		return new Object[][] {
			{1}, {3}, {6}		
		};
	}

	@DataProvider(name = "setWeekStartDayFailure")
	public Object[][] setWeekStartDayFailure() {
		return new Object[][] {
			{-1}, {7}, {8}		
		};
	}

	@DataProvider(name = "bucketTypeRangeSuccess")
	public Object[][] bucketTypeRangeSuccess() {
		return new Object[][] {
			{"s"}, {"sessioning"}, {"sessionsessionsessio"}		
		};
	}

	@DataProvider(name = "groupIdentifierSuccess")
	public Object[][] groupIdentifierSuccess() {
		return new Object[][] {
			{"E"}, {"Ccg7teUAkhTD1DZGyD+arER@qnZ54WY2Ne+Ruv822e*$6KoFF4"}, {"1tkgYErm3*&=%PSMoNO$oWCE$nhjesBodxD6jdcNMk1Yv%&tF6gMsJNOg=PCZkQNqd&vNrZ2c189FeQrNAsySDhQwMrp=Z2tdYEO"},		
		};
	}

	@DataProvider(name = "localDateTimeSuccess")
	public Object[][] localDateTimeSuccess() {
		return new Object[][] {
			{-86400000000000L}, {86400000000000L}	
		};
	}

	@DataProvider(name = "localDateTimeFailure")
	public Object[][] localDateTimeFailure() {
		return new Object[][] {
			{-86400000000001L}, {86400000000001L}	
		};
	}
	
	@DataProvider(name = "breachType")
	public Object[][] breachType() {
		return new Object[][] {
			{1}, {2}, {3}, {4},	{5}, {6}, {7}, {8},	{9}, {10}, {11}, {12}, {13}, {14}, {15}, {16}, {17}, {18}, {19}, {20}, {21}, {22}, {23}, {24}, {25}, {26},
			{27}, {28}, {29}, {30}, {31}, {32}, 
		};
	}

	@DataProvider(name = "gameroundidSuccess")
	public Object[][] gameroundidSuccess() {
		return new Object[][] {
			{1L}, {2147483647L}, {9223372036854775807L}
		};
	}
	
	@DataProvider(name = "createGameRoundUseridSuccess")
	public Object[][] createGameRoundUseridSuccess() {
		return new Object[][] {
			{1}, {2147483647}, {1073741823}
		};
	}
	
	@DataProvider(name = "createGameRoundPartnerIdSuccess")
	public Object[][] createGameRoundPartnerIdSuccess() {
		return new Object[][] {
			{1}, {2147483647}, {1073741823}
		};
	}
	
	@DataProvider(name = "createGameRoundRegulatedGameIdSuccess")
	public Object[][] createGameRoundRegulatedGameIdSuccess() {
		return new Object[][] {
			{1}, {2147483647}, {1073741823}
		};
	}
	
	@DataProvider(name = "createGameRoundProviderRegionIdSuccess")
	public Object[][] createGameRoundProviderRegionIdSuccess() {
		return new Object[][] {
			{1}, {2147483647}, {1073741823}
		};
	}
	
	@DataProvider(name = "createGameRoundChannelIdSuccess")
	public Object[][] createGameRoundChannelIdSuccess() {
		return new Object[][] {
			{1}, {2147483647}, {1073741823}
		};
	}
	
	@DataProvider(name = "closedReasonIdSuccess")
	public Object[][] closedReasonIdSuccess() {
		return new Object[][] {
			{1}, {2147483647}, {1073741823}
		};
	}
	
	@DataProvider(name = "partnerGameRoundIdSuccess")
	public Object[][] partnerGameRoundIdSuccess() {
		return new Object[][] {
			{"E"}, {"Ccg7teUAkhTD1DZGyD+arER@qnZ54WY2Ne+Ruv822e*$6KoFF4"}, {"1tkgYErm3*&=%PSMoNO$oWCE$nhjesBodxD6jdcNMk1Yv%&tF6gMsJNOg=PCZkQNqd&vNrZ2c189FeQrNAsySDhQwMrp=Z2tdYEO"},		
		};
	}
	
	@DataProvider(name = "partnerIdSuccess")
	public Object[][] partnerIdSuccess() {
		return new Object[][] {
			{1}, {1073741823}, {2147483647}
		};
	}

	@DataProvider(name = "closedUserIdSuccess")
	public Object[][] closedUserIdSuccess() {
		return new Object[][] {
			{1}, {1073741823}, {2147483647} 
		};
	}
	
	@DataProvider(name = "gameRngIdSuccess")
	public Object[][] gameRngIdSuccess() {
		return new Object[][] {
			{"E"}, {"OarTo6FNUQce&zjXVwsq3v917"}, {"qrSX2@woy&NRCdsANONKeF8U8bRbHMp=FbyVKf4BP3QZ8MbVk4"},		
		};
	}
	
	@DataProvider(name = "softwareIdSuccess")
	public Object[][] softwareIdSuccess() {
		return new Object[][] {
			{"E"}, {"OarTo6FNUQce&zjXVwsq3v917"}, {"qrSX2@woy&NRCdsANONKeF8U8bRbHMp=FbyVKf4BP3QZ8MbVk4"},		
		};
	}
	
	@DataProvider(name = "transactionIdSuccess")
	public Object[][] transactionIdSuccess() {
		return new Object[][] {
			{new BigInteger("1")}, {new BigInteger("2147483647")}, {new BigInteger("9223372036854775807")},		
		};
	}
	
	@DataProvider(name = "codeSuccess")
	public Object[][] codeSuccess() {
		return new Object[][] {
			{"E"}, {"OarTo6FNUQce&zjXVwsq3v917"}, {"qrSX2@woy&NRCdsANONKeF8U8bRbHMp=FbyVKf4BP3QZ8MbVk4"},		
		};
	}
	
	@DataProvider(name = "networkIdSuccess")
	public Object[][] networkIdSuccess() {
		return new Object[][] {
			{"E"}, {"OarTo6FNUQce&zjXVwsq3v917"}, {"qrSX2@woy&NRCdsANONKeF8U8bRbHMp=FbyVKf4BP3QZ8MbVk4"},		
		};
	}
	
	@DataProvider(name = "jackpotWinSuccess")
	public Object[][] jackpotWinSuccess() {
		return new Object[][] {
			{new BigDecimal("0")}, {new BigDecimal("444444444444444.4444")}, {new BigDecimal("999999999999999.9999")},		
		};
	}
	
	@DataProvider(name = "jackpotContributionSuccess")
	public Object[][] jackpotContributionSuccess() {
		return new Object[][] {
			{new BigDecimal("0")}, {new BigDecimal("4444444.4444444")}, {new BigDecimal("9999999.9999999")},		
		};
	}
	
	@DataProvider(name = "jackpotWinNegativeValuesSuccess")
	public Object[][] jackpotWinNegativeValuesSuccess() {
		return new Object[][] {
			{new BigDecimal("-1")}, {new BigDecimal("-444444444444444.4444")}, {new BigDecimal("-999999999999999.9999")},		
		};
	}
	
	@DataProvider(name = "jackpotContributionNegativeValuesSuccess")
	public Object[][] jackpotContributionNegativeValuesSuccess() {
		return new Object[][] {
			{new BigDecimal("-1")}, {new BigDecimal("-4444444.4444444")}, {new BigDecimal("-9999999.9999999")},		
		};
	}
	
	@DataProvider(name = "bet365TransactionIdSuccess")
	public Object[][] bet365TransactionIdSuccess() {
		return new Object[][] {
			{new BigInteger("1")}, {new BigInteger("2147483647")}, {new BigInteger("9223372036854775807")}
		};
	}
	
	@DataProvider(name = "taxableAmountPositiveValueSuccess")
	public Object[][] taxableAmountPositiveValueSuccess() {
		return new Object[][] {
			{new BigDecimal("1.1234")}, {new BigDecimal("214748.3647")}, {new BigDecimal("922337203685477.5807")},		
		};
	}
	
	@DataProvider(name = "taxableAmountNegativeValueSuccess")
	public Object[][] taxableAmountNegativeValueSuccess() {
		return new Object[][] {
			{new BigDecimal("-1.1234")}, {new BigDecimal("-214748.3647")}, {new BigDecimal("-922337203685477.5808")},		
		};
	}
	
	@DataProvider(name = "invalidFormatRangePromotionToken")
	public Object[][] invalidFormatRangePromotionToken() {
		return new Object[][] {
			{"E"}, {"C10B9A90-3525-4278-A980-4ECAE1CC6CA00"}, {"C10B9A90-3525-4278-A980-4ECAE1CC6CA"}		
		};
	}

	@DataProvider(name = "promotionIdSuccess")
	public Object[][] promotionIdSuccess() {
		return new Object[][] {
			{1}, {1073741823}, {2147483647}
		};
	}
	
	@DataProvider(name = "bucketTypeRangeFailure")
	public Object[][] bucketTypeRangeFailure() {
		return new Object[][] {
			{""}, {"sessionsessionsession"}		
		};
	}

	@DataProvider(name = "groupIdentifierFailure")
	public Object[][] groupIdentifierFailure() {
		return new Object[][] {
			{""}, {"1tkgYErm3*&=%PSMoNO$oWCE$nhjesBodxD6jdcNMk1Yv%&tF6gMsJNOg=PCZkQNqd&vNrZ2c189FeQrNAsySDhQwMrp=Z2tdYEO0"},		
		};
	}
	
	@DataProvider(name = "productIdSuccess")
	public Object[][] productIdSuccess() {
		return new Object[][] {
			{1}, {1073741823}, {2147483647}
		};
	}
}
