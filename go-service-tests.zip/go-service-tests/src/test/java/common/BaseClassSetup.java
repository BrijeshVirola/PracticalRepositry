package common;

import org.testng.ITestContext;
import org.testng.annotations.BeforeSuite;

import io.restassured.RestAssured;

public class BaseClassSetup {


	@BeforeSuite()
	public void init(ITestContext context) {

		RestAssured.baseURI = System.getProperty("baseUri") != null ? System.getProperty("baseUri") : context.getCurrentXmlTest().getParameter("baseUri");

	}

}
