package common;

public class KnownIssue {

	private final String issue;
	private final String jiraRef;
	private final String action;
	
	public KnownIssue(String issue, String jiraRef, String action) {
		this.issue = issue;
		this.jiraRef = jiraRef;
		this.action = action;
	}
	
	public String getTest() {
		return this.issue;
	}
	
	public String getJiraRef() {
		return this.jiraRef;
	}
	
	public String getAction() {
		return this.action;
	}
}
