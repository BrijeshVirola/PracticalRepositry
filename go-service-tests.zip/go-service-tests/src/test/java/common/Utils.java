package common;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import com.google.gson.Gson;

import common.testtoken.enums.SessionEndpoints;
import common.testtoken.request.CreateSlotsSessionTestReq;
import common.testtoken.request.CreateUserSessionTestReq;
import common.testtoken.response.CreateSlotsSessionTestResp;
import common.testtoken.response.CreateUserSessionTestResp;
import domain.BaseRequest;
import junit.framework.Assert;
import tests.slotsservice.request.GetActiveGameSessionReq;
import tests.slotsservice.response.GameSessionResp;
import tests.tokenservice.request.CreatePrivateTokenReq;
import tests.tokenservice.request.CreatePublicTokenReq;
import tests.tokenservice.requestobjects.CreatePrivateTokenParams;
import tests.tokenservice.requestobjects.CreatePublicTokenParams;
import tests.tokenservice.response.CreatePublicTokenResp;
import tests.tokenservice.response.TokenResp;

public class Utils {

	public static CreatePublicTokenResp createNewPublicToken(int userId) {

		String publicToken = UUID.randomUUID().toString();

		CreatePublicTokenReq publicRequest = new CreatePublicTokenReq
				.Builder()
				.defaults()
				.params(new CreatePublicTokenParams
						.Builder()
						.defaults()
						.userId(userId)
						.publicToken(publicToken)
						.build())
				.build();

		CreatePublicTokenResp actualCreateResponse =  BaseRequest.post(publicRequest, SessionEndpoints.createPublicTokenSuccess);
		CreatePublicTokenResp expectedCreateResponse = new CreatePublicTokenResp.Builder()
				.id(null)
				.defaults()
				.sno(actualCreateResponse.sno())
				.publicToken(publicToken)
				.build();

		Assert.assertEquals(expectedCreateResponse.publicToken(),actualCreateResponse.publicToken());
		Assert.assertTrue(actualCreateResponse.sno() > 0);

		return actualCreateResponse;
	}

	public static TokenResp createNewPrivateToken(String publicToken) {
		CreatePrivateTokenReq request = new CreatePrivateTokenReq
				.Builder()
				.defaults()
				.params(new CreatePrivateTokenParams
						.Builder()
						.defaults()
						.token(publicToken)
						.build())
				.build();
		TokenResp actualResponse =  BaseRequest.post(request, SessionEndpoints.createPrivateTokenSuccess);
		return actualResponse;
	}

	public static String createNewSlotsSession(String username, BigDecimal slotsSessionBalance) {

		CreateSlotsSessionTestReq publicRequest = new CreateSlotsSessionTestReq
				.Builder()
				.defaults()
				.username(username)
				.slotsSessionBalance(slotsSessionBalance)
				.build();

		CreateSlotsSessionTestResp token = BaseRequest.post(publicRequest, SessionEndpoints.createSlotsSessionTokenSuccess, BaseURI.CREATE_USER_SESSION);
		return token.getTestToken();
	}

	public static String getSlotsGameSessionId(int userId) {

		GetActiveGameSessionReq request = new GetActiveGameSessionReq.Builder()
				.defaults()
				.userId(userId)
				.build();

		GameSessionResp actResponse =  BaseRequest.post(request, SessionEndpoints.getActiveGameSessionSuccess);

		return actResponse.getGameSessionId();
	}

	public static CreateUserSessionTestResp createSession(String username) {

		CreateUserSessionTestReq createUserSessionTestRequest = new CreateUserSessionTestReq.Builder()
				.defaults()
				.username(username)
				.build();

		CreateUserSessionTestResp sessionResponse = BaseRequest.post(createUserSessionTestRequest, SessionEndpoints.createUserSessionTestSuccess, BaseURI.CREATE_USER_SESSION);

		return sessionResponse;
	}

	public static CreateUserSessionTestResp createSession(Integer intervalInMinutes, Integer triggerNextRealityCheckInSeconds) {

		CreateUserSessionTestReq createUserSessionTestRequest = new CreateUserSessionTestReq.Builder()
				.defaults()
				.realityCheckInterval(intervalInMinutes)
				.realityCheckSecondsUntil(triggerNextRealityCheckInSeconds)
				.build();

		CreateUserSessionTestResp sessionResponse = BaseRequest.post(createUserSessionTestRequest, SessionEndpoints.createUserSessionTestSuccess, BaseURI.CREATE_USER_SESSION);

		return sessionResponse;
	}

	/**
	 * Convert Json string to Java class object
	 * @param <T>
	 * @param jsonString
	 * @param respClass
	 * @return
	 */
	public static <T> T convertJsonToObject(String jsonString, Class<T> respClass) {
		Gson gson = new Gson();
		return gson.fromJson(jsonString, respClass);
	}

	/**
	 * Get the last message from a List with slight delay
	 * @param List of messages
	 * @return
	 * @throws InterruptedException 
	 */
	public static String getLastMessage(List<String> messages) throws InterruptedException {
		Thread.sleep(500);
		return messages.get(messages.size() - 1);
	}

	/**
	 * @return formatted date/time in UTC format yyyy-MM-dd'T'HH:mm:ss.SSSSSSS'Z'
	 */
	public static String dateTimeUtc() {
		Date currentDate = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSS'Z'");
		return simpleDateFormat.format(currentDate);
	}

	public static ArrayList<Integer> generateRandomUserIdList(int size) {
		int range = 999999;		

		ArrayList<Integer> set = new ArrayList<>();

		while(set.size()< size) {
			Random rnd = new Random();
			int number = rnd.nextInt(range);
			set.add(number);

		}  

		return set;
	}
}
