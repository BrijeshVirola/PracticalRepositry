package common.testtoken.enums;


import common.enumsconstants.ResponseEndpoints;
import common.testtoken.response.CreateSlotsSessionTestResp;
import common.testtoken.response.CreateUserSessionTestResp;
import tests.slotsservice.response.GameSessionResp;
import tests.tokenservice.response.CreatePublicTokenResp;
import tests.tokenservice.response.TokenResp;

public enum SessionEndpoints implements ResponseEndpoints {

	createPublicTokenSuccess(CreatePublicTokenResp.class, "CreatePublicToken"),
	createSlotsSessionTokenSuccess(CreateSlotsSessionTestResp.class, "createslotstoken-test"),
	createPrivateTokenSuccess(TokenResp.class, "CreatePrivateToken"),
	getActiveGameSessionSuccess(GameSessionResp.class, "GetActiveGameSession"),
	createUserSessionTestSuccess(CreateUserSessionTestResp.class, "CreateUserSession-Test");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> SessionEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
