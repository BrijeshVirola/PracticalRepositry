package common.enumsconstants;

public enum ServiceErrors implements Errors {
	
	NOT_HTTP_POST(1, "Request must be a POST"),
	NOT_HTTP_GET(1, "Request must be a GET"),
	UNKNOWN_METHOD(6, "Unknown method"),
	THE_CONTENT_TYPE_HEADER_WAS_MISSING_OR_INVALID(2, "Request must specify a Content-Type of application/json"),
	THE_ACCEPT_HEADER_WAS_MISSING_OR_INVALID(3, "Request must specify a Accept header of application/json"),
	INVALID_REQUEST(4, "Invalid request"),
	NO_JSON_REQUEST(4, "Body was empty"),
	EMPTY_JSON_BODY_REQUEST(5, "Method missing from request"),

	MISSING_REQUIRED_PARAM_USER_ID(7, "Missing parameter: user_id"),
	MISSING_REQUIRED_PARAM_PARTNER_ID(7, "Missing parameter: partner_id"),
	MISSING_REQUIRED_PARAM_PARTNER_TRANSACTION_ID(7, "Missing parameter: partner_transaction_id"),
	MISSING_REQUIRED_PARAM_PARTNER_TRANSACTION_TYPE_ID(7, "Missing parameter: transaction_type_id"),
	MISSING_PROVIDER_REGION_ID(7, "Missing parameter: provider_region_id"),
	USER_NOT_FOUND(1001, "User not found"),
	CHANNEL_ID_INVALID(1002, "channel_id is invalid"),
	TRANSACTION_NOT_FOUND(1010, "Transaction not found");
	
	public final int code;
	public final String message;

	private ServiceErrors(int code, String message) {
		this.code = code;
		this.message = message;
	}
	
	@Override
	public int getCode() {
		return code;
	}

	@Override
	public String getMessage() {
		return message;
	}
	
	public static enum GameRound implements Errors {
		PARTNER_GAME_ROUND_ID_LENGTH_OUT_OF_BOUNDS(1001, "partner_game_round_id should be between 1 and 100 long"),
		GAME_ROUND_NOT_FOUND(1006, "Game round not found");
		
		public final int code;
		public final String message;
		
		private GameRound(int code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		public int getCode() {
			return code;
		}

		@Override
		public String getMessage() {
			return message;
		}
	}
	
	public static enum Balance implements Errors {
		ID_TOO_LONG(4, "Couldn't unmarshal params into target type : json: cannot unmarshal number 9223372036854775808 into Go struct field getTransactionByIDRequest.id of type int64"),
		TRANSACTION_FAILED_FOR_UNKNOWN_REASON(1004,"Transaction unexpectedly failed"),		
		INSUFFICIENT_FUNDS(1005, "Insufficient funds"),
		INVALID_TRANSFER_AMOUNT(1006, "Stakes must use a negative total_amount"),
		INVALID_TRANSFER_TYPE(1009, "Invalid transaction type"),
		//TODO there are other messages for the following error code. The current way of handling them doesn't scale well
		INVALID_PARAMETER_VALUE(1011,"Invalid action_type_id");
		
		public final int code;
		public final String message;
		
		private Balance(int code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		public int getCode() {
			return code;
		}

		@Override
		public String getMessage() {
			return message;
		}
	}

	public static enum Token implements Errors {
		INCORRECT_METHOD(6,"Incorrect method in request"),
		MISSING_PARAMETER(7, "Missing parameter: "),
		TOKEN_IS_NOT_PUBLIC(1004, "Supplied token was not public"),
		TOKEN_IS_NOT_PRIVATE(1005, "Supplied token was not private"),
		PUBLIC_TOKEN_WAS_NOT_CREATED(1006, "Public token was not created"),
		SUPPLIED_TOKEN_IS_TOO_LONG(1007,"Supplied token is too long (100 chars max)"),
		UNEXPECTED_ERROR(1008, "Unexpected error");
		
		public final int code;
		public final String message;
		
		private Token(int code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		public int getCode() {
			return code;
		}

		@Override
		public String getMessage() {
			return message;
		}
	}
}
