package common.enumsconstants;

public class Constants {

	public static final long nodeId = 69L;
	
}
