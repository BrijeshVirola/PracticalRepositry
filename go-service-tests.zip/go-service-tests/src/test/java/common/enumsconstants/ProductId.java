package common.enumsconstants;

public enum ProductId {
	
	SPORTSBOOK(1), 
	CASINO(2),
	LIVE_CASINO(45),
	LIVE_CASINO_NATIVE(46),
	POKER(3),
	GAMES(4),
	BINGO(7),
	SLOTS(25);
	
	private int productId;

	ProductId(int productId) {
		this.productId = productId;
	}

	public int getId() {
		return productId;
	}

}
