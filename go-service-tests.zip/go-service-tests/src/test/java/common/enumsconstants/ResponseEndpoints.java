package common.enumsconstants;

public interface ResponseEndpoints {

	public <T> Class<T> getRespClass();
	public String getEndPoint();
}
