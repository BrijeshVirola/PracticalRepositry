package common.RetryTestFailures;

import java.util.HashMap;
import java.util.Map;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

/**
 * Re-runs failed test cases
 * @author petarpetrov
 *
 */
public class RetryAnalyzer implements IRetryAnalyzer {

	// The retry number is given as a property in the Jenkins job
    private static Integer maxRetries = System.getProperty("retryCount") != null
    	? Integer.parseInt(System.getProperty("retryCount"))
    	: 0;
    
    private static final Map<String, Integer> retryCount = new HashMap<>();
    
    @Override
    public boolean retry(ITestResult result) {

    	// Retry failures
    	if (canRetry(result)) {

    		System.out.println("Going to retry test - " + CleanUpDuplicate.getId(result));
    		retryCount.put(CleanUpDuplicate.getId(result), getRetryCount(result) + 1);
    		return true;
    	}

    	return false;
    }

    // check if test should be retried
    public boolean canRetry(ITestResult result) {
        return result.getStatus() == ITestResult.FAILURE && getRetryCount(result) < getMaxRetriesAllowed();
    }

    // handles duplicate tests using data provider
    private int getRetryCount(ITestResult result) {
        final String testId = CleanUpDuplicate.getId(result);
        return retryCount.containsKey(testId) ? retryCount.get(testId) : 0;
    }

    public static int getMaxRetriesAllowed() {
        return maxRetries;
    }
}