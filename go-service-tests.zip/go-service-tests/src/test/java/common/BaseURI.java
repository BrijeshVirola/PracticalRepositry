package common;

public class BaseURI {

	private static final String SERVER_URL = "http://mn2gampsr0002u0";
	
	public static final String CREATE_USER_SESSION = SERVER_URL + ":18380/api/"; // Also used for creating Slots session 
	public static final String GAME_ROUND_SERVICE = SERVER_URL + ":18060/api/";
	public static final String GAMING_BONUS_ADMIN_SERVICE = "http://gaminginternalsvc.uat.lb.local/gam-bonus-admin-svcv1/api/";
	
}
