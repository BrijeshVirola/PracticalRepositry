package common;
import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;


public class TimeUtils {

	public static String getCurrentTimeAsIsoString() {
		Date currentDate = new Date(System.currentTimeMillis());
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		return dateFormat.format(currentDate);
	}


	public static String dateUTCResponseValidation(String jsonResponse) {
		String currentSystemDate="";
		try {
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date date = new Date();
			currentSystemDate = dateFormat.format(date); 
			System.out.println("Date = " + currentSystemDate);
		} catch (Exception e) {
			e.printStackTrace();

		}
		return currentSystemDate;
	}


	public static String timeUTCResponseValidation(String jsonResponse) {
		String currentTime="";
		try {
			Format timeFormat = new SimpleDateFormat("HH:mm");
			currentTime = timeFormat.format(new Date());
			System.out.println("Time = " + currentTime);
		} catch (Exception e) {
			e.printStackTrace();

		}
		return currentTime;
	}

}
