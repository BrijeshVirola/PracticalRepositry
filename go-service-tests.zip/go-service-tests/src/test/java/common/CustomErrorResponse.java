package common;

import java.util.HashMap;
import java.util.Map;


public class CustomErrorResponse {
	@SuppressWarnings("unused")
	private String id;
	private Map<String, Object> error = new HashMap<>();

	private CustomErrorResponse(Builder builder) {
		this.id = builder.id;
		this.error.put("code",builder.code);
		this.error.put("message",builder.message);
	}

	public static class Builder {
		private String id;
		private Integer code;
		private String message;

		public Builder code(Integer code) {
			this.code = code;
			return this;
		}

		public Builder message(String message) {
			this.message = message;
			return this;
		}
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder defaults() {
			this.id = null;		
			this.code = 1;
			this.message = "Request must be a POST";
			return this;
		}
		
		public CustomErrorResponse build() {
			return new CustomErrorResponse(this);		}
	}
}

