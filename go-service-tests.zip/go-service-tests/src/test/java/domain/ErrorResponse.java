package domain;

import common.enumsconstants.Errors;

public class ErrorResponse {
	
	@SuppressWarnings("unused")
	private ErrorObject error;
	
	public ErrorResponse() {
	}

	public ErrorResponse(Errors error) {
		this.error = new ErrorObject(error);
	}
}
