package domain;

import java.util.Map;

import com.google.gson.JsonObject;

import common.enumsconstants.ResponseEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import logging.LoggingRequestFilter;

public class BaseRequest {

	private static LoggingRequestFilter filter = new LoggingRequestFilter();
	private static JsonObject body = new JsonObject();

	public static RequestSpecification createRequest(JsonObject jsonBody) {
		return createRequest(jsonBody, true, true); 
	}

	public static RequestSpecification createRequest(Object pojo) {
		return createRequest(pojo, true, true); 
	}

	public static RequestSpecification createRequest(JsonObject jsonBody, boolean shouldSetAcceptHeader, boolean shouldSetContentTypeHeader) {
		RequestSpecification request = RestAssured.given().filter(filter);

		setAcceptAndContentType(shouldSetAcceptHeader, shouldSetContentTypeHeader, request);

		request.body(jsonBody.toString());

		return request;
	}

	public static RequestSpecification createRequest(Object pojo, boolean shouldSetAcceptHeader, boolean shouldSetContentTypeHeader) {

		RequestSpecification request = RestAssured.given().filter(filter);
		setAcceptAndContentType(shouldSetAcceptHeader, shouldSetContentTypeHeader, request);
		request.body(pojo);

		return request;
	}

	@SafeVarargs
	public static RequestSpecification getRequest(Map<String, Object> queryParams, Map<String, Object>... headers) {
		RequestSpecification request = RestAssured.given().filter(filter);

		if (headers.length > 0) {
			request.headers(headers[0]).queryParams(queryParams);
		} else {
			request.queryParams(queryParams);
		}

		setAcceptAndContentType(true, true, request);
		return request;
	}

	public static Response callWrongMethodNameRequest(String endPoint, boolean post) {

		JsonObject body = new JsonObject();
		body.addProperty("Method", "invalid_method");

		RequestSpecification request = createRequest(body);
		Response response = post ? request.post(endPoint) : request.get(endPoint);
		response.then().statusCode(200);
		return response;
	}

	/**
	 * 
	 * @param endPoint
	 * @param shouldSetAcceptHeader
	 * @param shouldSetContentTypeHeader
	 * @param post if true will call POST request, otherwise GET
	 * @return
	 */
	public static Response callEmptyBodyRequest(String endPoint, boolean shouldSetAcceptHeader,
			boolean shouldSetContentTypeHeader,
			boolean post) {

		RequestSpecification request = createRequest(body, shouldSetAcceptHeader, shouldSetContentTypeHeader);
		Response response = post ? request.post(endPoint) : request.get(endPoint);
		response.then().statusCode(200);
		return response;
	}

	public static Response callNoJsonRequest(String endPoint, boolean shouldSetAcceptHeader, boolean shouldSetContentTypeHeader,
			boolean post) {
		RequestSpecification request = RestAssured.given().filter(filter);
		setAcceptAndContentType(shouldSetAcceptHeader, shouldSetContentTypeHeader, request);
		request.body("");

		Response response = post ? request.post(endPoint) : request.get(endPoint);
		response.then().statusCode(200);
		return response;
	}

	private static void setAcceptAndContentType(boolean shouldSetAcceptHeader, boolean shouldSetContentTypeHeader, RequestSpecification request) {
		if (shouldSetAcceptHeader) {
			request.header("Accept", "application/json");
		}
		if (shouldSetContentTypeHeader) {
			request.header("Content-Type", "application/json");
		}
	}

	public static <T> T post(Object reqObject, ResponseEndpoints endpoint) {

		RequestSpecification request = createRequest(reqObject);
		Response response = request.post(endpoint.getEndPoint());
		response.then().statusCode(200);

		T resp = response.as(endpoint.getRespClass());

		return resp;
	}

	/**
	 * 
	 * @param <T>
	 * @param reqObject
	 * @param endpoint
	 * @param baseUri
	 * @return
	 */
	public static <T> T post(Object reqObject, ResponseEndpoints endpoint, String baseUri) {

		RequestSpecification request = RestAssured.given().baseUri(baseUri).
				filter(filter);
		setAcceptAndContentType(true, true, request);
		request.body(reqObject);

		Response response = request.post(endpoint.getEndPoint());
		response.then().statusCode(200);

		T resp = response.as(endpoint.getRespClass());

		return resp;
	}

	@SafeVarargs
	public static <T> T get(Map<String, Object> queryParams, ResponseEndpoints endpoint, Map<String, Object>... headers) {
		RequestSpecification request = getRequest(queryParams, headers);
		Response response = request.get(endpoint.getEndPoint());

		T resp = response.as(endpoint.getRespClass());

		return resp;
	}

}
