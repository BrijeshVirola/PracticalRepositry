package domain;

import common.enumsconstants.Errors;

public class ErrorObject {
	
	@SuppressWarnings("unused")
	private int code;
	@SuppressWarnings("unused")
	private String message;

	public ErrorObject(Errors error) {
		this.code = error.getCode();
		this.message = error.getMessage();
	}
}
