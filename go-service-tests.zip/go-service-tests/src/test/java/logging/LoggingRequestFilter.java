package logging;

import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;

public class LoggingRequestFilter implements Filter {
	
	@Override
	public Response filter(FilterableRequestSpecification requestSpec, FilterableResponseSpecification responseSpec, FilterContext ctx) {
		String requestUri = requestSpec.getURI();
		Log.event("Request Uri:" + requestUri);

		String requestBody = requestSpec.getBody();
		String jsonRequestBody = JsonFormatter.getFormattedJson(requestBody);
		Log.event("Request Body:" + jsonRequestBody);

		Response response = ctx.next(requestSpec, responseSpec);
		String responseBody = response.getBody().asString();
		String jsonResponseBody = JsonFormatter.getFormattedJson(responseBody);
		Log.event("Response Body:" + jsonResponseBody);
		
		return response; 
	}
}
