package logging;

import org.testng.Reporter;

public class Log {
	public static void event(String description) {
		Reporter.log(description, true);
	}
}
