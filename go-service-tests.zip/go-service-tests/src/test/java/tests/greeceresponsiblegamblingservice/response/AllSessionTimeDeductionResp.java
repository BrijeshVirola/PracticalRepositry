package tests.greeceresponsiblegamblingservice.response;

import java.util.HashMap;
import java.util.Map;

public class AllSessionTimeDeductionResp {
	
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> result = new HashMap<>();

	private AllSessionTimeDeductionResp(Builder builder) {
		this.id = builder.id;
		this.result.put("breach", builder.breach);
		this.result.put("breach_code", builder.breach_code);
	}

	public String getId() {
		return id;
	}

	public static class Builder {
		private String id;
		private Boolean breach;
		private String breach_code;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder breach(Boolean breach) {
			this.breach = breach;
			return this;
		}


		public Builder breachCode(String breach_code) {
			this.breach_code = breach_code;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.breach = true;
			this.breach_code = "1022";
			return this;
		}

		public AllSessionTimeDeductionResp build() {
			return new AllSessionTimeDeductionResp(this);
		}	
	}

}
