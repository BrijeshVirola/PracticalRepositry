package tests.greeceresponsiblegamblingservice.response;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

public class UserHasZeroLimitSetResp {

	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> result = new HashMap<>();

	private UserHasZeroLimitSetResp(Builder builder) {
		this.id = builder.id;
		this.result.put("has_limit_set_to_zero", builder.has_limit_set_to_zero);
		this.result.put("session_statebag_updated", builder.session_statebag_updated);
	}

	public String getId() {
		return id;
	}

	public Instant getBucketDate() {
		return Instant.parse(result.get("ServerLocalDate").toString());
	}

	public static class Builder {
		private String id;
		private Boolean has_limit_set_to_zero;
		private Boolean session_statebag_updated;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder hasLimitSetToZero(Boolean has_limit_set_to_zero) {
			this.has_limit_set_to_zero = has_limit_set_to_zero;
			return this;
		}


		public Builder sessionStateBagUpdated(Boolean session_statebag_updated) {
			this.session_statebag_updated = session_statebag_updated;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.has_limit_set_to_zero = false;
			this.session_statebag_updated = false;
			return this;
		}

		public UserHasZeroLimitSetResp build() {
			return new UserHasZeroLimitSetResp(this);
		}	
	}
}
