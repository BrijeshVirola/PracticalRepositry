package tests.greeceresponsiblegamblingservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import common.Utils;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.greeceresponsiblegamblingservice.enums.GrRespGamblingEndpoints;
import tests.greeceresponsiblegamblingservice.request.SessionNotificationReq;
public class SessionNotificationTests extends BaseClassSetup {

	@Test(description = "Make a request to update a session state bag flag GreeceLimitNotification on loss limit breach types. Positive scenario.",
			dataProvider = "breachType", dataProviderClass = DataProviders.class)
	public void sessionNotification_breachType1_Positive_Scenario(Integer breachType) {
		String username = "GO_SVC_SLOTSGR";

		// Create new session
		String sessionId = Utils.createSession(username).getSessionId();

		SessionNotificationReq request = new SessionNotificationReq.Builder()
				.defaults()
				.sessionId(sessionId)
				.breachType(breachType)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.sessionNotificationSuccess);

		ResultOKResp expectedResponse =  new ResultOKResp.Builder()
				.defaults()
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}	

	@Test(description = "Make a request to update a session state bag flag GreeceLimitNotification on loss limit breach. Missing Parameter.")
	public void sessionNotification_Missing_Parameter_SessionId() {

		SessionNotificationReq request = new SessionNotificationReq.Builder()
				.defaults()
				.sessionId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.sessionNotificationError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1004)
				.message("Session not found")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	

	@Test(description = "Make a request to update a session state bag flag GreeceLimitNotification on loss limit breach. Breach Type Error.")
	public void sessionNotification_Breach_type_error() {
		
		String username = "GO_SVC_SLOTSGR";
		
		String sessionId = Utils.createSession(username).getSessionId();

		SessionNotificationReq request = new SessionNotificationReq.Builder()
				.defaults()
				.sessionId(sessionId)
				.breachType(4098)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.sessionNotificationError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1006)
				.message("Wrong BreachType in the request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to update a session state bag flag GreeceLimitNotification on loss limit breach. Wrong method.")
	public void sessionNotification_Wrong_Method() {

		SessionNotificationReq request = new SessionNotificationReq.Builder()
				.defaults()
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.sessionNotificationError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
