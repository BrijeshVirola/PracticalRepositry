package tests.greeceresponsiblegamblingservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.common.response.ResultOKResp;
import tests.greeceresponsiblegamblingservice.response.AllSessionTimeDeductionResp;
import tests.greeceresponsiblegamblingservice.response.UpdateWinBetBucketAmountResp;
import tests.greeceresponsiblegamblingservice.response.UserHasZeroLimitSetResp;

public enum GrRespGamblingEndpoints implements ResponseEndpoints {

	setUserLossLimitSuccess(ResultOKResp.class, "setuserlosslimit"),
	setUserLossLimitError(CustomErrorResponse.class, "setuserlosslimit"),
	updateWinBetBucketAmountSuccess(UpdateWinBetBucketAmountResp.class, "updatewinbetbucketamount"),
	updateWinBetBucketAmountError(CustomErrorResponse.class, "updatewinbetbucketamount"),
	userHasZeroLimitSetSuccess(UserHasZeroLimitSetResp.class, "userhaszerolimitset"),
	userHasZeroLimitSetError(CustomErrorResponse.class, "userhaszerolimitset"),
	sessionNotificationSuccess(ResultOKResp.class, "sessionnotification"),
	sessionNotificationError(CustomErrorResponse.class, "sessionnotification"),
	schedulePokerSessionTimeDeductionSuccess(AllSessionTimeDeductionResp.class, "schedulepokersessiontimededuction"),
	schedulePokerSessionTimeDeductionError(CustomErrorResponse.class, "schedulepokersessiontimededuction"),
	schedulegameroundsessiontimedeductionSuccess(AllSessionTimeDeductionResp.class, "schedulegameroundsessiontimededuction"),
	schedulegameroundsessiontimedeductionError(CustomErrorResponse.class, "schedulegameroundsessiontimededuction"),
	pokerlogoutsessiontimedeductionSuccess(AllSessionTimeDeductionResp.class, "pokerlogoutsessiontimededuction"),
	pokerlogoutsessiontimedeductionError(CustomErrorResponse.class, "pokerlogoutsessiontimededuction"),
	endgameroundsessiontimedeductionSuccess(AllSessionTimeDeductionResp.class, "endgameroundsessiontimededuction"),
	endgameroundsessiontimedeductionError(CustomErrorResponse.class, "endgameroundsessiontimededuction"),
	updateusersessiontimeSuccess(AllSessionTimeDeductionResp.class, "updateusersessiontime"),
	updateusersessiontimeError(CustomErrorResponse.class, "updateusersessiontime");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> GrRespGamblingEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
