package tests.greeceresponsiblegamblingservice.request;

import java.util.HashMap;
import java.util.Map;

public class EndGameRoundSessionTimeDeductionReq {

	@SuppressWarnings("unused")
	private String method;

	private Map<String, Object> params = new HashMap<>();

	private EndGameRoundSessionTimeDeductionReq(Builder builder) {
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("session_id", builder.session_id);
		this.params.put("partner_id", builder.partner_id);
		this.params.put("partner_game_round_id", builder.partner_game_round_id);

	}

	public static class Builder {
		private String method, session_id, partner_game_round_id;
		private Integer user_id, partner_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder sessionId(String session_id) {
			this.session_id = session_id;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder partnerId(Integer partner_id) {
			this.partner_id = partner_id;
			return this;
		}

		public Builder partnerGameRoundId(String partner_game_round_id) {
			this.partner_game_round_id = partner_game_round_id;
			return this;
		}

		public Builder defaults() {
			this.method = "endgameroundsessiontimededuction";
			this.user_id = 4138494;
			this.session_id="2FC023C0C3C7459082EF65D3C063383C020004";
			this.partner_id=139;
			this.partner_game_round_id="6/30967896";
			return this;
		}

		public EndGameRoundSessionTimeDeductionReq build() {
			return new EndGameRoundSessionTimeDeductionReq(this);
		}
	}
}
