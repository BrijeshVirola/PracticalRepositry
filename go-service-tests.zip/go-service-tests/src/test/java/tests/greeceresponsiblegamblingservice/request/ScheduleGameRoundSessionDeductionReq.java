package tests.greeceresponsiblegamblingservice.request;

import java.util.HashMap;
import java.util.Map;

public class ScheduleGameRoundSessionDeductionReq {

	@SuppressWarnings("unused")
	private String method;

	private Map<String, Object> params = new HashMap<>();

	private ScheduleGameRoundSessionDeductionReq(Builder builder) {
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("session_id", builder.session_id);
		this.params.put("partner_id", builder.partner_id);
		this.params.put("product_id", builder.product_id);
		this.params.put("partner_game_round_id", builder.partner_game_round_id);
		this.params.put("participation_datetime_utc", builder.participation_datetime_utc);
		this.params.put("participation_duration", builder.participation_duration);	

	}

	public static class Builder {
		private String method, session_id, partner_game_round_id, participation_datetime_utc;
		private Integer user_id, partner_id, product_id, participation_duration;

		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder sessionId(String session_id) {
			this.session_id = session_id;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder partnerId(Integer partner_id) {
			this.partner_id = partner_id;
			return this;
		}

		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}


		public Builder partnerGameRoundId(String partner_game_round_id) {
			this.partner_game_round_id = partner_game_round_id;
			return this;
		}


		public Builder participationDateTime(String participation_datetime_utc) {
			this.participation_datetime_utc = participation_datetime_utc;
			return this;
		}
		
		public Builder participantDuration(Integer participation_duration) {
			this.participation_duration = participation_duration;
			return this;
		}


		public Builder defaults() {
			this.method = "schedulegameroundsessiontimededuction";
			this.user_id = 4128416;
			this.session_id="4D29A8B9397546AD82F987F02194AD76000004";
			this.partner_id=139;
			this.product_id=4;
			this.partner_game_round_id="6/30967896";
			this.participation_datetime_utc="2022-01-05T13:41:25.125Z";
			this.participation_duration=10;
			return this;
		}

		public ScheduleGameRoundSessionDeductionReq build() {
			return new ScheduleGameRoundSessionDeductionReq(this);
		}
	}
}
