package tests.greeceresponsiblegamblingservice.request;

import java.util.HashMap;
import java.util.Map;

public class SchedulePokerSessionTimeDeductionReq {

	@SuppressWarnings("unused")
	private String method;

	private Map<String, Object> params = new HashMap<>();

	private SchedulePokerSessionTimeDeductionReq(Builder builder) {
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("session_id", builder.session_id);
	}

	public static class Builder {
		private String method, session_id;
		private Integer user_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder SessionId(String session_id) {
			this.session_id = session_id;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder defaults() {
			this.method = "schedulepokersessiontimededuction";
			this.user_id = 4537946;
			this.session_id="C48171EE19834F879DB846ED0FC65B4A020004";		
			return this;
		}

		public SchedulePokerSessionTimeDeductionReq build() {
			return new SchedulePokerSessionTimeDeductionReq(this);
		}
	}
}
