package tests.greeceresponsiblegamblingservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.greeceresponsiblegamblingservice.enums.GrRespGamblingEndpoints;
import tests.greeceresponsiblegamblingservice.request.UpdateUserSessionTimeReq;
import tests.greeceresponsiblegamblingservice.response.AllSessionTimeDeductionResp;
public class UpdateUserSessionTimeTests extends BaseClassSetup {

	//TODO: Implement stored procs to have user session before executing the test. JIRA Issue ID: PRJSAK-2663
	@Test(enabled = false, description = "Make a request to Update the buckets with the participation time. Positive scenario.")
	public void updateusersessiontime_Positive_Scenario() {

		UpdateUserSessionTimeReq request = new UpdateUserSessionTimeReq.Builder()
				.defaults()
				.build();

		AllSessionTimeDeductionResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateusersessiontimeSuccess);

		AllSessionTimeDeductionResp expectedResponse =  new AllSessionTimeDeductionResp.Builder()
				.defaults()
				.id(null)
				.breachCode("1020")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}	

	@Test(description = "Make a request to Update the buckets with the participation time. Missing parameter userID.")
	public void updateusersessiontime_Missing_Parameter_user_id() {


		UpdateUserSessionTimeReq request = new UpdateUserSessionTimeReq.Builder()
				.defaults()
				.userId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateusersessiontimeError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Update the buckets with the participation time. Missing parameter sessionID.")
	public void updateusersessiontime_Missing_Parameter_session_id() {


		UpdateUserSessionTimeReq request = new UpdateUserSessionTimeReq.Builder()
				.defaults()
				.sessionId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateusersessiontimeError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: session_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Update the buckets with the participation time.Missing parameter productId.")
	public void updateusersessiontime_Missing_Parameter_product_id() {


		UpdateUserSessionTimeReq request = new UpdateUserSessionTimeReq.Builder()
				.defaults()
				.productId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateusersessiontimeError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: product_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Update the buckets with the participation time. Missing parameter partcipantDuration defaults to 0 and record breach.")
	public void updateusersessiontime_Missing_Parameter_participation_duration() {


		UpdateUserSessionTimeReq request = new UpdateUserSessionTimeReq.Builder()
				.defaults()
				.participantDuration(null)
				.build();

		AllSessionTimeDeductionResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateusersessiontimeSuccess);

		AllSessionTimeDeductionResp expectedResponse = new AllSessionTimeDeductionResp.Builder()
				.defaults()
				.id(null)
				.breach(true)
				.breachCode("1020")
				.build();						

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Update the buckets with the participation time.Missing parameter partcipantDateTime.")
	public void updateusersessiontime_Missing_Parameter_participation_dateTime() {


		UpdateUserSessionTimeReq request = new UpdateUserSessionTimeReq.Builder()
				.defaults()
				.participationDateTime(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateusersessiontimeError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: participation_datetime_utc")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Update the buckets with the participation time.Wrong method.")
	public void updateusersessiontime_Wrong_Method() {

		UpdateUserSessionTimeReq request = new UpdateUserSessionTimeReq.Builder()
				.defaults()
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateusersessiontimeError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
