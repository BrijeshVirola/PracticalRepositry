package tests.greeceresponsiblegamblingservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.Utils;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.greeceresponsiblegamblingservice.enums.GrRespGamblingEndpoints;
import tests.greeceresponsiblegamblingservice.request.SetUserLossLimitReq;
public class SetUserLossLimitTests extends BaseClassSetup {

	@Test(description = "Make a request to add or update the user's loss limits. Positive scenario.")
	public void setUserLossLimit_Positive_Scenario() {

		SetUserLossLimitReq request = new SetUserLossLimitReq.Builder()
				.defaults()
				.userId(4712511)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.setUserLossLimitSuccess);

		ResultOKResp expectedResponse =  new ResultOKResp.Builder()
				.defaults()
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}	

	@Test(description = "Make a request to add or update the user's loss limits. Missing parameter.")
	public void SetUserLossLimitReq_Missing_Parameter() {

		SetUserLossLimitReq request = new SetUserLossLimitReq.Builder()
				.defaults()
				.userId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.setUserLossLimitError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to add or update the user's loss limits. Missing parameter.")
	public void SetUserLossLimitReq_Missing_Loss_Limit() {

		SetUserLossLimitReq request = new SetUserLossLimitReq.Builder()
				.defaults()
				.dailyLossLimitAmount(null)
				.weeklyLossLimitAmount(null)
				.monthlyLossLimitAmount(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.setUserLossLimitError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing limits in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to add or update the user's loss limits. Wrong method.")
	public void updateBetBucketAmount_Wrong_Method() {

		SetUserLossLimitReq request = new SetUserLossLimitReq.Builder()
				.defaults()
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.setUserLossLimitError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
