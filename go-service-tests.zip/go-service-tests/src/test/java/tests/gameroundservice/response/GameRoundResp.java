package tests.gameroundservice.response;

import common.enumsconstants.Errors;
import domain.ErrorResponse;

public class GameRoundResp extends ErrorResponse {
	
	@SuppressWarnings("unused")
	private String id = null;
	private GameRoundResult result;
		
	public GameRoundResp(Errors error) {
		super(error);
	}
	
	public GameRoundResult getResult() {
		return result;
	}
	
	/**
	 * Make end dates and closed reason same as the closed game round response.
	 * This will be used when asserting that both both responses for created game round and closed game round are equal.
	 * Only Partner end date, end date and closed reason id are different initially.
	 * @param closeGameRoundResp
	 */
	public void setEndDateAndCloseReason(GameRoundResp closeGameRoundResp) {
		getResult().setPartnerEndDate(closeGameRoundResp.getResult().getPartnerEndDate());
		getResult().setEndDate(closeGameRoundResp.getResult().getEndDate());
		getResult().setClosedReasonId(closeGameRoundResp.getResult().getClosedReasonId());
	}

	public class GameRoundResult {
		
		private int id, partner_id, user_id, channel_id, provider_region_id, regulated_game_id, closed_reason_id;
		private String bet365_game_round_id, partner_game_round_id, start_date, partner_start_date, end_date, partner_end_date;

		public int getId() {
			return id;
		}
		public int getPartnerId() {
			return partner_id;
		}
		public int getUserid() {
			return user_id;
		}
		public int getChannelId() {
			return channel_id;
		}
		public int getProviderRegionId() {
			return provider_region_id;
		}
		public int getRegulatedGameId() {
			return regulated_game_id;
		}
		public int getClosedReasonId() {
			return closed_reason_id;
		}
		public void setClosedReasonId(int closedReasonId) {
			this.closed_reason_id = closedReasonId;
		}
		public String getBet365GameRoundId() {
			return bet365_game_round_id;
		}
		public String getPartnerGameRoundId() {
			return partner_game_round_id;
		}
		public String getStartDate() {
			return start_date;
		}
		public String getPartnerStartDate() {
			return partner_start_date;
		}
		public String getEndDate() {
			return end_date;
		}
		public void setEndDate(String endDate) {
			this.end_date = endDate;
		}
		public String getPartnerEndDate() {
			return partner_end_date;
		}
		public void setPartnerEndDate(String partnerEndDate) {
			this.partner_end_date = partnerEndDate;
		}
	}
}
