package tests.gameroundservice.enums;


import common.enumsconstants.ResponseEndpoints;
import tests.gameroundservice.response.GameRoundResp;
import tests.gameroundservice.response.InsertRngDetailsResp;

public enum GameRoundEndpoints implements ResponseEndpoints {

	insertRngDetails(InsertRngDetailsResp.class, "InsertRngDetails"),
	getGameRoundById(GameRoundResp.class, "GetGameRoundById"),
	getGameRoundByPartnerGameRoundId(GameRoundResp.class, "GetGameRoundByPartnerGameRoundId"),
	getGameRound(GameRoundResp.class, "GetGameRound"),
	createGameRound(GameRoundResp.class, "CreateGameRound"),
	closeGameRoundByBet365GameRoundId(GameRoundResp.class, "CloseGameRoundByBet365GameRoundId");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> GameRoundEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
