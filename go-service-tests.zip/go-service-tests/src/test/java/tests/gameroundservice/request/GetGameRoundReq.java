package tests.gameroundservice.request;

public class GetGameRoundReq {
	
	@SuppressWarnings("unused")
	private String Method = "getgameround";
	@SuppressWarnings("unused")
	private String id = "1";
	@SuppressWarnings("unused")
	private GetGameRoundParams Params;
	
	public GetGameRoundReq(int userId, String bet365GameRoundId) {
		Params = new GetGameRoundParams(userId, bet365GameRoundId);
	}
	
	class GetGameRoundParams {
		
		@SuppressWarnings("unused")
		private int user_id;
		@SuppressWarnings("unused")
		private String bet365_game_round_id;
		
		public GetGameRoundParams(int userId, String bet365GameRoundId) {
			this.user_id = userId;
			this.bet365_game_round_id = bet365GameRoundId;
		}
	}

}
