package tests.gameroundservice.request;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import common.BaseURI;
import common.TimeUtils;
import common.enumsconstants.ServiceErrors;
import domain.BaseRequest;
import tests.gameroundservice.enums.GameRoundEndpoints;
import tests.gameroundservice.response.GameRoundResp;
import tests.gameroundservice.response.InsertRngDetailsResp;

public class GameRoundRequest extends BaseRequest {

	public static GameRoundResp createGameRound(int requestedUserId, String requestedPartnerGameRoundId, int requestedPartnerId, int requestedRegulatedGameId, int requestedProviderRegionId, int channelId) {
		assertThatGameRoundDoesNotAlreadyExist(requestedUserId,
				requestedPartnerId,
				requestedProviderRegionId,
				requestedPartnerGameRoundId);

		String currentTime = TimeUtils.getCurrentTimeAsIsoString();

		CreateGameRoundReq request = new CreateGameRoundReq(requestedUserId,
				requestedPartnerGameRoundId,
				requestedPartnerId,
				requestedRegulatedGameId,
				requestedProviderRegionId,
				channelId,
				currentTime);

		GameRoundResp response = BaseRequest.post(request, GameRoundEndpoints.createGameRound, BaseURI.GAME_ROUND_SERVICE);

		return response;
	}

	public static GameRoundResp createGameRound(int requestedUserId, String requestedPartnerGameRoundId, int requestedPartnerId, int requestedRegulatedGameId, int requestedProviderRegionId) {

		int channelId = 0;
		GameRoundResp response = createGameRound(requestedUserId, requestedPartnerGameRoundId, requestedPartnerId, requestedProviderRegionId, requestedRegulatedGameId, channelId);

		return response;
	}

	public static void assertThatGameRoundDoesNotAlreadyExist(int requestedUserId, int requestedPartnerId, int requestedProviderRegionId, String requestedPartnerGameRoundId) {

		GameRoundResp response = getGameRoundByPartnerGameRoundId(requestedUserId, requestedPartnerGameRoundId, requestedPartnerId, requestedProviderRegionId);
		GameRoundResp expResp =  new GameRoundResp(ServiceErrors.GameRound.GAME_ROUND_NOT_FOUND);

		assertReflectionEquals(expResp, response);
	}

	public static GameRoundResp closeGameRoundBybet365GameRoundId(GameRoundResp gameRoundResp) {
		CloseGameRoundByBet365GameRoundIdReq request = new CloseGameRoundByBet365GameRoundIdReq(gameRoundResp);
		GameRoundResp response = BaseRequest.post(request, GameRoundEndpoints.closeGameRoundByBet365GameRoundId, BaseURI.GAME_ROUND_SERVICE);

		return response;
	}

	public static GameRoundResp getGameRoundById(int gameRoundId) {
		GetGameRoundByIdReq request = new GetGameRoundByIdReq(gameRoundId);
		GameRoundResp response = BaseRequest.post(request, GameRoundEndpoints.getGameRoundById);

		return response;
	}

	public static GameRoundResp getGameRound(int userId, String bet365GameRoundId) {
		GetGameRoundReq request = new GetGameRoundReq(userId, bet365GameRoundId);
		GameRoundResp response = BaseRequest.post(request, GameRoundEndpoints.getGameRound);

		return response;
	}

	public static GameRoundResp getGameRoundByPartnerGameRoundId(int userId, String partnerGameRoundId, int partnerId, int providerRegionId) {
		GetGameRoundByPartnerGameRoundIdReq request = new GetGameRoundByPartnerGameRoundIdReq(userId, partnerGameRoundId, partnerId, providerRegionId);
		GameRoundResp response = BaseRequest.post(request, GameRoundEndpoints.getGameRoundByPartnerGameRoundId, BaseURI.GAME_ROUND_SERVICE);

		return response;
	}

	public static InsertRngDetailsResp insertRngDetails(long gameRoundId) {
		InsertRngDetailsReq request = new InsertRngDetailsReq(gameRoundId);
		InsertRngDetailsResp response = BaseRequest.post(request, GameRoundEndpoints.insertRngDetails);

		return response;
	}
}
