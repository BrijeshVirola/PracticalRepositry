package tests.gameroundservice.request;

public class CreateGameRoundReq {
	
	@SuppressWarnings("unused")
	private String Method = "creategameround";
	@SuppressWarnings("unused")
	private String id = "1";
	@SuppressWarnings("unused")
	private GameRoundParams Params;
	
	public CreateGameRoundReq(int requestedUserId,
			String partnerGameRoundId,
			int requestedPartnerId,
			int requestedRegulatedGameId,
			int requestedProviderRegionId,
			int channelId,
			String currentTime) {
		
		Params = new GameRoundParams(requestedUserId,
				partnerGameRoundId,
				requestedPartnerId,
			    requestedRegulatedGameId,
				requestedProviderRegionId,
				channelId,
				currentTime);
	}
	
	class GameRoundParams {
		
		@SuppressWarnings("unused")
		private int user_id, partner_id, regulated_game_id, provider_region_id, channel_id;
		@SuppressWarnings("unused")
		private String partner_game_round_id, partner_start_timestamp_utc;
		
		public GameRoundParams(int requestedUserId,
				String partnerGameRoundId,
				int requestedPartnerId,
				int requestedRegulatedGameId,
				int requestedProviderRegionId,
				int channelId,
				String currentTime) {
			
			this.user_id = requestedUserId;
			this.partner_game_round_id = partnerGameRoundId;
			this.partner_id = requestedPartnerId;
			this.regulated_game_id = requestedRegulatedGameId;
			this.provider_region_id = requestedProviderRegionId;
			this.channel_id = channelId;
			this.partner_start_timestamp_utc = currentTime;
		}
	}
}
