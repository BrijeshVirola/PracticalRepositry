package tests.gameroundservice.request;


public class InsertRngDetailsReq {
	
	@SuppressWarnings("unused")
	private String Method = "insertrngdetails";
	@SuppressWarnings("unused")
	private String id = "1";
	@SuppressWarnings("unused")
	private InsertRngDetailsParams Params;
	
	public InsertRngDetailsReq(long gameRoundId) {
		Params = new InsertRngDetailsParams(gameRoundId);
	}
	
	class InsertRngDetailsParams {
		
		@SuppressWarnings("unused")
		private long game_round_id;
		@SuppressWarnings("unused")
		private String rng_id = "rgn_id_test", software_id = "rng_softwareid_test";
		
		public InsertRngDetailsParams(long gameRoundId) {
			this.game_round_id = gameRoundId;
		}
	}

}
