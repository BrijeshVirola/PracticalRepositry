package tests.gamesservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.ExpectedFailure;
import domain.BaseRequest;
import tests.gamesservice.enums.GameEndpoints;
import tests.gamesservice.request.GetRegulatedGamesByGameIdReq;
import tests.gamesservice.response.GetRegulatedGamesByGameIdResp;
import tests.gamesservice.responseobjects.RegulatedGame;

public class GetRegulatedGamesByGameIdTests extends BaseClassSetup {


	@Test(description = "Make a valid request to get GetRegulatedGamesByGameId")
	public void GivenValidRequestForAKnownGetRegulatedGamesByGameId_WhenGetRegulatedGameByGameId_ThenASuccessResponseIsReceived() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)			
				.build();

		RegulatedGame regulatedGame = new RegulatedGame.Builder()
				.defaults()
				.regulatedGameId(59)
				.gameId(28)
				.regulatedZoneId(1)
				.providerGameReference("eas")
				.privateParterGameId("eas")
				.regulatoryGameReference("0")
				.providerRegionId(3)
				.productId(4)
				.platformTypeId(1)
				.cmsCoreGameId(2014)
				.partnerId(28)
				.gamePlayTechnologyId(1)
				.providerId(3)
				.gameName("Easter Surprise")
				.isMultistage(false)
				.bonusGameType("G")
				.returnDelayInSeconds(0)
				.isVisible(true)
				.providerImplementationId(72)
				.build();

		GetRegulatedGamesByGameIdResp expectedResponse = new GetRegulatedGamesByGameIdResp.Builder()
				.defaults()
				.addGame(regulatedGame)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetRegulatedGamesByGameIdResp actualResponse = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request with wrong method in the body for GetRegulatedGamesByGameId - Error code 6")
	public void GetRegulatedGamesByGameId_Wrong_Method() {

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD")
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}

	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2716", action = "test disabled due to return of unexpected error handled code and message")
	@Test(enabled = false, description ="Make a request with missing parameter from params object for GetRegulatedGamesByGameId - Error code 7")
	public void GetRegulatedGamesByGameId_Missing_Param_gameId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.gameId(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: game_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}

	@Test(description = "Make a request with missing parameter from params object for GetRegulatedGamesByGameId - Error code 7")
	public void GetRegulatedGamesByGameId_Missing_Param_providerId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerId(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: provider_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}

	@Test(description = "Make a request with missing parameter from params object for GetRegulatedGamesByGameId - Error code 7")
	public void GetRegulatedGamesByGameId_Missing_Param_providerRegionId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerRegionId(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: provider_region_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}

	@Test(description = "Make a request with missing parameter from params object for GetRegulatedGamesByGameId - Error code 7")
	public void GetRegulatedGamesByGameId_Missing_Param_productId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.productId(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}


	@Test(description = "Make a request with missing parameter from params object for GetRegulatedGamesByGameId - Error code 7")
	public void GetRegulatedGamesByGameId_Missing_Param_regulatedZoneId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.regulatedZoneId(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: regulated_zone_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}

}
