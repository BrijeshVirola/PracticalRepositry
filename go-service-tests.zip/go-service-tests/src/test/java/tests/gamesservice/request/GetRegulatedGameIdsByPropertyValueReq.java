package tests.gamesservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetRegulatedGameIdsByPropertyValueReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private GetRegulatedGameIdsByPropertyValueReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("product_id", builder.product_id);
		this.params.put("language_id", builder.language_id);
		this.params.put("property_id", builder.property_id);
		this.params.put("property_value", builder.property_value);
	}

	public static class Builder {
		private Integer product_id, language_id, property_id;
		private String id, method, property_value;

		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder productId(Integer productId) {
			this.product_id = productId;
			return this;
		}

		public Builder languageId(Integer languageId) {
			this.language_id = languageId;
			return this;
		}

		public Builder propertyId(Integer propertyId) {
			this.property_id = propertyId;
			return this;
		}

		public Builder propertyValue(String propertyValue) {
			this.property_value = propertyValue;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.method = "getregulatedgameidsbypropertyvalue";
			this.product_id = 1;
			this.language_id = 1;
			this.property_id = 1;
			this.property_value = "IsVisible";
			return this;
		}

		public GetRegulatedGameIdsByPropertyValueReq build() {
			return new GetRegulatedGameIdsByPropertyValueReq(this);
		}
	}
}
