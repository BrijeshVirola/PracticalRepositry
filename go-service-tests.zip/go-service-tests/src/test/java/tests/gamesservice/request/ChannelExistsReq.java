package tests.gamesservice.request;

import java.util.HashMap;
import java.util.Map;

public class ChannelExistsReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Integer channel_id;
	
	private Map<String, Object> params = new HashMap<>();
	
	private ChannelExistsReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("channel_id", builder.channel_id);
	}

	public static class Builder {
		private String method;
		private String id;
		private Integer channel_id;
		
		public Builder channelId(Integer channel_id) {
			this.channel_id = channel_id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		public Builder defaults() {
			this.method  = "channelexists";
			this.id = "1";
			return this;
		}
		
		public ChannelExistsReq build() {
			return new ChannelExistsReq(this);
		}
	}
}
