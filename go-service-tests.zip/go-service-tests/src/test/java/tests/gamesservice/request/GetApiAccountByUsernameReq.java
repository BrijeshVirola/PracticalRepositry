package tests.gamesservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetApiAccountByUsernameReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String userName;
	
	private Map<String, Object> params = new HashMap<>();
	
	private GetApiAccountByUsernameReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("userName", builder.userName);
	}

	public static class Builder {
		private String method;
		private String id;
		private String userName;
		
		public Builder userName(String userName) {
			this.userName = userName;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		public Builder defaults() {
			this.method  = "getapiaccountbyusername";
			this.id = "1";
			return this;
		}
		
		public GetApiAccountByUsernameReq build() {
			return new GetApiAccountByUsernameReq(this);
		}
	}
}
