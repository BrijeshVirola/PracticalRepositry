package tests.gamesservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetIgpReportingGamesDataReq {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String method;

	private Map<String, Object> params = new HashMap<>();

	private GetIgpReportingGamesDataReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("provider_game_reference", builder.provider_game_reference);
		this.params.put("provider_implementation_group_id", builder.provider_implementation_group_id);
		this.params.put("regulated_zone_id", builder.regulated_zone_id);
	}

	public static class Builder {
		private String id;
		private String method;
		private String provider_game_reference;
		private Integer provider_implementation_group_id;
		private Integer regulated_zone_id;

		public Builder providerGameReference(String provider_game_reference) {
			this.provider_game_reference = provider_game_reference;
			return this;
		}

		public Builder providerImplementationGroupId(Integer provider_implementation_group_id) {
			this.provider_implementation_group_id = provider_implementation_group_id;
			return this;
		}

		public Builder regulatedZoneId(Integer regulated_zone_id) {
			this.regulated_zone_id = regulated_zone_id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder defaults() {
			this.method = "GetIgpReportingGamesData";
			this.provider_game_reference = "CogenaWhiteLabelGMItalyTestGameA";
			this.provider_implementation_group_id = 10;
			this.regulated_zone_id = 2;
			return this;
		}

		public GetIgpReportingGamesDataReq build() {
			return new GetIgpReportingGamesDataReq(this);
		}
	}
}
