package tests.gamesservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetRegulatedGamesByPrivatePartnerGameIdReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private GetRegulatedGamesByPrivatePartnerGameIdReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("private_partner_game_id", builder.private_partner_game_id);
		this.params.put("provider_id", builder.provider_id);
		this.params.put("provider_region_id", builder.provider_region_id);
		this.params.put("product_id", builder.product_id);
		this.params.put("regulated_zone_id", builder.regulated_zone_id);
	}

	public static class Builder {
		private Integer provider_id, provider_region_id, product_id, regulated_zone_id;
		private String id, method, private_partner_game_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder productId(Integer productId) {
			this.product_id = productId;
			return this;
		}

		public Builder privatePartnerGameId(String private_partner_game_id) {
			this.private_partner_game_id = private_partner_game_id;
			return this;
		}

		public Builder providerId(Integer provider_id) {
			this.provider_id = provider_id;
			return this;
		}

		public Builder providerRegionId(Integer provider_region_id) {
			this.provider_region_id = provider_region_id;
			return this;
		}
		
		public Builder regulatedZoneId(Integer regulated_zone_id) {
			this.regulated_zone_id = regulated_zone_id;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.method = "getregulatedgamesbyprivatepartnergameid";
			this.regulated_zone_id = 1;
			this.private_partner_game_id = "gpas_gogold_pop";
			this.provider_region_id = 3;
			this.product_id	= 22;
			this.provider_id = 3;
			return this;
		}

		public GetRegulatedGamesByPrivatePartnerGameIdReq build() {
			return new GetRegulatedGamesByPrivatePartnerGameIdReq(this);
		}
	}
}
