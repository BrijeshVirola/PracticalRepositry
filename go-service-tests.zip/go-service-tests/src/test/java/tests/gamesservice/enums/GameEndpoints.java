package tests.gamesservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.gamesservice.response.ChannelExistsResp;
import tests.gamesservice.response.GetApiAccountByUsernameResp;
import tests.gamesservice.response.GetChannelsByPartnerIdResp;
import tests.gamesservice.response.GetCurrencyCodeExcludedRegulatedGameIdsResp;
import tests.gamesservice.response.GetGamesPartnerByPartnerHashResp;
import tests.gamesservice.response.GetIgpReportingGamesDataResp;
import tests.gamesservice.response.GetProductGamesByGameTokenResp;
import tests.gamesservice.response.GetRegulatedGameByIdResp;
import tests.gamesservice.response.GetRegulatedGameIdsByPropertyValueResp;
import tests.gamesservice.response.GetRegulatedGamesByGameIdResp;
import tests.gamesservice.response.GetRegulatedZoneByCountryGroupIdResp;
import tests.gamesservice.response.ListOfRegulatedGamesResp;

public enum GameEndpoints implements ResponseEndpoints {

	getGamesPartnerByPartnerHashSuccess(GetGamesPartnerByPartnerHashResp.class, "GetGamesPartnerByPartnerHash"),
	getGamesPartnerByPartnerHashError(CustomErrorResponse.class, "GetGamesPartnerByPartnerHash"),
	getRegulatedGameByIdSuccess(GetRegulatedGameByIdResp.class, "GetRegulatedGameById"),
	getRegulatedGameByIdError(CustomErrorResponse.class, "GetRegulatedGameById"),
	getRegulatedGamesByProviderGameReferenceSuccess(ListOfRegulatedGamesResp.class, "GetRegulatedGamesByProviderGameReference"),
	getRegulatedGamesByProviderGameReferenceError(CustomErrorResponse.class, "GetRegulatedGamesByProviderGameReference"),
	getRegulatedGameIdsByPropertyValueSuccess(GetRegulatedGameIdsByPropertyValueResp.class, "GetRegulatedGameIdsByPropertyValue"),
	getRegulatedGameIdsByPropertyValueError(CustomErrorResponse.class, "GetRegulatedGameIdsByPropertyValue"),
	getRegulatedZoneByCountryGroupIdSuccess(GetRegulatedZoneByCountryGroupIdResp.class, "GetRegulatedZoneByCountryGroupId"),
	getRegulatedZoneByCountryGroupIdError(CustomErrorResponse.class, "GetRegulatedZoneByCountryGroupId"),
	getApiAccountByUsernameSuccess(GetApiAccountByUsernameResp.class, "GetApiAccountByUsername"),
	getApiAccountByUsernameError(CustomErrorResponse.class, "GetApiAccountByUsername"),
	channelExistsSuccess(ChannelExistsResp.class, "ChannelExists"),
	channelExistsError(CustomErrorResponse.class, "ChannelExists"),
	getChannelsByPartnerIdSuccess(GetChannelsByPartnerIdResp.class, "GetChannelsByPartnerId"),
	getChannelsByPartnerIdError(CustomErrorResponse.class, "GetChannelsByPartnerId"),
	getRegulatedGamesByPrivatePartnerGameIdSuccess(ListOfRegulatedGamesResp.class, "GetRegulatedGamesByPrivatePartnerGameId"),
	getRegulatedGamesByPrivatePartnerGameIdError(CustomErrorResponse.class, "GetRegulatedGamesByPrivatePartnerGameId"),
	getCurrencyCodeExcludedRegulatedGameIdsSuccess(GetCurrencyCodeExcludedRegulatedGameIdsResp.class, "GetCurrencyCodeExcludedRegulatedGameIds"),
	getCurrencyCodeExcludedRegulatedGameIdsError(CustomErrorResponse.class, "GetCurrencyCodeExcludedRegulatedGameIds"),
	getProductGamesByGameTokenSuccess(GetProductGamesByGameTokenResp.class, "GetProductGamesByGameToken"),
	getProductGamesByGameTokenError(CustomErrorResponse.class, "GetProductGamesByGameToken"),
	getRegulatedGamesByGameIdSuccess(GetRegulatedGamesByGameIdResp.class, "GetRegulatedGamesByGameId"),
	getRegulatedGamesByGameIdError(CustomErrorResponse.class, "GetRegulatedGamesByGameId"),
	getIgpReportingGamesDataSuccess(GetIgpReportingGamesDataResp.class, "GetIgpReportingGamesData"),
	getIgpReportingGamesDataError(CustomErrorResponse.class, "GetIgpReportingGamesData");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> GameEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
