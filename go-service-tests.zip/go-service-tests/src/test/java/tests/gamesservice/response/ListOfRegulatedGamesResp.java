package tests.gamesservice.response;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import tests.gamesservice.responseobjects.RegulatedGame;

public class ListOfRegulatedGamesResp {

	@SuppressWarnings("unused")
	private String id;
	private Map<String, ArrayList<RegulatedGame>> result = new HashMap<>();

	private ListOfRegulatedGamesResp(Builder builder) {
		this.id = builder.id;
		this.result.put("regulated_games", builder.regulated_games);
	}

	public static class Builder {
		private String id;
		private ArrayList<RegulatedGame> regulated_games;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addGame(RegulatedGame game) {
			regulated_games.add(game);
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.regulated_games = new ArrayList<RegulatedGame>();
			return this;
		}
	
		public ListOfRegulatedGamesResp build() {
			return new ListOfRegulatedGamesResp(this);
		}
	}
}
