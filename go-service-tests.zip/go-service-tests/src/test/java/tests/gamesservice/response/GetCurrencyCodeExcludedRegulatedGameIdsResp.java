package tests.gamesservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetCurrencyCodeExcludedRegulatedGameIdsResp {

	@SuppressWarnings("unused")
	private String id;
	private Map<String, Object> result = new HashMap<>();

	private GetCurrencyCodeExcludedRegulatedGameIdsResp(Builder builder) {
		this.id = builder.id;
		this.result.put("regulated_game_ids", builder.regulated_game_ids);
	}

	public static class Builder {
		private String id;
		private Integer[] regulated_game_ids;

		public Builder regulatedGameIds(Integer[] regulated_game_ids) {
			this.regulated_game_ids = regulated_game_ids;
			return this;
		}
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.regulated_game_ids = new Integer[] { 6780, 6795, 6801, 6804, 6819, 6831, 6840, 6843, 6866, 6880, 6883, 6886, 6889,
					6895, 6901, 6913, 6930, 6938, 6941, 6944, 6949, 6955, 6967, 6973, 6976, 6989, 6995, 7010, 7013,
					7051, 7085, 7129, 7134, 7141, 7153, 7156, 7159, 7162, 7168, 7174, 7180, 7183, 7195, 7201, 7204,
					7210, 7263, 7270, 7272, 7278, 7283, 7289, 7301, 7304, 7307, 7310, 7327, 7330, 7358, 7379, 7382,
					7394, 7400, 7417, 7434, 7438, 7440, 7447, 7465, 7468, 7474, 7477, 7483, 7515, 7518, 7523, 7527,
					7539, 7545, 7548, 7553, 7557, 7563, 7577, 7580, 7587, 7593, 7608, 7611, 7642, 7646, 7660 };
			return this;
		}

		public GetCurrencyCodeExcludedRegulatedGameIdsResp build() {
			return new GetCurrencyCodeExcludedRegulatedGameIdsResp(this);
		}
	}
}
