package tests.gamesservice.response;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tests.gamesservice.responseobjects.GetProductGamesByGameTokenGame;

public class GetProductGamesByGameTokenResp {

	@SuppressWarnings("unused")
	private String id;
	private Map<String, List<GetProductGamesByGameTokenGame>> result = new HashMap<>();

	private GetProductGamesByGameTokenResp(Builder builder) {
		this.id = builder.id;
		this.result.put("games", builder.games);
		
	}

	public static class Builder {
		private String id;
		private ArrayList<GetProductGamesByGameTokenGame> games = new ArrayList<GetProductGamesByGameTokenGame>();

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addGame(GetProductGamesByGameTokenGame game) {
			games.add(game);
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			return this;
		}

		public GetProductGamesByGameTokenResp build() {
			GetProductGamesByGameTokenResp result = new GetProductGamesByGameTokenResp(this);
			return result;
		}
	}
}
