package tests.gamesservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.util.UUID;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamesservice.enums.GameEndpoints;
import tests.gamesservice.request.GetIgpReportingGamesDataReq;
import tests.gamesservice.response.GetIgpReportingGamesDataResp;

public class GetIgpReportingGamesDataTests extends BaseClassSetup{

	@DataProvider(name = "GetIgpReportingGamesDataFailure")
	public Object[][] GetIgpReportingGamesDataFailure() {
		return new Object[][] {
			{""}, {"c-E5xKzHMu4WrDK5Bzbq#3.P/WL5JzEm2&LGCzdjdviq/AheTcvB.)BxPCqBC.TU_FAx:#Qh;K%*_V5&;:*9AHT(haAHAvV$6}Ba)6Y{MnE.}nm&t%7EL5a+F/F@(hg-M:?-$c2Vp];[dNM)2_(g6{jg!Ek(4;.Gi-ZpA&kf&9@rk)2.iN?G(YGimtvCW5(%?VGL]Wkn-K{Sfet*?i/h$uMeGf[4eFR_ASqbfSH]%)8m3RG6pSz$dM53FSv3G.X-N6QEL%2;R56ua?T8Pv}y}_!=4WmtY@K)cS&5UKJ+99xKU}HbX=VnmyHQxn@uEe]Vb{FXcW!Q*=}K*w*ud&}/m?BvDNBZXWUr[dVVbw#69V}#RX]DMyJx!2ytxGRn{aWM{F=;q],uUg_HYvT@UVQ]A;a(Aywiei.XYM-rHkZ:YPphcWt+/QeVdT}p)P=gh3t)(QB[,kxXkw2U{8ZGyG-=8FR*ZC6qaN6AwE*C=8G&;2#[=X/[h+/C&w%b3r@:n)=.MC;T6ir{U.jiv=Mx$*R?vn$UYFf=X23[?J&Nx,%NEQ:)PAQf?A&)UZ*(&,yD=r/;B/_tn_h#M&tQk4wn&k}9{$Vb7*!:gF(Eci,HQ*)z)6:%7JZYf+hgj9um&4p}e)Y%GKtNi6!!N,P,)4?k,!Vd;}XA(Ng-?AuvzuG7x&_Q]qU}wi!7!8y;Vg_MhuM@FRjhVrdXfqqY[:RX@L7S#W$.%B?jead8X{A/yK?FMy4)i;peYASc-_5T8$#yk3c)%*!!DNwQvU7E2gafYxq7-]S_7K.688vZu}6N6{*U,aSZiv{J.4=zJab:b4#agGGk@emw7B9UM?5-($?f${kFU!8Az3#PmQ/i&4=z4]?}_3tx!&#}hm4kV;{&8wQW#%nhp.GEh:hgURQ(LJp46{uwmj3_=Fc_a9MgipLZ&E)&*)5TgGj#KMfUfyBM+?MZb&z2X2(NSpDmV$wEE{ck/D]rPp6Jbiv@5Y#E[*{{bErk2u]hV!,CVt;M{_Ju(VkYG6m7jXKeDJhY3N4Z3jt3*ncS2=w2%b7,Mhvv}.JXN$.M(kZ*kV-m(V4ypL()*iXp4TugpY.7HaRC-(?Qx7AD3]7n2f2B;3,66tFxC2P@jr3dhv7RHE/jR=]449QV#v,h!+X[4))YPuP7trG7,D-m/R:Rr;::!cwWGJ)%BY_a{Q$n[Y,mTJ-UtpZ,jn.Mi:}uT/Viw//ri](inYz?CY/ztjR/W?*}3-!.}]_vh}.Dd9#R78z}dZb[$R)WR3J=.VAM5V}Z.:a@=(/y9%]8S8/v(viQ]8ka6@-HL;*x5UJ62]9a*3vL%L75tyCuYM+.5rTt}(6.PPWC]9rty+Lb69hg_w6/,6nxhK+EB{wn%SRAJAPzeUFhQ=F,?.v6JZM{+4pqC*q%PpQ%2kjmRk9Ypv_c+v2&jSvnTw9i4U?)]HGvwkZdHM)th[#PgHaq)Uvy:]n2(f:]S5NnR[[QfQJ;rece@f9P,g[Z,2=qJa9#!F-_j.?Sw*mj*YC5_yAP52Lfk,;B}j8e,tj-Wm!24E6wg85w.-cEXQ$jvL&qrgYM8nHkAuDw2,RB]BH}]Bq[h=G(cCT]:mzXeGaDb68:R,998ndJ[qm[DF3AAbuJ.?dj}M9-9z,AUS:j:nar=79.&&gj*b=tyqHM)EuDC2kUPRZVYdC!gab[D/M%FyrBcnhShUt#fSxL4D#!y%Wbg,WFP}h!9AS5nn7gcXhENy@r[3tGQ-(aS8r}{T2pd$-%&JaT-({#UNF=@a[5wNydwyX?8d4n2%QaCY#CzJvb#;ydTkQQ%},z9/yRxjL(mG+K5gx8+Vk[Fv66D{$jb%gj.wb4bUQMU#%/nM%D5+!m*/Jr!y/5!ScHf/}(59[GQ4n9mCYTz.E.T3@,q?V?+!58ddJZ2*knCQVpuSQ*tnx3Vt*n=@AeBBDqJ-xJ%69J8Q3}ekw)YZFwQ7X(LayS8@zVq&.xyF(hEGWSdG#N%h)FCP)4LidD?fTN%SRZ+"},		
		};
	}

	@Test(description = "Make a valid request to get GetIgpReportingGamesData - Positve Scenario")
	public void GetIgpReportingGamesData_Positive_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetIgpReportingGamesDataReq request = new GetIgpReportingGamesDataReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetIgpReportingGamesDataResp expResponse =  new GetIgpReportingGamesDataResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetIgpReportingGamesDataResp actResponse =  BaseRequest.post(request, GameEndpoints.getIgpReportingGamesDataSuccess);

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to GetIgpReportingGamesData. Missing provider_game_reference parameter. Negative Scenario")
	public void GetIgpReportingGamesData_Missing_Provider_Game_Reference_Param() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetIgpReportingGamesDataReq request = new GetIgpReportingGamesDataReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerGameReference(null)
				.build();

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1009)
				.message("Invalid parameter: provider_game_reference must be between 1 and 2000 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(request, GameEndpoints.getIgpReportingGamesDataError);

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to GetIgpReportingGamesData. Missing provider_implementation_group_id parameter. Negative Scenario")
	public void GetIgpReportingGamesData_Missing_Provider_Implementation_Group_Id_Param() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetIgpReportingGamesDataReq request = new GetIgpReportingGamesDataReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerImplementationGroupId(null)
				.build();

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: provider_implementation_group_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(request, GameEndpoints.getIgpReportingGamesDataError);

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to GetIgpReportingGamesData. Missing regulated_zone_id parameter. Negative Scenario")
	public void GetIgpReportingGamesData_Missing_Regulated_Zone_Id_Param() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetIgpReportingGamesDataReq request = new GetIgpReportingGamesDataReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.regulatedZoneId(null)
				.build();

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: regulated_zone_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(request, GameEndpoints.getIgpReportingGamesDataError);

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to GetIgpReportingGamesData. Wrong method.")
	public void GetIgpReportingGamesData_Wrong_Method() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetIgpReportingGamesDataReq request = new GetIgpReportingGamesDataReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();   	

		CustomErrorResponse actualError =  BaseRequest.post(request, GameEndpoints.getIgpReportingGamesDataError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to GetIgpReportingGamesData. Invalid provider_game_reference parameter - Game Not Found. Negative Scenario")
	public void GetIgpReportingGamesData_Invalid_Provider_Game_Reference_Game_Not_Found_Param() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetIgpReportingGamesDataReq request = new GetIgpReportingGamesDataReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerGameReference("abc")
				.build();

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1006)
				.message("Game not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(request, GameEndpoints.getIgpReportingGamesDataError);

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to GetIgpReportingGamesData. Invalid provider_implementation_group_id parameter. Negative Scenario")
	public void GetIgpReportingGamesData_Invalid_Provider_Implementation_Group_Id_Param() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetIgpReportingGamesDataReq request = new GetIgpReportingGamesDataReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerImplementationGroupId(20)
				.build();

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1006)
				.message("Game not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(request, GameEndpoints.getIgpReportingGamesDataError);

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to GetIgpReportingGamesData. Invalid regulated_zone_id parameter. Negative Scenario")
	public void GetIgpReportingGamesData_Invalid_Regulated_Zone_Id_Param() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetIgpReportingGamesDataReq request = new GetIgpReportingGamesDataReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.regulatedZoneId(5)
				.build();

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1006)
				.message("Game not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(request, GameEndpoints.getIgpReportingGamesDataError);

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to GetIgpReportingGamesData. Out of range provider_game_reference parameter. Negative Scenario", dataProvider = "GetIgpReportingGamesDataFailure")
	public void GetIgpReportingGamesData_Out_Of_Range_Provider_Game_Reference_Param(String provider_game_reference) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetIgpReportingGamesDataReq request = new GetIgpReportingGamesDataReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerGameReference(provider_game_reference)
				.build();

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1009)
				.message("Invalid parameter: provider_game_reference must be between 1 and 2000 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(request, GameEndpoints.getIgpReportingGamesDataError);

		assertReflectionEquals(expectedError, actualError);
	}
}
