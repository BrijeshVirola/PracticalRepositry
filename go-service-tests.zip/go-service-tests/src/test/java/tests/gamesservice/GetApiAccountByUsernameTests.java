package tests.gamesservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamesservice.enums.GameEndpoints;
import tests.gamesservice.request.GetApiAccountByUsernameReq;
import tests.gamesservice.response.GetApiAccountByUsernameResp;

public class GetApiAccountByUsernameTests extends BaseClassSetup{

	@Test(description = "Make a request to get api account details by username")
	public void getApiAccountByUsername_Postitive_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetApiAccountByUsernameReq request = new GetApiAccountByUsernameReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userName("OnseoUser")
				.build();

		GetApiAccountByUsernameResp actResp = BaseRequest.post(request, GameEndpoints.getApiAccountByUsernameSuccess);

		GetApiAccountByUsernameResp expResp = new GetApiAccountByUsernameResp.Builder()
				.defaults()
				.idInMainBodySection(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expResp, actResp);
	}

	@Test(description = "Make a request with missing parameter from params object for GetApiAccountByUsername - Error code 7")
	public void getApiAccountByUsername_Missing_Param() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetApiAccountByUsernameReq request = new GetApiAccountByUsernameReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userName(null)
				.build();

		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: username")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actError =  BaseRequest.post(request, GameEndpoints.getApiAccountByUsernameError);

		assertReflectionEquals(expError, actError);
	}

	@Test(description = "Make a request with unknown username in the body for GetApiAccountByUsername - Error code 1001")
	public void getApiAccountByUsername_api_Account_Not_Found() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetApiAccountByUsernameReq request = new GetApiAccountByUsernameReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userName("UNKNOWN_USER")
				.build();

		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(1001)
				.message("Api account was not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actError =  BaseRequest.post(request, GameEndpoints.getApiAccountByUsernameError);

		assertReflectionEquals(expError, actError);
	}

	@Test(description = "Make a request with too long username in the body for GetApiAccountByUsername - Error code 1002")
	public void getApiAccountByUsername_username_Too_Long() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetApiAccountByUsernameReq request = new GetApiAccountByUsernameReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userName("OnseoUserdafadfdafadfdafd1")
				.build();

		CustomErrorResponse actError =  BaseRequest.post(request, GameEndpoints.getApiAccountByUsernameError);

		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Supplied username is too long (25 chars max)")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expError, actError);
	}

	@Test(description = "Make a request with wrong method in the body for GetApiAccountByUsername - Error code 6")
	public void getApiAccountByUsername_Wrong_Method() {

		GetApiAccountByUsernameReq request = new GetApiAccountByUsernameReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD")
				.build();

		CustomErrorResponse actError =  BaseRequest.post(request, GameEndpoints.getApiAccountByUsernameError);

		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expError, actError);
	}
}
