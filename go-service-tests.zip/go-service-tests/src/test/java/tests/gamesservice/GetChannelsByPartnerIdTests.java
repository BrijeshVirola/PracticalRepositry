package tests.gamesservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamesservice.enums.GameEndpoints;
import tests.gamesservice.request.GetChannelsByPartnerIdReq;
import tests.gamesservice.response.GetChannelsByPartnerIdResp;

public class GetChannelsByPartnerIdTests extends BaseClassSetup {

	@DataProvider(name = "getChannelsByPartnerId")
	private Object[][] getChannelsByPartnerId() {
		return new Object[][] {
			{139, new Integer[] {10046, 10050, 10056, 10057, 10058, 10062, 10063, 10064, 10065, 10066, 10067, 10068, 10069}},
			{140, new Integer[] {10047}},
			{45, new Integer[] {9998, 9999}},
			{46, new Integer[] {10000, 10001}},
			{100, new Integer[] {10002, 10003}},
			{101, new Integer[] {10004, 10005}},
			{102, new Integer[] {10006, 10007}},
			{103, new Integer[] {10008, 10009}},
			{114, new Integer[] {10010}},
			{115, new Integer[] {10011}},
		};
	}

	@Test(description = "Make a request to get channels by partner id username", dataProvider = "getChannelsByPartnerId")
	public void getChannelsByPartnerId_Positive_Scenario(int partnerId, Integer[] resultChannels) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetChannelsByPartnerIdReq request = new GetChannelsByPartnerIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.partnerId(partnerId)
				.build();

		GetChannelsByPartnerIdResp expResponse =  new GetChannelsByPartnerIdResp.Builder()
				.id(idForRequestToBeEchoedBackInResponseId)
				.result(resultChannels)
				.build();

		GetChannelsByPartnerIdResp actResponse =  BaseRequest.post(request, GameEndpoints.getChannelsByPartnerIdSuccess);

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request with missing parameter from params object for getChannelsByPartnerId - Error code 7")
	public void getChannelsByPartnerId_Missing_Param() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetChannelsByPartnerIdReq request = new GetChannelsByPartnerIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.partnerId(null)
				.build();

		CustomErrorResponse actError = BaseRequest.post(request, GameEndpoints.getChannelsByPartnerIdError);
		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: partner_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expError, actError);
	}

	@Test(description = "Make a request with wrong method in the body for getChannelsByPartnerId - Error code 6")
	public void getChannelsByPartnerId_Wrong_Method() {

		GetChannelsByPartnerIdReq request = new GetChannelsByPartnerIdReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actError =  BaseRequest.post(request, GameEndpoints.getChannelsByPartnerIdError);
		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expError, actError);
	}

}
