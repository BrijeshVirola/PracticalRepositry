package tests.gamesservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamesservice.enums.GameEndpoints;
import tests.gamesservice.request.GetRegulatedGameByIdReq;
import tests.gamesservice.response.GetRegulatedGameByIdResp;
import tests.gamesservice.responseobjects.RegulatedGame;

public class GetRegulatedGameByIdTests extends BaseClassSetup {


	@Test(description = "Make a valid request to get GetRegulatedGameById with a known regulated game id")
	public void GivenValidRequestForAKnownRegulatedGameId_WhenGetRegulatedGameById_ThenASuccessResponseIsReceived() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGameByIdReq requestBody = new GetRegulatedGameByIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		RegulatedGame game = new RegulatedGame.Builder()
				.defaults()
				.build();

		GetRegulatedGameByIdResp expectedResponce = new GetRegulatedGameByIdResp.Builder()
				.defaults()
				.addGame(game)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetRegulatedGameByIdResp actualResponse = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGameByIdSuccess);

		assertReflectionEquals(expectedResponce, actualResponse);
	}

	@Test(description = "Make a request with wrong method in the body for GetRegulatedGameById - Error code 6")
	public void GetRegulatedGameById_Wrong_Method() {

		GetRegulatedGameByIdReq requestBody = new GetRegulatedGameByIdReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD")
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGameByIdError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}

	@Test(description = "Make a request with missing parameter from params object for GetRegulatedGameById - Error code 7")
	public void GetRegulatedGameById_Missing_Param() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGameByIdReq requestBody = new GetRegulatedGameByIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.regulatedGameId(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGameByIdError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: regulated_game_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}

	@Test(description = "Make a request with a game which is unknown for GetRegulatedGameById - Error code 1006")
	public void GetRegulatedGameById_Unknown_GameId() {

		Integer unknownRegulatedGameId = 999999;
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGameByIdReq requestBody = new GetRegulatedGameByIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.regulatedGameId(unknownRegulatedGameId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGameByIdError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1006)
				.message("Game not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}

}
