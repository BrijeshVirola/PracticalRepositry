package tests.prizeservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.prizeservice.response.GetPrizeResp;
import tests.prizeservice.response.InsertPrizeResp;

public enum PrizeEndpoints implements ResponseEndpoints {

	insertPrizeSuccess(InsertPrizeResp.class, "InsertPrize"),
	insertPrizeError(CustomErrorResponse.class, "InsertPrize"),
	getPrizeSuccess(GetPrizeResp.class, "GetPrize"),
	getPrizeError(CustomErrorResponse.class, "GetPrize");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> PrizeEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
