package tests.cbsbalanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.cbsbalanceservice.enums.CbsBalanceEndpoints;
import tests.cbsbalanceservice.request.GetTransactionsByPartnerTransactionIDReq;
import tests.cbsbalanceservice.response.GetCbsTransactionsResp;
import tests.cbsbalanceservice.response.InsertTransaction;

public class GetTransactionsByPartnerTransactionIDTests extends BaseClassSetup {

	@Test(description = "Make a request to getTransactionsByPartnerTransactionID. Positive default scenario.")
	public void getTransactionsByPartnerTransactionID_Positive_Default_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetTransactionsByPartnerTransactionIDReq requestBody = new GetTransactionsByPartnerTransactionIDReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		InsertTransaction insertTransaction = new InsertTransaction.Builder()
				.defaults()
				.gameRoundId(9712524274560982L)
				.partnerTimestampUtc("2021-11-22T10:47:23.344Z")
				.partnerTransactionId("e6b2bff2-5288-497b-b26e-9484f067687d")
				.bet365TransactionId(9712524274560982L)
				.bet365GamesTransactionId(9712524274560976L)
				.build();

		GetCbsTransactionsResp expectedResponse = new GetCbsTransactionsResp.Builder()
				.defaults()
				.addTransaction(insertTransaction)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCbsTransactionsResp actualResponse = BaseRequest.post(requestBody, CbsBalanceEndpoints.getTransactionsByPartnerTransactionIDSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getTransactionsByPartnerTransactionID with invalid method.")
	public void getTransactionsByPartnerTransactionID_Invalid_Method() {

		GetTransactionsByPartnerTransactionIDReq requestBody = new GetTransactionsByPartnerTransactionIDReq.Builder()
				.defaults()
				.method("INVALID_METHOD")
				.id(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, CbsBalanceEndpoints.getTransactionsByPartnerTransactionIDError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getTransactionsByPartnerTransactionID with missing parameter user_id.")
	public void getTransactionsByPartnerTransactionID_Missing_userId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetTransactionsByPartnerTransactionIDReq requestBody = new GetTransactionsByPartnerTransactionIDReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, CbsBalanceEndpoints.getTransactionsByPartnerTransactionIDError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getTransactionsByPartnerTransactionID unknown user_id.")
	public void getTransactionsByPartnerTransactionID_Unknown_UserId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetTransactionsByPartnerTransactionIDReq requestBody = new GetTransactionsByPartnerTransactionIDReq.Builder()
				.defaults()
				.userId(UsersId.NOT_EXISTING)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCbsTransactionsResp expectedResponse = new GetCbsTransactionsResp.Builder()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCbsTransactionsResp actualResponse = BaseRequest.post(requestBody, CbsBalanceEndpoints.getTransactionsByPartnerTransactionIDSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
