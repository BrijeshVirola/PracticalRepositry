package tests.cbsbalanceservice;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.ExpectedFailure;
import common.FlakeGenerator;
import common.TransactionType;
import common.enumsconstants.Constants;
import domain.BaseRequest;
import tests.cbsbalanceservice.enums.CbsBalanceEndpoints;
import tests.cbsbalanceservice.request.CbsAdjustBalanceReq;
import tests.cbsbalanceservice.request.ExternalBalanceChange;
import tests.cbsbalanceservice.response.GetCbsTransactionResp;
public class AdjustBalanceTests extends BaseClassSetup {

	@DataProvider(name = "group1PlaytechTransactionTypeProvider")
	public Object[][] getGroup1PlaytechTransactionTypes() {
		return new Object[][] {	
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER}
		};
	}

	@Test(description = "Make a request to Adjust balance endpoint. Positive scenario.", dataProvider = "group1PlaytechTransactionTypeProvider")
	public void valid_Group1PlaytechTransactionType_When_AdjustBalance_Then_TheExpectedTransactionIsReturned(TransactionType transactionType) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer transactionTypeInt = transactionType.getValue();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.realAmount(null)
				.bonusAmount(null)
				.ringFencedAmount(null)
				.bet365TransactionId(null)
				.regulatedGameId(-1)
				.cmsCoreGameId(-1)
				.transactionTypeId(transactionTypeInt)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCbsTransactionResp actualResponse =  BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceSuccess);

		Assert.assertEquals(transactionTypeInt, actualResponse.result.transaction_type_id);
		Assert.assertEquals(request.params.partner_transaction_id, actualResponse.result.partner_transaction_id);
		Assert.assertEquals("-0.03", actualResponse.result.real_amount);
		Assert.assertEquals("0", actualResponse.result.ringfenced_amount);
		Assert.assertEquals("0", actualResponse.result.bonus_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount);
		Assert.assertEquals("-0.03", actualResponse.result.total_amount_gbp);
		Assert.assertEquals("GBP", actualResponse.result.currency_code);

		String timeStampAdjustedForTrailingZeroRemovalInResponse = request.params.partner_timestamp_utc.replaceAll("0+(?=Z)", "");
		Assert.assertEquals(timeStampAdjustedForTrailingZeroRemovalInResponse, actualResponse.result.partner_timestamp_utc);

		Assert.assertEquals(request.params.game_round_id, actualResponse.result.game_round_id);
		Assert.assertEquals(new Long(0), actualResponse.result.bet365_transaction_id);
		Assert.assertEquals(request.params.provider_region_id, actualResponse.result.provider_region_id);
		Assert.assertEquals(request.params.regulated_game_id, actualResponse.result.regulated_game_id);
		Assert.assertTrue(actualResponse.result.is_new);
	}

	@DataProvider(name = "group1NonPlaytechTransactionTypeProvider")
	public Object[][] getGroup1NonPlaytechTransactionTypes() {
		return new Object[][] {	
			{TransactionType.STAKE},
			{TransactionType.FREE_SPIN_STAKE},
			{TransactionType.GOLDEN_CHIP_STAKE},
			{TransactionType.GAMING_STAKE},
			{TransactionType.POKER_BUY_CHIPS},
			{TransactionType.POKER_TOURNAMENT_ENTRY},
			{TransactionType.POKER_TOURNAMENT_REBUY}
		};
	}

	@Test(description = "Make a request to Adjust balance endpoint. Positive scenario.", dataProvider = "group1NonPlaytechTransactionTypeProvider")
	public void valid_Group1NonPlaytechTransactionType_When_AdjustBalance_Then_TheExpectedTransactionIsReturned(TransactionType transactionType) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer transactionTypeInt = transactionType.getValue();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.realAmount(null)
				.bonusAmount(null)
				.ringFencedAmount(null)
				.bet365TransactionId(null)
				.transactionTypeId(transactionTypeInt)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCbsTransactionResp actualResponse =  BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceSuccess);

		Assert.assertEquals(transactionTypeInt, actualResponse.result.transaction_type_id);
		Assert.assertEquals(request.params.partner_transaction_id, actualResponse.result.partner_transaction_id);
		Assert.assertEquals("-0.03", actualResponse.result.real_amount);
		Assert.assertEquals("0", actualResponse.result.ringfenced_amount);
		Assert.assertEquals("0", actualResponse.result.bonus_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount);
		Assert.assertEquals("-0.03", actualResponse.result.total_amount_gbp);
		Assert.assertEquals("GBP", actualResponse.result.currency_code);

		String timeStampAdjustedForTrailingZeroRemovalInResponse = request.params.partner_timestamp_utc.replaceAll("0+(?=Z)", "");
		Assert.assertEquals(timeStampAdjustedForTrailingZeroRemovalInResponse, actualResponse.result.partner_timestamp_utc);

		Assert.assertEquals(request.params.game_round_id, actualResponse.result.game_round_id);
		Assert.assertEquals(new Long(0), actualResponse.result.bet365_transaction_id);
		Assert.assertEquals(request.params.provider_region_id, actualResponse.result.provider_region_id);
		Assert.assertEquals(request.params.regulated_game_id, actualResponse.result.regulated_game_id);
		Assert.assertTrue(actualResponse.result.is_new);
	}

	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2153", action = "transaction unexpectedly failed, test disabled")
	@Test(enabled=false, description = "Make a request to Adjust balance endpoint including optional external balance data. Positive scenario.", dataProvider = "group1TransactionTypeProvider")
	public void valid_Group1TransactionType_When_AdjustBalanceWithExternalBalanceChange_Then_TheExpectedTransactionIsReturned(
			TransactionType transactionType) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer transactionTypeInt = transactionType.getValue();

		ExternalBalanceChange external_balance_change = new ExternalBalanceChange.Builder()
				.bonusAmount("-0.03")
				.ringFencedAmount("-0.00")
				.build();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.realAmount(null)
				.bonusAmount(null)
				.ringFencedAmount(null)
				.transactionTypeId(transactionTypeInt)
				.addExternalBalanceChange(external_balance_change)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCbsTransactionResp actualResponse =  BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceSuccess);

		Assert.assertEquals(transactionTypeInt, actualResponse.result.transaction_type_id);
		Assert.assertEquals(request.params.partner_transaction_id, actualResponse.result.partner_transaction_id);
		Assert.assertEquals("-0.03", actualResponse.result.real_amount);
		Assert.assertEquals(request.params.ring_fenced_amount, actualResponse.result.ringfenced_amount);
		Assert.assertEquals("0", actualResponse.result.bonus_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount);
		Assert.assertEquals("-0.03", actualResponse.result.total_amount_gbp);
		Assert.assertEquals("GBP", actualResponse.result.currency_code);

		String timeStampAdjustedForTrailingZeroRemovalInResponse = request.params.partner_timestamp_utc.replaceAll("0+(?=Z)", "");
		Assert.assertEquals(timeStampAdjustedForTrailingZeroRemovalInResponse, actualResponse.result.partner_timestamp_utc);

		Assert.assertEquals(request.params.game_round_id, actualResponse.result.game_round_id);
		Assert.assertEquals(request.params.bet365_transaction_id, actualResponse.result.bet365_transaction_id);
		Assert.assertEquals(request.params.provider_region_id, actualResponse.result.provider_region_id);
		Assert.assertEquals(request.params.regulated_game_id, actualResponse.result.regulated_game_id);
		Assert.assertTrue(actualResponse.result.is_new);
	}

	@DataProvider(name = "group3TransactionTypeProvider")
	public Object[][] getGroup3TransactionTypes() {
		return new Object[][] {	
			{TransactionType.RETURN},
			{TransactionType.FREE_SPIN_RETURN},
			{TransactionType.GOLDEN_CHIP_RETURN},
			{TransactionType.GAMING_RETURN},
			//{TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_CASINO},
			//{TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO},
			{TransactionType.POKER_SELL_CHIPS},
			{TransactionType.POKER_TOURNAMENT_WIN},
			//{TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_POKER}
		};
	}

	@ExpectedFailure(jiraRef = "PRJSAK-2150", action = "unrecognised transaction types removed form data provider.")
	@Test(description = "Make a request to Adjust balance endpoint excluding optional external balance data. Positive scenario.", dataProvider = "group3TransactionTypeProvider")
	public void valid_Group3TransactionType_When_AdjustBalanceWithoutExternalBalanceChange_Then_TheExpectedTransactionIsReturned(
			TransactionType transactionType) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer transactionTypeInt = transactionType.getValue();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.transactionTypeId(transactionTypeInt)
				.id(idForRequestToBeEchoedBackInResponseId)
				.bonusGameType(null)
				.cmsCoreGameId(null)
				.bet365TransactionId(null)
				.sourceBet365GamesTransactionId(null)
				.realAmount("0.01")
				.bonusAmount("0.01")
				.ringFencedAmount("0.01")
				.totalAmount("0.03")
				.sourceBet365GamesTransactionId(FlakeGenerator.nextId(Constants.nodeId)) 
				.build();

		GetCbsTransactionResp actualResponse =  BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceSuccess);

		Assert.assertEquals(transactionTypeInt, actualResponse.result.transaction_type_id);
		Assert.assertEquals(request.params.partner_transaction_id, actualResponse.result.partner_transaction_id);

		Assert.assertEquals("0.02", actualResponse.result.real_amount);
		Assert.assertEquals("0", actualResponse.result.bonus_amount);
		Assert.assertEquals(request.params.ring_fenced_amount, actualResponse.result.ringfenced_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount_gbp);
		Assert.assertEquals("GBP", actualResponse.result.currency_code);

		String timeStampAdjustedForTrailingZeroRemovalInResponse = request.params.partner_timestamp_utc.replaceAll("0+(?=Z)", "");
		Assert.assertEquals(timeStampAdjustedForTrailingZeroRemovalInResponse, actualResponse.result.partner_timestamp_utc);

		Assert.assertEquals(request.params.game_round_id, actualResponse.result.game_round_id);
		Assert.assertEquals(new Long(0), actualResponse.result.bet365_transaction_id);
		Assert.assertTrue(actualResponse.result.bet365_games_transaction_id > 0);
		Assert.assertEquals(request.params.provider_region_id, actualResponse.result.provider_region_id);
		Assert.assertEquals(request.params.regulated_game_id, actualResponse.result.regulated_game_id);
		Assert.assertTrue(actualResponse.result.is_new);
	}

	@Test(description = "Make a request to Adjust balance endpoint for instant games return excluding optional external balance data. Positive scenario.")
	public void valid_Group4TransactionType_When_AdjustBalanceWithoutExternalBalanceChange_Then_TheExpectedTransactionIsReturned() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer transactionTypeInt = TransactionType.INSTANT_GAMES_RETURN.getValue();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.transactionTypeId(transactionTypeInt)
				.id(idForRequestToBeEchoedBackInResponseId)
				.cmsCoreGameId(null)
				.bet365TransactionId(null)
				.userBonusId(null)
				.realAmount("1.01")
				.bonusAmount("1.01")
				.ringFencedAmount("1.01")
				.totalAmount("3.03")
				.sourceBet365GamesTransactionId(FlakeGenerator.nextId(Constants.nodeId)) 
				.build();

		GetCbsTransactionResp actualResponse =  BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceSuccess);

		Assert.assertEquals(transactionTypeInt, actualResponse.result.transaction_type_id);
		Assert.assertEquals(request.params.partner_transaction_id, actualResponse.result.partner_transaction_id);
		Assert.assertEquals("2.02", actualResponse.result.real_amount);
		Assert.assertEquals("0", actualResponse.result.bonus_amount);
		Assert.assertEquals(request.params.ring_fenced_amount, actualResponse.result.ringfenced_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount_gbp);
		Assert.assertEquals("GBP", actualResponse.result.currency_code);

		String timeStampAdjustedForTrailingZeroRemovalInResponse = request.params.partner_timestamp_utc.replaceAll("0+(?=Z)", "");
		Assert.assertEquals(timeStampAdjustedForTrailingZeroRemovalInResponse, actualResponse.result.partner_timestamp_utc);

		Assert.assertEquals(new Long(0), actualResponse.result.bet365_transaction_id);
		Assert.assertEquals(request.params.game_round_id, actualResponse.result.game_round_id);
		Assert.assertTrue(actualResponse.result.bet365_games_transaction_id > 0);
		Assert.assertEquals(request.params.provider_region_id, actualResponse.result.provider_region_id);
		Assert.assertEquals(request.params.regulated_game_id, actualResponse.result.regulated_game_id);
		Assert.assertTrue(actualResponse.result.is_new);
	}

	@DataProvider(name = "group5TransactionTypeProvider")
	public Object[][] getGroup5TransactionTypes() {
		return new Object[][] {	
			{TransactionType.VOID_STAKE},
			{TransactionType.VOID_GAMING_STAKE},
			{TransactionType.VOID_POKER_BUY_CHIPS},
			{TransactionType.VOID_POKER_TOURNAMENT_ENTRY},
			{TransactionType.VOID_POKER_TOURNAMENT_REBUY}
		};
	}

	@Test(description = "Make a request to Adjust balance endpoint excluding optional external balance data. Positive scenario.", dataProvider = "group5TransactionTypeProvider")
	public void valid_Group5TransactionType_When_AdjustBalanceWithoutExternalBalanceChange_Then_TheExpectedTransactionIsReturned(
			TransactionType transactionType) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer transactionTypeInt = transactionType.getValue();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.transactionTypeId(transactionTypeInt)
				.id(idForRequestToBeEchoedBackInResponseId)
				.cmsCoreGameId(null)
				.bet365TransactionId(null)
				.allowBonus(null)
				.allowRingFenced(null)
				.realAmount("0.01")
				.bonusAmount("0.01")
				.ringFencedAmount("0.01")
				.totalAmount("0.03")
				.sourceBet365GamesTransactionId(FlakeGenerator.nextId(Constants.nodeId)) 
				.build();

		GetCbsTransactionResp actualResponse =  BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceSuccess);

		Assert.assertEquals(transactionTypeInt, actualResponse.result.transaction_type_id);
		Assert.assertEquals(request.params.partner_transaction_id, actualResponse.result.partner_transaction_id);
		Assert.assertEquals(request.params.real_amount, actualResponse.result.real_amount);
		Assert.assertEquals(request.params.bonus_amount, actualResponse.result.bonus_amount);
		Assert.assertEquals(request.params.ring_fenced_amount, actualResponse.result.ringfenced_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount_gbp);
		Assert.assertEquals("GBP", actualResponse.result.currency_code);

		String timeStampAdjustedForTrailingZeroRemovalInResponse = request.params.partner_timestamp_utc.replaceAll("0+(?=Z)", "");
		Assert.assertEquals(timeStampAdjustedForTrailingZeroRemovalInResponse, actualResponse.result.partner_timestamp_utc);

		Assert.assertEquals(new Long(0), actualResponse.result.bet365_transaction_id);
		Assert.assertEquals(request.params.game_round_id, actualResponse.result.game_round_id);
		Assert.assertTrue(actualResponse.result.bet365_games_transaction_id > 0);
		Assert.assertEquals(request.params.provider_region_id, actualResponse.result.provider_region_id);
		Assert.assertEquals(request.params.regulated_game_id, actualResponse.result.regulated_game_id);
		Assert.assertTrue(actualResponse.result.is_new);
	}

	@Test(description = "Make a request to Adjust balance endpoint for void instant games stake excluding optional external balance data. Positive scenario.")
	public void valid_Group6TransactionType_When_AdjustBalanceWithoutExternalBalanceChange_Then_TheExpectedTransactionIsReturned() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer transactionTypeInt = TransactionType.VOID_INSTANT_GAMES_STAKE.getValue();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.transactionTypeId(transactionTypeInt)
				.id(idForRequestToBeEchoedBackInResponseId)
				.cmsCoreGameId(null)
				.bet365TransactionId(null)
				.allowBonus(null)
				.allowRingFenced(null)
				.userBonusId(null)
				.realAmount("0.01")
				.bonusAmount("0.01")
				.ringFencedAmount("0.01")
				.totalAmount("0.03")
				.sourceBet365GamesTransactionId(FlakeGenerator.nextId(Constants.nodeId)) 
				.build();

		GetCbsTransactionResp actualResponse =  BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceSuccess);

		Assert.assertEquals(transactionTypeInt, actualResponse.result.transaction_type_id);
		Assert.assertEquals(request.params.partner_transaction_id, actualResponse.result.partner_transaction_id);
		Assert.assertEquals(request.params.real_amount, actualResponse.result.real_amount);
		Assert.assertEquals(request.params.bonus_amount, actualResponse.result.bonus_amount);
		Assert.assertEquals(request.params.ring_fenced_amount, actualResponse.result.ringfenced_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount_gbp);
		Assert.assertEquals("GBP", actualResponse.result.currency_code);

		String timeStampAdjustedForTrailingZeroRemovalInResponse = request.params.partner_timestamp_utc.replaceAll("0+(?=Z)", "");
		Assert.assertEquals(timeStampAdjustedForTrailingZeroRemovalInResponse, actualResponse.result.partner_timestamp_utc);

		Assert.assertEquals(new Long(0), actualResponse.result.bet365_transaction_id);
		Assert.assertEquals(request.params.game_round_id, actualResponse.result.game_round_id);
		Assert.assertTrue(actualResponse.result.bet365_games_transaction_id > 0);
		Assert.assertEquals(request.params.provider_region_id, actualResponse.result.provider_region_id);
		Assert.assertEquals(request.params.regulated_game_id, actualResponse.result.regulated_game_id);
		Assert.assertTrue(actualResponse.result.is_new);
	}
}