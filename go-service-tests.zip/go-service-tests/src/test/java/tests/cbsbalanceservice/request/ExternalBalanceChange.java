package tests.cbsbalanceservice.request;

public class ExternalBalanceChange {
	@SuppressWarnings("unused")
	private String bonus_amount;
	@SuppressWarnings("unused")
	private String ring_fenced_amount;

	private ExternalBalanceChange(Builder builder) {
		this.bonus_amount = builder.bonus_amount;
		this.ring_fenced_amount = builder.ring_fenced_amount;
	}

	public static class Builder {
		private String bonus_amount;
		@SuppressWarnings("unused")
		private String ring_fenced_amount;
		
		public Builder bonusAmount(String bonus_amount) {
			this.bonus_amount = bonus_amount;
			return this;
		}
		
		public Builder ringFencedAmount(String ring_fenced_amount) {
			this.ring_fenced_amount = ring_fenced_amount;
			return this;
		}
		
		public Builder defaults() {
			this.bonus_amount = "-3.50";
			this.ring_fenced_amount = "-3.50";
			return this;
		}
		
		public ExternalBalanceChange build() {
			return new ExternalBalanceChange(this);
		}
	}
}
