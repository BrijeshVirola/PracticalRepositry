package tests.cbsbalanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.ExpectedFailure;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.cbsbalanceservice.enums.CbsBalanceEndpoints;
import tests.cbsbalanceservice.request.GetLatestTransactionByTransactionTypeIdReq;
import tests.cbsbalanceservice.response.GetCbsTransactionResp;
import tests.cbsbalanceservice.response.InsertTransaction;

public class GetLatestTransactionByTransactionTypeIdTests extends BaseClassSetup {

	@ExpectedFailure(jiraRef="PRJSAK-2113", action="test disabled. latest data can change so need to create our own transaction first but can't due to PRJSAK-2113")
	@Test(enabled=false, description = "Make a request to getLatestTransactionByTransactionTypeId. Positive default scenario.")
	public void getLatestTransactionByTransactionTypeId_Positive_Default_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetLatestTransactionByTransactionTypeIdReq requestBody = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		InsertTransaction insertTransaction = new InsertTransaction.Builder()
				.defaults()
				.partnerTimestampUtc("2021-11-12T12:45:19.524Z")
				.bet365GamesTransactionId(8584986789690779L)
				.gameRoundId(539723L)
				.partnerTransactionId("1234/2103260708")
				.build();

		GetCbsTransactionResp expectedResponse = new GetCbsTransactionResp.Builder()
				.defaults()
				.addTransaction(insertTransaction)
				.id(null)//reinstate this field check once PRJSAK-2105 has been fixed
				.build();

		GetCbsTransactionResp actualResponse = BaseRequest.post(requestBody, CbsBalanceEndpoints.getLatestTransactionByTransactionTypeIdSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getLatestTransactionByTransactionTypeId with invalid method.")
	public void getLatestTransactionByTransactionTypeId_Invalid_Method() {

		GetLatestTransactionByTransactionTypeIdReq requestBody = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.method("INVALID_METHOD")
				.id(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, CbsBalanceEndpoints.getLatestTransactionByTransactionTypeIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getLatestTransactionByTransactionTypeId with missing parameter user_id.")
	public void getLatestTransactionByTransactionTypeId_Missing_userId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetLatestTransactionByTransactionTypeIdReq requestBody = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, CbsBalanceEndpoints.getLatestTransactionByTransactionTypeIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getLatestTransactionByTransactionTypeId unknown user_id.")
	public void getLatestTransactionByTransactionTypeId_Unknown_userId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetLatestTransactionByTransactionTypeIdReq requestBody = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.userId(UsersId.NOT_EXISTING)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1010)
				.message("Transaction not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, CbsBalanceEndpoints.getLatestTransactionByTransactionTypeIdError);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
