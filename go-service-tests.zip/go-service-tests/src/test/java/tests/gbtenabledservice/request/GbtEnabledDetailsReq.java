package tests.gbtenabledservice.request;

import java.util.HashMap;
import java.util.Map;


public class GbtEnabledDetailsReq {

	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private Map<String, Object> params = new HashMap<>();
	
	private GbtEnabledDetailsReq(Builder builder) {
		this.Method = builder.method;
		this.ID = builder.id;
		this.params.put("country_id", builder.country_id);
		this.params.put("product_id", builder.product_id);
	}
	


	public static class Builder {
		private String method, id;
		private Integer country_id, product_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder params(Integer country_id, Integer product_id) {
			this.product_id = product_id;
			this.country_id = country_id;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder countryId(Integer country_id) {
			this.country_id = country_id;
			return this;
		}

		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}

		public Builder defaults() {
			this.method = "isgbtenabled";
			this.id = "123456789";
			this.country_id = 197;
			this.product_id = 4;
			return this;
		}

		public GbtEnabledDetailsReq build() {
			return new GbtEnabledDetailsReq(this);
		}
	}
}