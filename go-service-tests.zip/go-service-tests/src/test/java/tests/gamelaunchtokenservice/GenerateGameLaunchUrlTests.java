package tests.gamelaunchtokenservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamelaunchtokenservice.enums.GameLaunchTokenEndpoints;
import tests.gamelaunchtokenservice.request.GenerateGameLaunchUrlReq;
import tests.gamelaunchtokenservice.response.GenerateGameLaunchUrlResp;

public class GenerateGameLaunchUrlTests  extends BaseClassSetup{

	@Test(description = "Make a request to GenerateGameLaunchUrl. Positive scenario.")
	public void generateGameLaunchUrl_Positive_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GenerateGameLaunchUrlResp actResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlSuccess);

		GenerateGameLaunchUrlResp expResponse =  new GenerateGameLaunchUrlResp.Builder()
				.defaults()
				.token(actResponse.result.get("token").toString())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(actResponse, expResponse);
	}

	@Test(description = "Make a request to generateGameLaunchUrl. Missing product_id parameter.")
	public void generateGameLaunchUrl_MissingProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.productId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.message("Missing parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to generateGameLaunchUrl. Wrong method.")
	public void generateGameLaunchUrl_Wrong_Method() {

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
