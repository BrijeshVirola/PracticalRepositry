package tests.gamelaunchtokenservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamelaunchtokenservice.enums.GameLaunchTokenEndpoints;
import tests.gamelaunchtokenservice.request.GenerateGameLaunchUrlReq;
import tests.gamelaunchtokenservice.request.GetGameLaunchDetailsReq;
import tests.gamelaunchtokenservice.response.GenerateGameLaunchUrlResp;
import tests.gamelaunchtokenservice.response.GetGameLaunchDetailsResp;

public class GetGameLaunchDetailsTests  extends BaseClassSetup{

	@Test(description = "Make a request to GenerateGameLaunchUrl. Positive scenario.")
	public void generateGameLaunchUrl_Positive_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GenerateGameLaunchUrlResp actResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlSuccess);

		String actualToken = actResponse.result.get("token").toString();

		GenerateGameLaunchUrlResp expResponse =  new GenerateGameLaunchUrlResp.Builder()
				.defaults()
				.token(actualToken)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expResponse, actResponse);

		String idGenerateGameLaunchUrl = UUID.randomUUID().toString();

		GetGameLaunchDetailsReq requestGetGameLaunchDetails = new GetGameLaunchDetailsReq.Builder()
				.defaults()
				.token(actualToken)
				.id(idGenerateGameLaunchUrl)
				.build();

		GetGameLaunchDetailsResp actualGetGameLaunchDetailsResponse =  BaseRequest.post(requestGetGameLaunchDetails, GameLaunchTokenEndpoints.getGameLaunchDetailsSuccess);

		GetGameLaunchDetailsResp expectedGetGameLaunchDetailsResponse =  new GetGameLaunchDetailsResp.Builder()
				.defaults()
				.id(idGenerateGameLaunchUrl)
				.build();

		assertReflectionEquals(expectedGetGameLaunchDetailsResponse, actualGetGameLaunchDetailsResponse);
	}

	@Test(description = "Make a request to getGameLaunchDetails. Missing token parameter.")
	public void getGameLaunchDetails_MissingToken_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGameLaunchDetailsReq request = new GetGameLaunchDetailsReq.Builder()
				.defaults()
				.token(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.getGameLaunchDetailsError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.message("Missing parameter: token")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getGameLaunchDetails. Wrong method.")
	public void getGameLaunchDetails_Wrong_Method() {

		GetGameLaunchDetailsReq request = new GetGameLaunchDetailsReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.getGameLaunchDetailsError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
