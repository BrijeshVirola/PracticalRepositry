package tests.playtechadminservice.response;

import java.util.TreeSet;

public class ExpirationRules{
	@SuppressWarnings("unused")
	private String start_date;
	@SuppressWarnings("unused")
	private TreeSet<Integer> allowed_statuses;
	@SuppressWarnings("unused")
	private Integer expiration_period, expiration_period_start_event;
	
	private ExpirationRules(Builder builder) {
		this.allowed_statuses = builder.allowed_statuses;
		this.start_date = builder.start_date;
		this.expiration_period = builder.expiration_period;
		this.expiration_period_start_event = builder.expiration_period_start_event;
	}
	
	public static class Builder {
		TreeSet<Integer> allowed_statuses;
		private String start_date;
		private Integer expiration_period, expiration_period_start_event;
		
		public Builder addAllowedStatuses(Integer status) {
			this.allowed_statuses.add(status);
			return this;
		}
		
		public Builder startDate(String start_date) {
			this.start_date = start_date;
			return this;
		}
		
		public Builder expirationPeriod(Integer expiration_period) {
			this.expiration_period = expiration_period;
			return this;
		}
		
		public Builder expirationPeriodStartEvent(Integer expiration_period_start_event) {
			this.expiration_period_start_event = expiration_period_start_event;
			return this;
		}
		
		public Builder defaults() {
			this.allowed_statuses = new TreeSet<Integer>();
			this.start_date = "2021-05-20 13:53:27.000";
			this.expiration_period = 43200;
			this.expiration_period_start_event = 1;
			return this;
		}
		
		public ExpirationRules build() {
			return new ExpirationRules(this);
		}
	}
}
