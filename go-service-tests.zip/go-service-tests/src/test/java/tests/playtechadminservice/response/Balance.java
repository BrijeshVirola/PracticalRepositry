package tests.playtechadminservice.response;

public class Balance{
	@SuppressWarnings("unused")
	private String amount, currency_code, balance_type;
	
	private Balance(Builder builder) {
		this.amount = builder.amount;
		this.currency_code = builder.currency_code;
		this.balance_type = builder.balance_type;
	}
	
	public static class Builder {
		private String amount, currency_code, balance_type;
		
		public Builder amount(String amount) {
			this.amount = amount;
			return this;
		}
		
		public Builder currencyCode(String currency_code) {
			this.currency_code = currency_code;
			return this;
		}
		
		public Builder balanceType(String balance_type) {
			this.balance_type = balance_type;
			return this;
		}
		
		public Builder defaults() {
			this.balance_type = "ringfenced_real_balance";
			this.amount = "0";
			this.currency_code = "EUR";
			return this;
		}
		
		public Balance build() {
			return new Balance(this);
		}
	}
}