package tests.playtechadminservice.response;

import java.util.ArrayList;
import java.util.List;

public class ExpirationRulesAllowedStatuses{
	@SuppressWarnings("unused")
	private List<Integer> allowed_statuses;
	
	private ExpirationRulesAllowedStatuses(Builder builder) {
		this.allowed_statuses = builder.allowed_statuses;
	}
	
	public static class Builder {
		private List<Integer> allowed_statuses;
		
		public Builder addAllowedStatus(Integer allowed_status) {
			this.allowed_statuses.add(allowed_status);
			return this;
		}
		
		public Builder defaults() {
			this.allowed_statuses = new ArrayList<Integer>();
			return this;
		}
		
		public ExpirationRulesAllowedStatuses build() {
			return new ExpirationRulesAllowedStatuses(this);
		}
	}
}
