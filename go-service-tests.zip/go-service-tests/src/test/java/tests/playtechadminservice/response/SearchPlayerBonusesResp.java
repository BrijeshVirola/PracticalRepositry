package tests.playtechadminservice.response;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SearchPlayerBonusesResp {

		@SuppressWarnings("unused")
		private String id;
		private Map<String, List<Bonus>> result = new HashMap<>();
		private SearchPlayerBonusesResp(Builder builder) {
			this.id = builder.id;
			this.result.put("bonus", builder.bonuses);
		}
		
		public List<Bonus> getBonuses() {
			return result.get("bonus");
		}
		
		public static class Builder {
			private String id;
			private List<Bonus> bonuses = new ArrayList<Bonus>();

			public Builder id(String id) {
				this.id = id;
				return this;
			}

			public Builder addBonus(Bonus bonus) {
				this.bonuses.add(bonus);
				return this;
			}

			public Builder defaults() {
				this.id = "1";
				return this;
			}

			public SearchPlayerBonusesResp build() {
				return new SearchPlayerBonusesResp(this);
			}
		}
	}
