package tests.playtechadminservice.response;

import java.util.ArrayList;
import java.util.List;

public class GetDynamicBalancesResp {

		@SuppressWarnings("unused")
		private String id;
		@SuppressWarnings("unused")
		private Result result;
		
		private GetDynamicBalancesResp(Builder builder) {
			this.id = builder.id;
			this.result = new Result(builder);
		}
		
		public static class Builder {
			private String id;
			private Integer error_code;
			private List<Balance> balances = new ArrayList<Balance>();

			public Builder id(String id) {
				this.id = id;
				return this;
			}
			
			public Builder errorCode(Integer error_code) {
				this.error_code = error_code;
				return this;
			}

			public Builder addBalance(Balance balance) {
				this.balances.add(balance);
				return this;
			}

			public Builder defaults() {
				this.id = "1";
				this.error_code = 0;
				return this;
			}

			public GetDynamicBalancesResp build() {
				return new GetDynamicBalancesResp(this);
			}
		}
		
		public class Result {

			@SuppressWarnings("unused")
			private Integer error_code;
			@SuppressWarnings("unused")
			private List<Balance> balances;

			public Result(Builder builder) {
				this.error_code = builder.error_code;
				this.balances = builder.balances;
			}
		}

	}
