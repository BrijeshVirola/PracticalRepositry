package tests.playtechadminservice.response;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class Bonus {

	private final static String POUND_SIGN = "\u00A3";
	@SuppressWarnings("unused")
	private String remote_bonus_id, bonus_instance_code, template_code, template_name, status, play_type, end_date, template_last_modify_timestamp, issue_date, accept_date, template_default_name;
	@SuppressWarnings("unused")
	private String wagering_method, issuing_comment, wagering_start_date, owning_service, marketing_name, product, completion_requirement_type, gaming_context_last_modify_timestamp;
	@SuppressWarnings("unused")
	private Integer user_id, product_id, free_spins_count, free_spins_count_remaining, completion_type, gaming_context_code;
	@SuppressWarnings("unused")
	private Boolean decline_on_withdraw, non_redeemable_with_wagering, no_decline_on_ftwd_req;
	@SuppressWarnings("unused")
	private List<String> triggers;
	@SuppressWarnings("unused")
	private AmountAndCurrencyCode amount_on_balance, redeemed_amount, initial_wagering, wagering, pending_winnings, removed_amount, amount;
	@SuppressWarnings("unused")
	private List<CompletionRequirementStatuses> completion_requirement_statuses;
	@SuppressWarnings("unused")
	private ExpirationRules expiration_rules;
	
	private Bonus(Builder builder) {
		this.remote_bonus_id = builder.remote_bonus_id;
		this.bonus_instance_code = builder.bonus_instance_code;
		this.template_code = builder.template_code;
		this.template_name = builder.template_name;
		this.status = builder.status;
		this.play_type = builder.play_type;
		this.end_date = builder.end_date;
		this.decline_on_withdraw = builder.decline_on_withdraw;
		this.template_last_modify_timestamp = builder.template_last_modify_timestamp;
		this.issue_date = builder.issue_date;
		this.accept_date = builder.accept_date;
		this.wagering_method = builder.wagering_method;
		this.free_spins_count = builder.free_spins_count;
		this.free_spins_count_remaining = builder.free_spins_count_remaining;
		this.issuing_comment = builder.issuing_comment;
		this.non_redeemable_with_wagering = builder.non_redeemable_with_wagering;
		this.completion_type = builder.completion_type;
		this.wagering_start_date = builder.wagering_start_date;
		this.owning_service = builder.owning_service;
		this.marketing_name = builder.marketing_name;
		this.product = builder.product;
		this.completion_requirement_type = builder.completion_requirement_type;
		this.gaming_context_code = builder.gaming_context_code;
		this.gaming_context_last_modify_timestamp = builder.gaming_context_last_modify_timestamp;
		this.no_decline_on_ftwd_req = builder.no_decline_on_ftwd_req;
		this.template_default_name = builder.template_default_name;
		this.triggers = builder.triggers;
		this.completion_requirement_statuses = builder.completion_requirement_statuses;
		this.expiration_rules = builder.expiration_rules;
		this.amount_on_balance = builder.amount_on_balance;
		this.redeemed_amount = builder.redeemed_amount;
		this.initial_wagering = builder.initial_wagering;
		this.wagering = builder.wagering;
		this.pending_winnings = builder.pending_winnings;
		this.removed_amount = builder.removed_amount;
		this.amount = builder.amount;
	}
	
	public Instant getIssueDateAsInstant() {
		return Instant.parse(issue_date.replace(" ", "T") + "Z");
	}
	
	public String getBonusInstanceCode() {
		return bonus_instance_code;
	}
	
	public static class Builder {
		private String remote_bonus_id, bonus_instance_code, template_code, template_name, status, play_type, end_date, template_last_modify_timestamp, issue_date, accept_date, template_default_name;
		private String wagering_method, issuing_comment, wagering_start_date, owning_service, marketing_name, product, completion_requirement_type, gaming_context_last_modify_timestamp;
		@SuppressWarnings("unused")
		private Integer user_id, product_id, free_spins_count, free_spins_count_remaining, completion_type, gaming_context_code;
		private Boolean decline_on_withdraw, non_redeemable_with_wagering, no_decline_on_ftwd_req;
		private List<String> triggers;
		@SuppressWarnings("unused")
		private AmountAndCurrencyCode amount_on_balance, redeemed_amount, initial_wagering, wagering, pending_winnings, removed_amount, amount;
		@SuppressWarnings("unused")
		private ExpirationRules expiration_rules;
		private List<CompletionRequirementStatuses> completion_requirement_statuses;
		
		public Builder remoteBonusId(String remote_bonus_id) {
			this.remote_bonus_id = remote_bonus_id;
			return this;
		}

		public Builder bonusInstanceCode(String bonus_instance_code) {
			this.bonus_instance_code = bonus_instance_code;
			return this;
		}

		public Builder templateCode(String template_code) {
			this.template_code = template_code;
			return this;
		}
		
		public Builder templateName(String template_name) {
			this.template_name = template_name;
			return this;
		}

		public Builder status(String status) {
			this.status = status;
			return this;
		}
		
		public Builder playType(String play_type) {
			this.play_type = play_type;
			return this;
		}
		
		public Builder endDate(String end_date) {
			this.end_date = end_date;
			return this;
		}
		
		public Builder declineOnWithdraw(Boolean decline_on_withdraw) {
			this.decline_on_withdraw = decline_on_withdraw;
			return this;
		}
		
		public Builder templateLastModifyTimestamp(String template_last_modify_timestamp) {
			this.template_last_modify_timestamp = template_last_modify_timestamp;
			return this;
		}

		public Builder issueDate(String issue_date) {
			this.issue_date = issue_date;
			return this;
		}
		
		public Builder acceptDate(String accept_date) {
			this.accept_date = accept_date;
			return this;
		}
		
		public Builder wageringMethod(String wagering_method) {
			this.wagering_method = wagering_method;
			return this;
		}
		
		public Builder freeSpinsCount(Integer free_spins_count) {
			this.free_spins_count = free_spins_count;
			return this;
		}
		
		public Builder freeSpinsCountRemaining(Integer free_spins_count_remaining) {
			this.free_spins_count_remaining = free_spins_count_remaining;
			return this;
		}
		
		public Builder issuingComment(String issuing_comment) {
			this.issuing_comment = issuing_comment;
			return this;
		}
		
		public Builder nonRedeemableWithWagering(Boolean non_redeemable_with_wagering) {
			this.non_redeemable_with_wagering = non_redeemable_with_wagering;
			return this;
		}
		
		public Builder completionType(Integer completion_type) {
			this.completion_type = completion_type;
			return this;
		}
		
		public Builder wageringStartDate(String wagering_start_date) {
			this.wagering_start_date = wagering_start_date;
			return this;
		}
		
		public Builder owningService(String owning_service) {
			this.owning_service = owning_service;
			return this;
		}
		
		public Builder marketingName(String marketing_name) {
			this.marketing_name = marketing_name;
			return this;
		}
		
		public Builder product(String product) {
			this.product = product;
			return this;
		}
		
		public Builder completionRequirementType(String completion_requirement_type) {
			this.completion_requirement_type = completion_requirement_type;
			return this;
		}
		
		public Builder gamingContextCode(Integer gaming_context_code) {
			this.gaming_context_code = gaming_context_code;
			return this;
		}
		
		public Builder gamingCcontextLastModifyTimestamp(String gaming_context_last_modify_timestamp) {
			this.gaming_context_last_modify_timestamp = gaming_context_last_modify_timestamp;
			return this;
		}
		
		public Builder noDeclineOnFtwdReq(Boolean no_decline_on_ftwd_req) {
			this.no_decline_on_ftwd_req = no_decline_on_ftwd_req;
			return this;
		}
		
		public Builder templateDefaultName(String template_default_name) {
			this.template_default_name = template_default_name;
			return this;
		}
		
		public Builder addTriggers(String trigger) {
			this.triggers.add(trigger);
			return this;
		}
		
		public Builder addAmount(AmountAndCurrencyCode amountAndCurrencyCode) {
			this.amount = amountAndCurrencyCode;
			return this;
		}
		
		public Builder addAmountOnBalance(AmountAndCurrencyCode amountAndCurrencyCode) {
			this.amount_on_balance = amountAndCurrencyCode;
			return this;
		}
		
		public Builder addRedeemedAmount(AmountAndCurrencyCode amountAndCurrencyCode) {
			this.redeemed_amount = amountAndCurrencyCode;
			return this;
		}
		
		public Builder addInitialWagering(AmountAndCurrencyCode amountAndCurrencyCode) {
			this.initial_wagering = amountAndCurrencyCode;
			return this;
		}
		
		public Builder addWagering(AmountAndCurrencyCode amountAndCurrencyCode) {
			this.wagering = amountAndCurrencyCode;
			return this;
		}
		
		public Builder addPendingWinnings(AmountAndCurrencyCode amountAndCurrencyCode) {
			this.pending_winnings = amountAndCurrencyCode;
			return this;
		}

		public Builder addRemovedAmount(AmountAndCurrencyCode amountAndCurrencyCode) {
			this.removed_amount = amountAndCurrencyCode;
			return this;
		}
		
		public Builder completionRequirementStatusesToNull() {
			this.completion_requirement_statuses = null;
			return this;
		}
		
		public Builder addCompletionRequirementStatuses(CompletionRequirementStatuses completion_requirement_statuses) {
			this.completion_requirement_statuses.add(completion_requirement_statuses);
			return this;
		}
		
		public Builder expirationRules(ExpirationRules expirationRules) {
			this.expiration_rules = expirationRules;
			return this;
		}
		
		public Builder defaults() {
			this.remote_bonus_id = "637764673155536972";
			this.bonus_instance_code = "10699332";
			this.template_code = "65046";
			this.template_name = "EW - OpeningBonus UK (" + POUND_SIGN + "25)";
			this.status = "expired";
			this.play_type = "prewager";
			this.end_date = "2022-01-29 13:21:56.000";
			this.decline_on_withdraw = false;
			this.template_last_modify_timestamp = "2021-08-20 10:04:48.991";
			this.issue_date = "2021-12-30 13:21:56.000";
			this.accept_date = "";
			this.wagering_method = "Bonus";
			this.free_spins_count = 0;
			this.free_spins_count_remaining = 0;
			this.issuing_comment = "AddBonus";
			this.non_redeemable_with_wagering = false;
			this.completion_type = 2;
			this.wagering_start_date = "";
			this.owning_service = "";
			this.marketing_name = "Opening Bonus";
			this.product = "Casino";
			this.completion_requirement_type = "casinowagering";
			this.gaming_context_code = 1;
			this.gaming_context_last_modify_timestamp = "2017-01-26 12:54:29.000";
			this.no_decline_on_ftwd_req = false;
			this.template_default_name = "EW - OpeningBonus UK (" + POUND_SIGN + "25)";
			this.triggers = new ArrayList<>();
			this.completion_requirement_statuses = new ArrayList<CompletionRequirementStatuses>();
			this.expiration_rules = null;
			return this;
		}

		public Bonus build() {
			return new Bonus(this);
		}
	}
}
