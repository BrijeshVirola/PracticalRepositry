package tests.playtechadminservice.response;

public class AmountAndCurrencyCode{
	@SuppressWarnings("unused")
	private String amount, currency_code;
	private AmountAndCurrencyCode(Builder builder) {
		this.amount = builder.amount;
		this.currency_code = builder.currency_code;
	}
	
	public static class Builder {
		private String amount, currency_code;
		
		public Builder amount(String amount) {
			this.amount = amount;
			return this;
		}
		
		public Builder currencyCode(String currency_code) {
			this.currency_code = currency_code;
			return this;
		}
		
		public Builder defaults() {
			this.amount = "8";
			this.currency_code = "GBP";
			return this;
		}
		
		public AmountAndCurrencyCode build() {
			return new AmountAndCurrencyCode(this);
		}
	}
}