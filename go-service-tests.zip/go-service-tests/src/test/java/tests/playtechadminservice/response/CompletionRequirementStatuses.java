package tests.playtechadminservice.response;

public class CompletionRequirementStatuses{
	@SuppressWarnings("unused")
	private String type, initial_wagering, remaining_wagering;
	
	private CompletionRequirementStatuses(Builder builder) {
		this.type = builder.type;
		this.initial_wagering = builder.initial_wagering;
		this.remaining_wagering = builder.remaining_wagering;
	}
	
	public static class Builder {
		private String type, initial_wagering, remaining_wagering;
		
		public Builder type(String type) {
			this.type = type;
			return this;
		}
		
		public Builder initialWagering(String initial_wagering) {
			this.initial_wagering = initial_wagering;
			return this;
		}
		
		public Builder remaining_wagering(String remaining_wagering) {
			this.remaining_wagering = remaining_wagering;
			return this;
		}
		
		public Builder defaults() {
			this.type = "betamountwagering";
			this.initial_wagering = "8";
			this.remaining_wagering = "8";
			return this;
		}
		
		public CompletionRequirementStatuses build() {
			return new CompletionRequirementStatuses(this);
		}
	}
}