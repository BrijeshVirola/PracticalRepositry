package tests.playtechadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.playtechadminservice.enums.PTAdminEndpoints;
import tests.playtechadminservice.request.SearchPlayerBonusesReq;
import tests.playtechadminservice.response.AmountAndCurrencyCode;
import tests.playtechadminservice.response.Bonus;
import tests.playtechadminservice.response.CompletionRequirementStatuses;
import tests.playtechadminservice.response.ExpirationRules;
import tests.playtechadminservice.response.SearchPlayerBonusesResp;
public class SearchPlayerBonusesTests extends BaseClassSetup {
	@Test(description = "Make a request to SearchPlayerBonuses. Positive scenario.")
	public void searchPlayerBonuses_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ExpirationRules expirationRules = new ExpirationRules.Builder()
				.defaults()
				.addAllowedStatuses(1)
				.addAllowedStatuses(3)
				.addAllowedStatuses(4)
				.build();

		Bonus bonus1 = new Bonus.Builder()
				.defaults()
				.expirationRules(expirationRules)
				.addCompletionRequirementStatuses(new CompletionRequirementStatuses.Builder()
						.initialWagering("400")
						.remaining_wagering("400")
						.type("betamountwagering")
						.build())
				.addAmount(new AmountAndCurrencyCode.Builder().amount("10").currencyCode("GBP").build())
				.addAmountOnBalance(new AmountAndCurrencyCode.Builder().amount("0").currencyCode("GBP").build())
				.addInitialWagering(new AmountAndCurrencyCode.Builder().amount("400").currencyCode("GBP").build())
				.addPendingWinnings(new AmountAndCurrencyCode.Builder().amount("0").currencyCode("GBP").build())
				.addRedeemedAmount(new AmountAndCurrencyCode.Builder().amount("0").currencyCode("GBP").build())
				.addRemovedAmount(new AmountAndCurrencyCode.Builder().amount("10").currencyCode("GBP").build())
				.addTriggers("Manual")
				.addWagering(new AmountAndCurrencyCode.Builder().amount("400").currencyCode("GBP").build())
				.build();

		SearchPlayerBonusesReq request = new SearchPlayerBonusesReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();


		SearchPlayerBonusesResp expectedResponse = new SearchPlayerBonusesResp.Builder()
				.defaults()
				.addBonus(bonus1)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		SearchPlayerBonusesResp actualResponse =  BaseRequest.post(request, PTAdminEndpoints.searchPlayerBonusesSuccess);


		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to searchPlayerBonuses. Missing user_id parameter.")
	public void searchPlayerBonuses_MissingUserid_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SearchPlayerBonusesReq request = new SearchPlayerBonusesReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.searchPlayerBonusesError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to searchPlayerBonuses. Missing product_id parameter.")
	public void searchPlayerBonuses_MissingProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SearchPlayerBonusesReq request = new SearchPlayerBonusesReq.Builder()
				.defaults()
				.productId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.searchPlayerBonusesError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to searchPlayerBonuses. Wrong method.")
	public void searchPlayerBonuses_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SearchPlayerBonusesReq request = new SearchPlayerBonusesReq.Builder().defaults()
				.id(idForRequestToBeEchoedBackInResponseId).method("INVALID_METHOD_NAME").build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.searchPlayerBonusesError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
