package tests.playtechadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.ExpectedFailure;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.playtechadminservice.enums.PTAdminEndpoints;
import tests.playtechadminservice.request.SendPlayerMessageReq;
public class SendPlayerMessageTests extends BaseClassSetup {

	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2445", action="test disabled pending appropriate test data or mocked endpoint")
	@Test(enabled=false, description = "Make a request to SendPlayerMessage. Positive scenario.")
	public void sendPlayerMessage_WageringBonus_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SendPlayerMessageReq request = new SendPlayerMessageReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.result("ok")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, PTAdminEndpoints.sendPlayerMessageSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to sendPlayerMessage. Missing active session.")
	public void sendPlayerMessage_MissingActiveSession_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SendPlayerMessageReq request = new SendPlayerMessageReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.sendPlayerMessageError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Player has no active sessions")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to sendPlayerMessage. Missing user_id parameter.")
	public void sendPlayerMessage_MissingUserid_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SendPlayerMessageReq request = new SendPlayerMessageReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.sendPlayerMessageError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to sendPlayerMessage. Missing product_id parameter.")
	public void sendPlayerMessage_MissingProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SendPlayerMessageReq request = new SendPlayerMessageReq.Builder()
				.defaults()
				.productId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.sendPlayerMessageError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to sendPlayerMessage. Wrong method.")
	public void sendPlayerMessage_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SendPlayerMessageReq request = new SendPlayerMessageReq.Builder().defaults()
				.id(idForRequestToBeEchoedBackInResponseId).method("INVALID_METHOD_NAME").build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.sendPlayerMessageError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
