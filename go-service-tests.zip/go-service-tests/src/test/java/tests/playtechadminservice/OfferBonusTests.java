package tests.playtechadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.playtechadminservice.enums.PTAdminEndpoints;
import tests.playtechadminservice.request.OfferBonusReq;
public class OfferBonusTests extends BaseClassSetup {
	@Test(description = "Make a request to OfferBonus - wagering bonus. Positive scenario.")
	public void offerBonus_WageringBonus_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.result("ok")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, PTAdminEndpoints.offerBonusSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to OfferBonus - golden chips. Positive scenario.")
	public void offerBonus_GoldenChips_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.description("AddBonus")
				.transactionDate("2020-11-20T13:44:00Z")
				.templateId("38854")
				.goldenChipsCount(1)
				.goldenChipsUnitValue("10")
				.amount(null)
				.build();

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.result("ok")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, PTAdminEndpoints.offerBonusSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to offerBonus. Missing user_id parameter.")
	public void offerBonus_MissingUserid_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.offerBonusError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to offerBonus. Missing product_id parameter.")
	public void offerBonus_MissingProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.productId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.offerBonusError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to offerBonus. Wrong method.")
	public void offerBonus_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder().defaults()
				.id(idForRequestToBeEchoedBackInResponseId).method("INVALID_METHOD_NAME").build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.offerBonusError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
