package tests.playtechadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.playtechadminservice.enums.PTAdminEndpoints;
import tests.playtechadminservice.request.GetDynamicBalancesReq;
import tests.playtechadminservice.response.Balance;
import tests.playtechadminservice.response.GetDynamicBalancesResp;
public class GetDynamicBalancesTests extends BaseClassSetup {
	@Test(description = "Make a request to GetDynamicBalances. Positive scenario.")
	public void getDynamicBalances_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetDynamicBalancesReq request = new GetDynamicBalancesReq.Builder()
				.defaults()
				.addRequestedBalances("ringfenced_real_balance")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		Balance balance = new Balance.Builder().defaults().build();

		GetDynamicBalancesResp expectedResponse = new GetDynamicBalancesResp.Builder()
				.defaults()
				.addBalance(balance)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetDynamicBalancesResp actualResponse =  BaseRequest.post(request, PTAdminEndpoints.getDynamicBalancesSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to getDynamicBalances. Missing user_id parameter.")
	public void getDynamicBalances_MissingUserid_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetDynamicBalancesReq request = new GetDynamicBalancesReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.getDynamicBalancesError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getDynamicBalances. Missing product_id parameter.")
	public void getDynamicBalances_MissingProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetDynamicBalancesReq request = new GetDynamicBalancesReq.Builder()
				.defaults()
				.productId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.getDynamicBalancesError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getDynamicBalances. Wrong method.")
	public void getDynamicBalances_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetDynamicBalancesReq request = new GetDynamicBalancesReq.Builder().defaults()
				.id(idForRequestToBeEchoedBackInResponseId).method("INVALID_METHOD_NAME").build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.getDynamicBalancesError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
