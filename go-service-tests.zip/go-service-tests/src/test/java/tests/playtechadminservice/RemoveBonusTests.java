package tests.playtechadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.playtechadminservice.enums.PTAdminEndpoints;
import tests.playtechadminservice.request.OfferBonusReq;
import tests.playtechadminservice.request.RemoveBonusReq;
import tests.playtechadminservice.request.SearchPlayerBonusesReq;
import tests.playtechadminservice.response.Bonus;
import tests.playtechadminservice.response.SearchPlayerBonusesResp;

public class RemoveBonusTests extends BaseClassSetup {
	@Test(description = "Make a request to RemoveBonus - wagering bonus. Positive scenario.")
	public void removeBonus_WageringBonus_Positive_Scenario() throws InterruptedException {

		Instant testStartTime = Instant.now().minusSeconds(3);

		Integer testUserId = 4700685;

		String idForOfferBonus = UUID.randomUUID().toString();

		OfferBonusReq requestOfferBonus = new OfferBonusReq.Builder()
				.defaults()
				.userId(testUserId)
				.id(idForOfferBonus)
				.build();

		ResultOKResp expectedOfferBonusResponse = new ResultOKResp.Builder()
				.result("ok")
				.id(idForOfferBonus)
				.build();

		ResultOKResp actualOfferBonusResponse =  BaseRequest.post(requestOfferBonus, PTAdminEndpoints.offerBonusSuccess);

		assertReflectionEquals(expectedOfferBonusResponse, actualOfferBonusResponse);	

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SearchPlayerBonusesReq request = new SearchPlayerBonusesReq.Builder()
				.defaults()
				.userId(testUserId)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		SearchPlayerBonusesResp actualResponse =  BaseRequest.post(request, PTAdminEndpoints.searchPlayerBonusesSuccess);

		List<Bonus>bonuses = actualResponse.getBonuses();
		Integer newlyCreatedBonusInstanceCode = 0;

		for (Bonus bonus : bonuses) {
			Long timeSinceTestStarted = Duration.between(testStartTime, bonus.getIssueDateAsInstant()).toMillis();
			if (timeSinceTestStarted >= 0) {
				newlyCreatedBonusInstanceCode = Integer.parseInt(bonus.getBonusInstanceCode());
				break;
			}
		}

		String idForRemoveBonus = UUID.randomUUID().toString();

		RemoveBonusReq requestRemoveBonus = new RemoveBonusReq.Builder()
				.defaults()
				.userId(testUserId)
				.bonusInstanceCode(newlyCreatedBonusInstanceCode)
				.id(idForRemoveBonus)
				.build();

		ResultOKResp expectedRemoveBonusResponse = new ResultOKResp.Builder()
				.result("ok")
				.id(idForRemoveBonus)
				.build();

		ResultOKResp actualRemoveBonusResponse =  BaseRequest.post(requestRemoveBonus, PTAdminEndpoints.removeBonusSuccess);

		assertReflectionEquals(expectedRemoveBonusResponse, actualRemoveBonusResponse);	
	}

	@Test(description = "Make a request to removeBonus. Missing user_id parameter.")
	public void removeBonus_MissingUserid_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RemoveBonusReq request = new RemoveBonusReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.removeBonusError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to removeBonus. Missing product_id parameter.")
	public void removeBonus_MissingProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RemoveBonusReq request = new RemoveBonusReq.Builder()
				.defaults()
				.productId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.removeBonusError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to removeBonus. Wrong method.")
	public void removeBonus_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RemoveBonusReq request = new RemoveBonusReq.Builder().defaults()
				.id(idForRequestToBeEchoedBackInResponseId).method("INVALID_METHOD_NAME").build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.removeBonusError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
