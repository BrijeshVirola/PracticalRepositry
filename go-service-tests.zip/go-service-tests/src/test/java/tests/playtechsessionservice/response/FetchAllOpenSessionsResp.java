package tests.playtechsessionservice.response;

import tests.playtechsessionservice.responseobjects.FetchAllOpenSessionsRespOpenSessionObject;
import tests.playtechsessionservice.responseobjects.FetchAllOpenSessionsRespResultObject;

public class FetchAllOpenSessionsResp {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private FetchAllOpenSessionsRespResultObject result;

	public FetchAllOpenSessionsResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public String getId() {
		return id;
	}

	public FetchAllOpenSessionsRespResultObject getResult() {
		return result;
	}

	public static class Builder {

		private String id;
		private FetchAllOpenSessionsRespResultObject result;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder result(FetchAllOpenSessionsRespResultObject result) {
			this.result = result;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.result = new FetchAllOpenSessionsRespResultObject
					.Builder()
					.defaults()
					.addJackpot(
							new FetchAllOpenSessionsRespOpenSessionObject
							.Builder()
							.defaults()
							.build())
					.build();
			return this;
		}
		
		public FetchAllOpenSessionsResp build() {
			return new FetchAllOpenSessionsResp(this);
		}

	}

}
