package tests.playtechsessionservice.response;

import java.util.HashMap;
import java.util.Map;

public class CheckOpenSessionResp {
	
	@SuppressWarnings("unused")
	private String id;
	private Map<String, Object> result = new HashMap<>();
	
	private CheckOpenSessionResp(Builder builder) {
		this.id = builder.id;
		this.result.put("is_open", builder.isOpen);
	}
	
	public static class Builder {

		private String id;
		private Boolean isOpen;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder isOpen(Boolean isOpen) {
			this.isOpen = isOpen;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.isOpen = false;
			return this;
		}
		
		public CheckOpenSessionResp build() {
			return new CheckOpenSessionResp(this);
		}
		
	}

}
