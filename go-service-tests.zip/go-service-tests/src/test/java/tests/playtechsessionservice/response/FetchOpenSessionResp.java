package tests.playtechsessionservice.response;

import java.util.HashMap;
import java.util.Map;

public class FetchOpenSessionResp {
	
	@SuppressWarnings("unused")
	private String id;
	private Map<String, Object> result = new HashMap<>();

	private FetchOpenSessionResp(Builder builder) {
		this.id = builder.id;
		this.result.put("user_id", builder.userId);
		this.result.put("username", builder.userName);
		this.result.put("casino_name", builder.casinoName);
		this.result.put("session_id", builder.sessionId);
	}

	public static class Builder {
		private String id;
		private Integer userId;
		private String userName;
		private String casinoName;
		private String sessionId;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder userId(Integer userId) {
			this.userId = userId;
			return this;
		}

		public Builder userName(String userName) {
			this.userName = userName;
			return this;
		}

		public Builder casinoName(String casinoName) {
			this.casinoName = casinoName;
			return this;
		}

		public Builder sessionId(String sessionId) {
			this.sessionId = sessionId;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.userId = 12345;
			this.userName = "ov4ar";
			this.casinoName = "ptstaging2.139";
			this.sessionId = "E3C36F861FEF4CFB9414A174144C5A99000004";
			return this;
		}

		public FetchOpenSessionResp build() {
			return new FetchOpenSessionResp(this);
		}

	}
	
}
