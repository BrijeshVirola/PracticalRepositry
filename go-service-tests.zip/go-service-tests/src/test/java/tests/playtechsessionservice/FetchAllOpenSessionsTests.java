package tests.playtechsessionservice;

import static org.junit.Assert.assertNotNull;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.playtechsessionservice.enums.PTSessionEndpoints;
import tests.playtechsessionservice.request.FetchAllOpenSessionsReq;
import tests.playtechsessionservice.request.StartSessionReq;
import tests.playtechsessionservice.response.FetchAllOpenSessionsResp;

public class FetchAllOpenSessionsTests extends BaseClassSetup {

	@Test(description = "Make a request to fetch all open sessions. Positive scenario.")
	public void FetchAllOpenSessions_Positive_Scenario() {

		String id = UUID.randomUUID().toString();
		String playtechSessionToken = UUID.randomUUID().toString();
		String sessionId = UUID.randomUUID().toString();


		StartSessionReq startSessionRequestBody = new StartSessionReq
				.Builder()
				.defaults()
				.id(id)
				.playtechSessionToken(playtechSessionToken)
				.sessionId(sessionId)
				.build();

		BaseRequest.post(startSessionRequestBody, PTSessionEndpoints.startPlaytechSessionSuccess);

		FetchAllOpenSessionsReq requestBody = new FetchAllOpenSessionsReq
				.Builder()
				.defaults()
				.Id(id)
				.build();

		FetchAllOpenSessionsResp actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.fetchAllOpenSessionsSuccess);

		assertNotNull(actualResponse.getResult().getOpenSessions().get(0).getUser_id());
		assertNotNull(actualResponse.getResult().getOpenSessions().get(0).getOpen_date_time_utc());
		assertNotNull(actualResponse.getResult().getOpenSessions().get(0).getSession_id());

	}

	@Test(description = "Make a request to fetch all open sessions with invalid method name. Negative scenario.")
	public void FetchAllOpenSessions_With_Invalid_Method_name_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		FetchAllOpenSessionsReq requestBody = new FetchAllOpenSessionsReq
				.Builder()
				.defaults()
				.Id(id)
				.method("XXX")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(requestBody, PTSessionEndpoints.fetchAllOpenSessionsError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(null)
				.code(6)
				.message("Incorrect method in request")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}
