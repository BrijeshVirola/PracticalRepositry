package tests.playtechsessionservice.responseobjects;

import java.util.ArrayList;
import java.util.List;

public class FetchAllOpenSessionsRespResultObject {
	
	@SuppressWarnings("unused")
	private List<FetchAllOpenSessionsRespOpenSessionObject> open_sessions;
	
	private FetchAllOpenSessionsRespResultObject(Builder builder) {
		this.open_sessions = builder.openSessions;
	}
	
	public List<FetchAllOpenSessionsRespOpenSessionObject> getOpenSessions() {
		return open_sessions;
	}

	public static class Builder {
		
		private List<FetchAllOpenSessionsRespOpenSessionObject> openSessions;
		
		public Builder addJackpot(FetchAllOpenSessionsRespOpenSessionObject jackpot) {
			openSessions.add(jackpot);
			return this;
		}
		
		public Builder defaults() {
			openSessions= new ArrayList<>();
			return this;
		}
		
		public FetchAllOpenSessionsRespResultObject build() {
			return new FetchAllOpenSessionsRespResultObject(this);
		}
			
	}

}
