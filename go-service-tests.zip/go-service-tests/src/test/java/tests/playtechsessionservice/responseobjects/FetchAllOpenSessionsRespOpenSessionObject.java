package tests.playtechsessionservice.responseobjects;

public class FetchAllOpenSessionsRespOpenSessionObject {
	
	@SuppressWarnings("unused")
	private String session_id;
	@SuppressWarnings("unused")
	private Integer user_id;
	@SuppressWarnings("unused")
	private String open_date_time_utc;

	private FetchAllOpenSessionsRespOpenSessionObject(Builder builder) {
		this.session_id = builder.sessionId;
		this.user_id = builder.userId;
		this.open_date_time_utc = builder.openDateTimeUtc;
	}
	
	public String getSession_id() {
		return session_id;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public String getOpen_date_time_utc() {
		return open_date_time_utc;
	}

	public static class Builder {
		
		private String sessionId;
		private Integer userId;
		private String openDateTimeUtc;
		
		public Builder sessionId(String sessionId) {
			this.sessionId = sessionId;
			return this;
		}
		
		public Builder userId(Integer userId) {
			this.userId = userId;
			return this;
		}
		
		public Builder openDateTimeUtc(String openDateTimeUtc) {
			this.openDateTimeUtc = openDateTimeUtc;
			return this;
		}
		
		public Builder defaults() {
			this.sessionId = "A6BB9A8AF3F84DD99387D8B29C90E625000004";
			this.userId = 2825451;
			this.openDateTimeUtc = "2021-12-13T19:22:34.73Z";
			return this;
		}
		
		public FetchAllOpenSessionsRespOpenSessionObject build() {
			return new FetchAllOpenSessionsRespOpenSessionObject(this);
		}
		
	}

}
