package tests.playtechsessionservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.common.response.ResultOKResp;
import tests.playtechsessionservice.response.CheckOpenSessionResp;
import tests.playtechsessionservice.response.FetchAllOpenSessionsResp;
import tests.playtechsessionservice.response.FetchOpenSessionResp;

public enum PTSessionEndpoints implements ResponseEndpoints {

	startPlaytechSessionSuccess(ResultOKResp.class, "startsession"),
	startPlaytechSessionError(CustomErrorResponse.class, "startsession"),
	endSessionSuccess(ResultOKResp.class, "endsession"),
	endSessionError(CustomErrorResponse.class, "endsession"),
	fetchAllOpenSessionsSuccess(FetchAllOpenSessionsResp.class, "fetchallopensessions"),
	fetchAllOpenSessionsError(CustomErrorResponse.class, "fetchallopensessions"),
	checkOpenSessionSuccess(CheckOpenSessionResp.class, "checkopensession"),
	checkOpenSessionError(CustomErrorResponse.class, "checkopensession"),
	fetchOpenSessionSuccess(FetchOpenSessionResp.class, "fetchopensession"),
	fetchOpenSessionError(CustomErrorResponse.class, "fetchopensession");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> PTSessionEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
