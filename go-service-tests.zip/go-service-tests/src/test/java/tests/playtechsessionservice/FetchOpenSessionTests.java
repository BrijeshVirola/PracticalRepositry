package tests.playtechsessionservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.playtechsessionservice.enums.PTSessionEndpoints;
import tests.playtechsessionservice.request.EndSessionReq;
import tests.playtechsessionservice.request.FetchOpenSessionReq;
import tests.playtechsessionservice.request.StartSessionReq;
import tests.playtechsessionservice.response.FetchOpenSessionResp;

public class FetchOpenSessionTests extends BaseClassSetup {

	@Test(description = "Make a request to fetch open session. Positive scenario.")
	public void FetchOpenSession_Positive_Scenario() {

		String id = UUID.randomUUID().toString();
		String playtechSessionToken = UUID.randomUUID().toString();
		String sessionId = UUID.randomUUID().toString();

		StartSessionReq startSessionrequestBody = new StartSessionReq
				.Builder()
				.defaults()
				.id(id)
				.userId(4708521)
				.playtechSessionToken(playtechSessionToken)
				.sessionId(sessionId)
				.build();

		BaseRequest.post(startSessionrequestBody, PTSessionEndpoints.startPlaytechSessionSuccess);

		FetchOpenSessionReq requestBody = new FetchOpenSessionReq
				.Builder()
				.defaults()
				.id(id)
				.sessionId(sessionId)
				.build();

		FetchOpenSessionResp actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.fetchOpenSessionSuccess);

		FetchOpenSessionResp expectedResponse = new FetchOpenSessionResp
				.Builder()
				.defaults()
				.id(id)
				.userId(4708521)
				.sessionId(sessionId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to fetch open session. Negative scenario.")
	public void FetchOpenSession_With_Ended_Session_Negative_Scenario() {

		String id = UUID.randomUUID().toString();
		String playtechSessionToken = UUID.randomUUID().toString();
		String sessionId = UUID.randomUUID().toString();

		StartSessionReq startSessionrequestBody = new StartSessionReq
				.Builder()
				.defaults()
				.id(id)
				.playtechSessionToken(playtechSessionToken)
				.sessionId(sessionId)
				.build();

		BaseRequest.post(startSessionrequestBody, PTSessionEndpoints.startPlaytechSessionSuccess);

		EndSessionReq endSessionrequestBody = new EndSessionReq
				.Builder()
				.defaults()
				.id(id)
				.playtechSessionToken(playtechSessionToken)
				.sessionId(sessionId)
				.build();

		BaseRequest.post(endSessionrequestBody, PTSessionEndpoints.endSessionSuccess);

		FetchOpenSessionReq requestBody = new FetchOpenSessionReq
				.Builder()
				.defaults()
				.id(id)
				.sessionId(sessionId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.fetchOpenSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(1005)
				.message("Open Playtech session does not exist")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to fetch open session with null sessionId in params. Negative scenario.")
	public void FetchOpenSession_Missing_Params_sessionId_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		FetchOpenSessionReq requestBody = new FetchOpenSessionReq
				.Builder()
				.defaults()
				.id(id)
				.sessionId(null)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.fetchOpenSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(7)
				.message("Missing parameter: session_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

}
