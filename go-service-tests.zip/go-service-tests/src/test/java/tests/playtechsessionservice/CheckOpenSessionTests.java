package tests.playtechsessionservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.playtechsessionservice.enums.PTSessionEndpoints;
import tests.playtechsessionservice.request.CheckOpenSessionReq;
import tests.playtechsessionservice.response.CheckOpenSessionResp;

public class CheckOpenSessionTests extends BaseClassSetup {

	@Test(description = "Make a request to check open session. Positive scenario.")
	public void CheckOpenSession_Positive_Scenario() {

		String id = UUID.randomUUID().toString();
		String sessionId = UUID.randomUUID().toString();

		CheckOpenSessionReq requestBody = new CheckOpenSessionReq
				.Builder()
				.defaults()
				.id(id)
				.sessionId(sessionId)
				.build();

		CheckOpenSessionResp actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.checkOpenSessionSuccess);

		CheckOpenSessionResp expectedResponse = new CheckOpenSessionResp
				.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to check open session with null sessionId in params. Negative scenario.")
	public void CheckOpenSession_Missing_Params_sessionId_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		CheckOpenSessionReq requestBody = new CheckOpenSessionReq
				.Builder()
				.defaults()
				.id(id)
				.sessionId("")
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.checkOpenSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(7)
				.message("Missing parameter: session_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

}
