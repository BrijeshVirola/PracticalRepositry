package tests.playtechsessionservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.playtechsessionservice.enums.PTSessionEndpoints;
import tests.playtechsessionservice.request.StartSessionReq;

public class StartSessionTests extends BaseClassSetup{

	@Test(description = "Make a request to start session and kill the same session. Positive scenario.")
	public void StartSession_Positive_Scenario() {

		String id = UUID.randomUUID().toString();
		String playtechSessionToken = UUID.randomUUID().toString();
		String sessionId = UUID.randomUUID().toString();


		StartSessionReq requestBody = new StartSessionReq
				.Builder()
				.defaults()
				.id(id)
				.playtechSessionToken(playtechSessionToken)
				.sessionId(sessionId)
				.build();

		ResultOKResp actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.startPlaytechSessionSuccess);

		ResultOKResp expectedResponse = new ResultOKResp
				.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to start session for the existing Playtech Session Token. Negative scenario.")
	public void StartSession_With_Existing_PlaytechSession_Token_Negative_Scenario() {

		String id = UUID.randomUUID().toString();
		String playtechSessionToken = UUID.randomUUID().toString();
		String sessionId = UUID.randomUUID().toString();

		StartSessionReq requestBody = new StartSessionReq
				.Builder()
				.defaults()
				.id(id)
				.playtechSessionToken(playtechSessionToken)
				.sessionId(sessionId)
				.build();

		BaseRequest.post(requestBody, PTSessionEndpoints.startPlaytechSessionSuccess);

		StartSessionReq existinPlayTechSessionTokenRequestBody = new StartSessionReq
				.Builder()
				.defaults()
				.id(id)
				.playtechSessionToken(playtechSessionToken)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(existinPlayTechSessionTokenRequestBody, PTSessionEndpoints.startPlaytechSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(1002)
				.message("Playtech session token already exists")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to start session with null user_id in params. Negative scenario.")
	public void StartSession_Missing_Params_user_id_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		StartSessionReq requestBody = new StartSessionReq
				.Builder()
				.defaults()
				.id(id)
				.userId(null)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.startPlaytechSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(7)
				.message("Missing parameter: user_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to start session with null username in params. Negative scenario.")
	public void StartSession_Missing_Params_username_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		StartSessionReq requestBody = new StartSessionReq
				.Builder()
				.defaults()
				.id(id)
				.userName(null)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.startPlaytechSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(7)
				.message("Missing parameter: username")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to start session with null casino_name in params. Negative scenario.")
	public void StartSession_Missing_Params_casino_name_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		StartSessionReq requestBody = new StartSessionReq
				.Builder()
				.defaults()
				.id(id)
				.casinoName(null)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.startPlaytechSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(7)
				.message("Missing parameter: casino_name")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to start session with null playtech_session_token in params. Negative scenario.")
	public void StartSession_Missing_Params_playtech_session_token_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		StartSessionReq requestBody = new StartSessionReq
				.Builder()
				.defaults()
				.id(id)
				.playtechSessionToken(null)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.startPlaytechSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(7)
				.message("Missing parameter: playtech_session_token")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to start session with null session_id in params. Negative scenario.")
	public void StartSession_Missing_Params_session_id_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		StartSessionReq requestBody = new StartSessionReq
				.Builder()
				.defaults()
				.id(id)
				.sessionId(null)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.startPlaytechSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(7)
				.message("Missing parameter: session_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to start session with null product_id in params. Negative scenario.")
	public void StartSession_Missing_Params_product_id_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		StartSessionReq requestBody = new StartSessionReq
				.Builder()
				.defaults()
				.id(id)
				.productId(null)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.startPlaytechSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(7)
				.message("Missing parameter: product_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

}
