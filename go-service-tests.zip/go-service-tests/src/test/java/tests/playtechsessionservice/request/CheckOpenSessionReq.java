package tests.playtechsessionservice.request;

import java.util.HashMap;
import java.util.Map;

public class CheckOpenSessionReq {

	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	private Map<String, Object> Params = new HashMap<>();

	private CheckOpenSessionReq(Builder builder) {
		this.Method = builder.method;
		this.ID = builder.id;
		this.Params.put("session_id", builder.sessionId);
	}

	public static class Builder {

		private String method;
		private String id;
		private String sessionId;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder sessionId(String sessionId) {
			this.sessionId = sessionId;
			return this;
		}

		public Builder defaults() {
			this.method = "checkopensession";
			this.id = "1";
			this.sessionId = "A6BB9A8AF3F84DD99387D8B29C90E625000004";
			return this;
		}

		public CheckOpenSessionReq build() {
			return new CheckOpenSessionReq(this);
		}

	}

}
