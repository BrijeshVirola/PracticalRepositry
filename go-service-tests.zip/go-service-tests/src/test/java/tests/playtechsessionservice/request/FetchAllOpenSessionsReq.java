package tests.playtechsessionservice.request;

import java.util.HashMap;
import java.util.Map;

public class FetchAllOpenSessionsReq {

	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	private Map<String, Object> Params = new HashMap<>();
	
	private FetchAllOpenSessionsReq(Builder builder) {
		this.Method = builder.method;
		this.ID = builder.id;
		this.Params.put("open_after_utc", builder.openAfterUtc);
	}
	
	public static class Builder {
		
		private String method;
		private String id;
		private String openAfterUtc;
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder Id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder openAfterUtc(String openAfterUtc) {
			this.openAfterUtc = openAfterUtc;
			return this;
		}
		
		public Builder defaults() {
			this.method = "fetchallopensessions";
			this.id = "1";
			this.openAfterUtc = "2022-01-06T12:13:26Z";
			return this;
		}
		
		public FetchAllOpenSessionsReq build() {
			return new FetchAllOpenSessionsReq(this);
		}
		
	}

}
