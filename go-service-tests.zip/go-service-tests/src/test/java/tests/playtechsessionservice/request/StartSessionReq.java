package tests.playtechsessionservice.request;

import java.util.HashMap;
import java.util.Map;

public class StartSessionReq {

	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	private Map<String, Object> Params = new HashMap<>();

	private StartSessionReq(Builder builder) {
		this.Method = builder.method;
		this.ID = builder.id;
		this.Params.put("user_id", builder.userId);
		this.Params.put("username", builder.userName);
		this.Params.put("casino_name", builder.casinoName);
		this.Params.put("playtech_session_token", builder.playtechSessionToken);
		this.Params.put("session_id", builder.sessionId);
		this.Params.put("product_id", builder.productId);
		this.Params.put("is_web", builder.isWeb);
	}

	public static class Builder {
		private String method;
		private String id;
		private Integer userId;
		private String userName;
		private String casinoName;
		private String playtechSessionToken;
		private String sessionId;
		private Integer productId;
		private Boolean isWeb;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder userId(Integer userId) {
			this.userId = userId;
			return this;
		}

		public Builder userName(String userName) {
			this.userName = userName;
			return this;
		}

		public Builder casinoName(String casinoName) {
			this.casinoName = casinoName;
			return this;
		}

		public Builder playtechSessionToken(String playtechSessionToken) {
			this.playtechSessionToken = playtechSessionToken;
			return this;
		}

		public Builder sessionId(String sessionId) {
			this.sessionId = sessionId;
			return this;
		}

		public Builder productId(Integer productId) {
			this.productId = productId;
			return this;
		}

		public Builder isWeb(Boolean isWeb) {
			this.isWeb = isWeb;
			return this;
		}

		public Builder defaults() {
			this.method = "startsession";
			this.id = "1";
			this.userId = 12345;
			this.userName = "ov4ar";
			this.casinoName = "ptstaging2.139";
			this.playtechSessionToken = "29e15293-eccb-4af0-bb8f-4e57c7d39538";
			this.sessionId = "E3C36F861FEF4CFB9414A174144C5A98000004";
			this.productId = 2;
			this.isWeb = false;
			return this;
		}

		public StartSessionReq build() {
			return new StartSessionReq(this);
		}

	}

}
