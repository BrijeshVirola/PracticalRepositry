package tests.playtechsessionservice.request;

import java.util.HashMap;
import java.util.Map;

public class EndSessionReq {

	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	private Map<String, Object> Params = new HashMap<>();

	private EndSessionReq(Builder builder) {
		this.Method = builder.method;
		this.ID = builder.id;
		this.Params.put("user_id", builder.userId);
		this.Params.put("playtech_session_token", builder.playtechSessionToken);
		this.Params.put("session_id", builder.sessionId);
	}

	public static class Builder {
		private String method;
		private String id;
		private Integer userId;
		private String playtechSessionToken;
		private String sessionId;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder userId(Integer userId) {
			this.userId = userId;
			return this;
		}

		public Builder playtechSessionToken(String playtechSessionToken) {
			this.playtechSessionToken = playtechSessionToken;
			return this;
		}

		public Builder sessionId(String sessionId) {
			this.sessionId = sessionId;
			return this;
		}

		public Builder defaults() {
			this.method = "endsession";
			this.id = "1";
			this.userId = 12345;
			this.playtechSessionToken = "0FC651D3-FC86-470C-8056-41389296F865";
			this.sessionId = "E3C36F861FEF4CFB9414A174144C5A98000004";
			return this;
		}

		public EndSessionReq build() {
			return new EndSessionReq(this);
		}

	}

}
