package tests.playtechsessionservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.apache.commons.lang.RandomStringUtils;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.playtechsessionservice.enums.PTSessionEndpoints;
import tests.playtechsessionservice.request.EndSessionReq;
import tests.playtechsessionservice.request.StartSessionReq;

public class EndSessionTests extends BaseClassSetup {

	@Test(description = "Make a request to end session. Positive scenario.")
	public void EndSession_Positive_Scenario() {

		String id = UUID.randomUUID().toString();
		String playtechSessionToken = UUID.randomUUID().toString();
		String sessionId = RandomStringUtils.randomAlphanumeric(38).toUpperCase();

		StartSessionReq startSessionRequestBody = new StartSessionReq
				.Builder()
				.defaults()
				.id(id)
				.userId(4708527)
				.playtechSessionToken(playtechSessionToken)
				.sessionId(sessionId)
				.build();

		BaseRequest.post(startSessionRequestBody, PTSessionEndpoints.startPlaytechSessionSuccess);

		EndSessionReq requestBody = new EndSessionReq
				.Builder()
				.defaults()
				.id(id)
				.userId(4708527)
				.playtechSessionToken(playtechSessionToken)
				.sessionId(sessionId)
				.build();

		ResultOKResp actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.endSessionSuccess);

		ResultOKResp expectedResponse = new ResultOKResp
				.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to end session with null userId in params. Negative scenario.")
	public void EndSession_Missing_Params_userId_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();
		String playtechSessionToken = UUID.randomUUID().toString();
		String sessionId = RandomStringUtils.randomAlphanumeric(38).toUpperCase();

		EndSessionReq requestBody = new EndSessionReq
				.Builder()
				.defaults()
				.id(id)
				.userId(null)
				.playtechSessionToken(playtechSessionToken)
				.sessionId(sessionId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.endSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(7)
				.message("Missing parameter: user_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to end session with null playtech_session_token in params. Negative scenario.")
	public void EndSession_Missing_Params_playtech_session_token_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();
		String sessionId = RandomStringUtils.randomAlphanumeric(38).toUpperCase();

		EndSessionReq requestBody = new EndSessionReq
				.Builder()
				.defaults()
				.id(id)
				.playtechSessionToken(null)
				.sessionId(sessionId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.endSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(7)
				.message("Missing parameter: playtech_session_token")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to end session with null session_id in params. Negative scenario.")
	public void EndSession_Missing_Params_session_id_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();
		String playtechSessionToken = UUID.randomUUID().toString();

		EndSessionReq requestBody = new EndSessionReq
				.Builder()
				.defaults()
				.id(id)
				.playtechSessionToken(playtechSessionToken)
				.sessionId(null)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.endSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(7)
				.message("Missing parameter: session_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to end session with already ended Playtech Session Token in params. Negative scenario.")
	public void EndSession_Already_Ended_Session_Token_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();
		String playtechSessionToken = UUID.randomUUID().toString();
		String sessionId = RandomStringUtils.randomAlphanumeric(38).toUpperCase();

		StartSessionReq startSessionRequestBody = new StartSessionReq
				.Builder()
				.defaults()
				.id(id)
				.playtechSessionToken(playtechSessionToken)
				.sessionId(sessionId)
				.build();

		BaseRequest.post(startSessionRequestBody, PTSessionEndpoints.startPlaytechSessionSuccess);

		EndSessionReq endSessionRequestBody = new EndSessionReq
				.Builder()
				.defaults()
				.id(id)
				.playtechSessionToken(playtechSessionToken)
				.sessionId(sessionId)
				.build();

		BaseRequest.post(endSessionRequestBody, PTSessionEndpoints.endSessionSuccess);

		EndSessionReq requestBody = new EndSessionReq
				.Builder()
				.defaults()
				.id(id)
				.playtechSessionToken(playtechSessionToken)
				.sessionId(sessionId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.endSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(1003)
				.message("Playtech session associated with this token is already ended")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to end session with not started Playtech Session Token in params. Negative scenario.")
	public void EndSession_Not_Started_Session_Token_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();
		String playtechSessionToken = UUID.randomUUID().toString();
		String sessionId = RandomStringUtils.randomAlphanumeric(38).toUpperCase();

		EndSessionReq requestBody = new EndSessionReq
				.Builder()
				.defaults()
				.id(id)
				.playtechSessionToken(playtechSessionToken)
				.sessionId(sessionId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PTSessionEndpoints.endSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(1004)
				.message("Playtech session associated with this token is not started")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

}
