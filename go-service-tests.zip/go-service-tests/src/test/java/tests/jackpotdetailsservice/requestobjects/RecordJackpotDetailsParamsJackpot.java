package tests.jackpotdetailsservice.requestobjects;

import java.math.BigDecimal;

public class RecordJackpotDetailsParamsJackpot {
	
	@SuppressWarnings("unused")
	private BigDecimal contribution;
	@SuppressWarnings("unused")
	private BigDecimal win;
	@SuppressWarnings("unused")
	private String code;
	@SuppressWarnings("unused")
	private String network_id;
	
	private RecordJackpotDetailsParamsJackpot(Builder builder) {
		this.contribution = builder.contribution;
		this.win = builder.win;
		this.code = builder.code;
		this.network_id = builder.network_id;
	}
	
	public static class Builder {
		
		private BigDecimal contribution;
		private BigDecimal win;
		private String code;
		private String network_id;

		public Builder contribution(BigDecimal contribution) {
			this.contribution = contribution;
			return this;
		}

		public Builder win(BigDecimal win) {
			this.win = win;
			return this;
		}
		
		public Builder code(String code) {
			this.code = code;
			return this;
		}
		
		public Builder networkId(String networkId) {
			this.network_id = networkId;
			return this;
		}

		public Builder defaults() {
			this.contribution = new BigDecimal("2.55");
			this.win = new BigDecimal("0.78");		
			this.code = "MegaPot";
			this.network_id = "TheJackpotNetwork";		
			return this;
		}

		public RecordJackpotDetailsParamsJackpot build() {
			RecordJackpotDetailsParamsJackpot jackpot = new RecordJackpotDetailsParamsJackpot(this);
			return jackpot;
		}
	}
}
