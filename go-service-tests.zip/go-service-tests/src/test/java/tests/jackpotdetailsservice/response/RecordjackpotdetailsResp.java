package tests.jackpotdetailsservice.response;

public class RecordjackpotdetailsResp {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Result result;
	
	public RecordjackpotdetailsResp(String id, boolean ok) {
		this.id = id;
		result = new Result(ok);
	}
	
	private class Result {
		
		@SuppressWarnings("unused")
		boolean OK;
		
		public Result(boolean ok) {
			this.OK = ok;
		}
		
	}
}
