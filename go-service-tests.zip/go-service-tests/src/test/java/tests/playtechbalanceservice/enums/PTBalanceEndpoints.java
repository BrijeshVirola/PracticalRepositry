package tests.playtechbalanceservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.playtechbalanceservice.response.GetBonusBalancesForProductResp;

public enum PTBalanceEndpoints implements ResponseEndpoints {

	getBonusBalancesForProductSuccess(GetBonusBalancesForProductResp.class, "GetBonusBalancesForProduct"),
	getBonusBalancesForProductError(CustomErrorResponse.class, "GetBonusBalancesForProduct");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> PTBalanceEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
