package tests.playtechbalanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.ExpectedFailure;
import common.enumsconstants.ProductId;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.playtechbalanceservice.enums.PTBalanceEndpoints;
import tests.playtechbalanceservice.request.GetBonusBalancesForProductReq;
import tests.playtechbalanceservice.response.GetBonusBalancesForProductResp;

public class GetBonusBalancesForProductTests extends BaseClassSetup {
	
	@DataProvider(name = "bonusBalance")
	private Object[][] bonusBalance() {
		return new Object[][] {
			{UsersId.GO_SVC_TEST123, ProductId.CASINO.getId(), "75.85", "0", "0", "0"},
			{UsersId.GO_SVC_TEST126, ProductId.LIVE_CASINO.getId(), "85.68", "0", "0", "0"},
			{UsersId.GO_SVC_TEST123, ProductId.POKER.getId(), "0", "0", "0", "0"},
			{UsersId.GO_SVC_TEST123, ProductId.BINGO.getId(), "0", "0", "0", "0"},
		};
	}
	
	@DataProvider(name = "ringFencedBalance")
	private Object[][] ringFencedBalance() {
		return new Object[][] {
			{ProductId.CASINO.getId(), "20", "0", "19", "0"},
			{ProductId.LIVE_CASINO.getId(), "0", "0", "0", "0"},
			{ProductId.POKER.getId(), "0", "0", "0", "0"},
			{ProductId.BINGO.getId(), "0", "0", "0", "0"},
		};
	}
	
	@DataProvider(name = "missingCasinoMapping")
	private Object[][] missingCasinoMapping() {
		return new Object[][] {
			{ProductId.SPORTSBOOK.getId()},
			{ProductId.GAMES.getId()},
			{ProductId.SLOTS.getId()},
		};
	}
	
	@DataProvider(name = "products")
	private Object[][] products() {
		return new Object[][] {
			{ProductId.CASINO.getId()},
			{ProductId.LIVE_CASINO.getId()},
			{ProductId.POKER.getId()},
			{ProductId.BINGO.getId()}
		};
	}
	
	@DataProvider(name = "productsMessage")
	private Object[][] productsMessage() {
		return new Object[][] {
			{ProductId.CASINO.getId(), "Failed to get Playtech balance"},
			{ProductId.LIVE_CASINO.getId(), "Failed to get Playtech balance"},
			{ProductId.POKER.getId(), "Failed to get Playtech balance"},
			{ProductId.BINGO.getId(), "VirtueFusion returned an error response"},
		};
	}
	
	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2425", action="commented out test for id field")
	@Test(description = "Make a request to GetBonusBalancesForProduct. Zero balance.")
	public void getBonusBalancesForProduct_Zero_Balance() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder()
				.defaults()
				.userId(UsersId.GO_SVC_TEST125)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetBonusBalancesForProductResp actualResponse =  BaseRequest.post(request, PTBalanceEndpoints.getBonusBalancesForProductSuccess);

		GetBonusBalancesForProductResp expectedResponse = new GetBonusBalancesForProductResp.Builder()
				.defaults()
				.id(null)//reinstate this test when PRJSAK-2425 is fixed
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2425", action="commented out test for id field")
	@Test(description = "Make a request to GetBonusBalancesForProduct. Ring fenced bonus.", dataProvider = "ringFencedBalance")
	public void getBonusBalancesForProduct_Ring_Fenced_Balance(int productId, String bonus_balance,
			String bonus_pending_winnings, String ringfenced_balance, String real_winnings_balance) throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder()
				.defaults()
				.userId(UsersId.GO_SVC_TEST121)
				.productId(productId)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetBonusBalancesForProductResp actualResponse =  BaseRequest.post(request, PTBalanceEndpoints.getBonusBalancesForProductSuccess);

		GetBonusBalancesForProductResp expectedResponse = new GetBonusBalancesForProductResp.Builder()
				.defaults()
				.bonusBalance(bonus_balance)
				.bonusPendingWinnings(bonus_pending_winnings)
				.ringfencedBalance(ringfenced_balance)
				.realWinningsBalance(real_winnings_balance)
				.id(null)//reinstate this test when PRJSAK-2425 is fixed
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2425", action="commented out test for id field")
	@Test(description = "Make a request to GetBonusBalancesForProduct. Bonus pending winnings.")
	public void getBonusBalancesForProduct_Bonus_Pending_Winnings() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder()
				.defaults()
				.userId(UsersId.GO_SVC_TEST122)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetBonusBalancesForProductResp actualResponse =  BaseRequest.post(request, PTBalanceEndpoints.getBonusBalancesForProductSuccess);

		GetBonusBalancesForProductResp expectedResponse = new GetBonusBalancesForProductResp.Builder()
				.defaults()
				.bonusBalance("20.25")
				.bonusPendingWinnings("1.8")
				.id(null)//reinstate this test when PRJSAK-2425 is fixed
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2425", action="commented out test for id field")
	@Test(description = "Make a request to GetBonusBalancesForProduct. Bonus balance.", dataProvider = "bonusBalance")
	public void getBonusBalancesForProduct_Bonus_Balance(int userId, int productId, String bonus_balance,
			String bonus_pending_winnings, String ringfenced_balance, String real_winnings_balance) throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder()
				.defaults()
				.userId(userId)
				.productId(productId)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetBonusBalancesForProductResp actualResponse =  BaseRequest.post(request, PTBalanceEndpoints.getBonusBalancesForProductSuccess);

		GetBonusBalancesForProductResp expectedResponse = new GetBonusBalancesForProductResp.Builder()
				.defaults()
				.bonusBalance(bonus_balance)
				.bonusPendingWinnings(bonus_pending_winnings)
				.ringfencedBalance(ringfenced_balance)
				.realWinningsBalance(real_winnings_balance)
				.id(null)//reinstate this test when PRJSAK-2425 is fixed
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2425", action="commented out test for id field, also disabled due to not clear how to reproduce")
	@Test(description = "Make a request to GetBonusBalancesForProduct. Real winnings balance.")
	public void getBonusBalancesForProduct_Real_Winnings_Balance() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder()
				.defaults()
				.userId(UsersId.GO_SVC_TEST124)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetBonusBalancesForProductResp actualResponse =  BaseRequest.post(request, PTBalanceEndpoints.getBonusBalancesForProductSuccess);

		GetBonusBalancesForProductResp expectedResponse = new GetBonusBalancesForProductResp.Builder()
				.defaults()
				.bonusBalance("30")
				.bonusPendingWinnings("0")
				.realWinningsBalance("2")
				.ringfencedBalance("30")
				.id(null)//reinstate this test when PRJSAK-2425 is fixed
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2425", action="commented out test for id field")
	@Test(description = "Make a request to getBonusBalancesForProduct. Missing user_id parameter.")
	public void getBonusBalancesForProduct_MissingUserid_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTBalanceEndpoints.getBonusBalancesForProductError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(null)//reinstate this test when PRJSAK-2425 is fixed
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2425", action="commented out test for id field")
	@Test(description = "Make a request to getBonusBalancesForProduct. Not existing user_id.", dataProvider = "products")
	public void getBonusBalancesForProduct_Not_Existing_Userid(int productId) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder()
				.defaults()
				.userId(1)
				.productId(productId)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTBalanceEndpoints.getBonusBalancesForProductError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Failed to get user core data")
				.id(null)//reinstate this test when PRJSAK-2425 is fixed
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2425", action="1. commented out test for id field, 2. Error should be shown.")
	@Test(description = "Make a request to getBonusBalancesForProduct. Australian user. Not Playtech available.", dataProvider = "productsMessage")
	public void getBonusBalancesForProduct_User_From_Country_Without_Playtech(int productId, String message) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder()
				.defaults()
				.userId(UsersId.GO_SVC_TEST128)
				.productId(productId)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTBalanceEndpoints.getBonusBalancesForProductError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message(message)
				.id(null)//reinstate this test when PRJSAK-2425 is fixed
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2425", action="commented out test for id field")
	@Test(description = "Make a request to getBonusBalancesForProduct. Missing product_id parameter.")
	public void getBonusBalancesForProduct_MissingProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder()
				.defaults()
				.productId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTBalanceEndpoints.getBonusBalancesForProductError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: product_id")
				.id(null)//reinstate this test when PRJSAK-2425 is fixed
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2425", action="commented out test for id field")
	@Test(description = "Make a request to getBonusBalancesForProduct. Missing casino mapping products.",
	dataProvider = "missingCasinoMapping")
	public void getBonusBalancesForProduct_MissingCasinoMappingProducts(int productId) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.productId(productId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTBalanceEndpoints.getBonusBalancesForProductError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Missing casino mapping for product and country group")
				.id(null)//reinstate this test when PRJSAK-2425 is fixed
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2425", action="commented out test for id field")
	@Test(description = "Make a request to getBonusBalancesForProduct. Missing params.")
	public void getBonusBalancesForProduct_MissingParams() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		request.removeParams();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTBalanceEndpoints.getBonusBalancesForProductError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(5)
				.message("Params missing from request")
				.id(null)//reinstate this test when PRJSAK-2425 is fixed
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getBonusBalancesForProduct. Wrong method.")
	public void getBonusBalancesForProduct_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder().defaults()
				.id(idForRequestToBeEchoedBackInResponseId).method("INVALID_METHOD_NAME").build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTBalanceEndpoints.getBonusBalancesForProductError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
