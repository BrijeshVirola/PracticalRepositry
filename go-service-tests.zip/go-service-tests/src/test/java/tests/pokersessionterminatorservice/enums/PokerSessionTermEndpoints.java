package tests.pokersessionterminatorservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.common.response.ResultOKResp;

public enum PokerSessionTermEndpoints implements ResponseEndpoints {

	addSessionSuccess(ResultOKResp.class, "addsession"),
	addSessionError(CustomErrorResponse.class, "addsession"),
	terminateSessionSuccess(ResultOKResp.class, "terminatesession"),
	terminateSessionError(CustomErrorResponse.class, "terminatesession"),
	forceLogoutSuccess(ResultOKResp.class, "forcelogout"),
	forceLogoutError(CustomErrorResponse.class, "forcelogout");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> PokerSessionTermEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
