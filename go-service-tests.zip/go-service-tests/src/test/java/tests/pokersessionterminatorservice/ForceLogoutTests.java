package tests.pokersessionterminatorservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.pokersessionterminatorservice.enums.PokerSessionTermEndpoints;
import tests.pokersessionterminatorservice.request.ForceLogoutReq;

public class ForceLogoutTests extends BaseClassSetup{

	@Test(description = "Make a request to force logout with a valid object. Positive scenario.")
	public void ForceLogout_Positive_Scenario() {

		String id = UUID.randomUUID().toString();

		ForceLogoutReq requestBody = new ForceLogoutReq
				.Builder()
				.defaults()
				.id(id)
				.build();

		ResultOKResp actualResponse = BaseRequest.post(requestBody, PokerSessionTermEndpoints.forceLogoutSuccess);

		ResultOKResp expectedResponse = new ResultOKResp
				.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to force logout with any casinoName value valid object. Positive scenario.")
	public void ForceLogout_Positive_Scenario_With_Any_casinoName_Value() {

		String id = UUID.randomUUID().toString();

		ForceLogoutReq requestBody = new ForceLogoutReq
				.Builder()
				.defaults()
				.id(id)
				.casinoName("XXX")
				.build();

		ResultOKResp actualResponse = BaseRequest.post(requestBody, PokerSessionTermEndpoints.forceLogoutSuccess);

		ResultOKResp expectedResponse = new ResultOKResp
				.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to force logout with a missing countdown_starting_seconds(optional) valid object. Positive scenario.")
	public void ForceLogout_Positive_Scenario_With_Missing_Optional_Params_Object() {

		String id = UUID.randomUUID().toString();

		ForceLogoutReq requestBody = new ForceLogoutReq
				.Builder()
				.defaults()
				.id(id)
				.countdownStartingSeconds(null)
				.build();

		ResultOKResp actualResponse = BaseRequest.post(requestBody, PokerSessionTermEndpoints.forceLogoutSuccess);

		ResultOKResp expectedResponse = new ResultOKResp
				.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to force logout with invalid method value. Negative scenario.")
	public void ForceLogout_Invalid_Method_Value_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		ForceLogoutReq requestBody = new ForceLogoutReq
				.Builder()
				.defaults()
				.id(id)
				.method("XXX")
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PokerSessionTermEndpoints.forceLogoutError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(null)
				.code(6)
				.message("Incorrect method in request")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to force logout with null userId in params. Negative scenario.")
	public void ForceLogout_Missing_Params_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		ForceLogoutReq requestBody = new ForceLogoutReq
				.Builder()
				.defaults()
				.id(id)
				.userId(null)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PokerSessionTermEndpoints.forceLogoutError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(7)
				.message("Missing/invalid parameter: user_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to force logout with invalid sessionId in params. Negative scenario.")
	public void ForceLogout_Invalid_Params_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		ForceLogoutReq requestBody = new ForceLogoutReq
				.Builder()
				.defaults()
				.id(id)
				.sessionId(null)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PokerSessionTermEndpoints.forceLogoutError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(7)
				.message("Missing parameter: session_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

}
