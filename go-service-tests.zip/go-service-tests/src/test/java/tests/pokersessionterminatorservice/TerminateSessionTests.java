package tests.pokersessionterminatorservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.pokersessionterminatorservice.enums.PokerSessionTermEndpoints;
import tests.pokersessionterminatorservice.request.TerminateSessionReq;

public class TerminateSessionTests {

	@Test(description = "Make a request to terminate session with a valid object. Positive scenario.")
	public void TerminateSession_Positive_Scenario() {

		String id = UUID.randomUUID().toString();

		TerminateSessionReq requestBody = new TerminateSessionReq
				.Builder()
				.defaults()
				.id(id)
				.build();

		ResultOKResp actualResponse = BaseRequest.post(requestBody, PokerSessionTermEndpoints.terminateSessionSuccess);

		ResultOKResp expectedResponse = new ResultOKResp
				.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to terminate session with invalid method value. Negative scenario.")
	public void TerminateSession_Invalid_Method_Value_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		TerminateSessionReq requestBody = new TerminateSessionReq
				.Builder()
				.defaults()
				.id(id)
				.method("XXX")
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PokerSessionTermEndpoints.terminateSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(null)
				.code(6)
				.message("Incorrect method in request")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to terminate session with null userId in params. Negative scenario.")
	public void TerminateSession_Missing_Params_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		TerminateSessionReq requestBody = new TerminateSessionReq
				.Builder()
				.defaults()
				.id(id)
				.userId(null)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PokerSessionTermEndpoints.terminateSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(7)
				.message("Missing/invalid parameter: user_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to terminate session with invalid sessionId in params. Negative scenario.")
	public void TerminateSession_Invalid_Params_Object_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		TerminateSessionReq requestBody = new TerminateSessionReq
				.Builder()
				.defaults()
				.id(id)
				.sessionId("XXX")
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, PokerSessionTermEndpoints.terminateSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(7)
				.message("Missing/invalid parameter: session_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

}
