package tests.pokersessionterminatorservice.request;

import java.util.HashMap;
import java.util.Map;

public class ForceLogoutReq {

	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private Map<String, Object> Params = new HashMap<>();

	private ForceLogoutReq(Builder builder) {
		this.Method = builder.method;
		this.ID = builder.id;
		this.Params.put("user_id", builder.userId);
		this.Params.put("username", builder.userName);
		this.Params.put("casino_name", builder.casinoName);
		this.Params.put("session_id", builder.sessionId);
		this.Params.put("countdown_starting_seconds", builder.countdownStartingSeconds);		
	}

	public static class Builder {

		private String method;
		private String id;
		private Integer userId;
		private String userName;
		private String casinoName;
		private String sessionId;
		private Integer countdownStartingSeconds;		

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder userId(Integer userId) {
			this.userId = userId;
			return this;
		}

		public Builder userName(String userName) {
			this.userName = userName;
			return this;
		}

		public Builder casinoName(String casinoName) {
			this.casinoName = casinoName;
			return this;
		}

		public Builder sessionId(String sessionId) {
			this.sessionId = sessionId;
			return this;
		}

		public Builder countdownStartingSeconds(Integer countdownStartingSeconds) {
			this.countdownStartingSeconds = countdownStartingSeconds;
			return this;
		}

		public Builder defaults() {
			this.method = "forcelogout";
			this.id = "1";
			this.userId = 3452895;
			this.userName = "MB13SWE";
			this.casinoName = "ptstaging2.139";
			this.sessionId = "42F762BA35594DA0A907B2CD9B05D404000004";
			this.countdownStartingSeconds = 15;
			return this;
		}

		public ForceLogoutReq build() {
			return new ForceLogoutReq(this);
		}

	}

}
