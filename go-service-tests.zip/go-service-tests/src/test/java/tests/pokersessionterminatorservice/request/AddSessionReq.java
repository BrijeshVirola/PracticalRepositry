package tests.pokersessionterminatorservice.request;

import java.util.HashMap;
import java.util.Map;

public class AddSessionReq {

	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	private Map<String, Object> Params = new HashMap<>();

	private AddSessionReq(Builder builder) {
		this.Method = builder.method;
		this.ID = builder.id;
		this.Params.put("user_id", builder.userId);
		this.Params.put("session_id", builder.sessionId);
	}

	public static class Builder {

		private String method;
		private String id;
		private Integer userId;
		private String sessionId;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder userId(Integer userId) {
			this.userId = userId;
			return this;
		}

		public Builder sessionId(String sessionId) {
			this.sessionId = sessionId;
			return this;
		}

		public Builder defaults() {
			this.method = "addsession";
			this.id = "1";
			this.userId = 3452895;
			this.sessionId = "42F762BA35594DA0A907B2CD9B05D404000004";
			return this;
		}

		public AddSessionReq build() {
			return new AddSessionReq(this);
		}

	}

}
