package tests.gtoolmanagementservice.request;

import tests.gtoolmanagementservice.requestobjects.GetPermissionsQueryReqParams;

public class GetPermissionsQueryReq {
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private GetPermissionsQueryReqParams Params;
	
	private GetPermissionsQueryReq(Builder builder) {
		this.Method = builder.method;
		this.ID = builder.id;
		this.Params = builder.params;	
	}
	
	public static class Builder {
		private String method;
		private String id;
		private GetPermissionsQueryReqParams params;
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder params(GetPermissionsQueryReqParams params) {
			this.params = params;
			return this;
		}
		
		public Builder defaults() {
			this.method = "getpermissionsquery";
			this.id = "1";
			this.params = new GetPermissionsQueryReqParams
					.Builder()
					.defaults()
					.build();
			return this;
		}
		
		public GetPermissionsQueryReq build() {
			return new GetPermissionsQueryReq(this);
		}
		
	}
}
