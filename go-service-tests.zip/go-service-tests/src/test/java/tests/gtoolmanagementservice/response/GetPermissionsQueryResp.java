package tests.gtoolmanagementservice.response;

import java.util.ArrayList;
import java.util.List;
import tests.gtoolmanagementservice.responseobjects.GetPermissionsQueryRespResultObject;

public class GetPermissionsQueryResp {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private List<GetPermissionsQueryRespResultObject> result;

	private GetPermissionsQueryResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public static class Builder {
		
		private String id;
		private List<GetPermissionsQueryRespResultObject> result;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addResult(GetPermissionsQueryRespResultObject resultObject) {
			this.result.add(resultObject);
			return this;
		}
		
		public Builder defaults() {
			id = "1";
			result = new ArrayList<>();
			return this;
		}
		
		public GetPermissionsQueryResp build() {
			return new GetPermissionsQueryResp(this);
		}
		
	}

	public List<GetPermissionsQueryRespResultObject> getResult() {
		return result;
	}
	
}