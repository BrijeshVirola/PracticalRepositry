package tests.gtoolmanagementservice;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.isA;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.List;
import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gtoolmanagementservice.enums.GToolManagementEndpoints;
import tests.gtoolmanagementservice.request.GetPermissionsQueryReq;
import tests.gtoolmanagementservice.requestobjects.GetPermissionsQueryReqParams;
import tests.gtoolmanagementservice.response.GetPermissionsQueryResp;
import tests.gtoolmanagementservice.responseobjects.GetPermissionsQueryRespResultObject;

public class GetPermissionsQueryTests extends BaseClassSetup {

	@Test(description = "Make a request to get permissions query. Positive scenario.")
	public void GetPermissionsQuery_Positive_Scenario() {

		String id = UUID.randomUUID().toString();

		GetPermissionsQueryReq requestBody = new GetPermissionsQueryReq
				.Builder()
				.defaults()
				.id(id)
				.build();

		GetPermissionsQueryResp actualResponse = BaseRequest.post(requestBody, GToolManagementEndpoints.getPermissionsQuerySuccess);

		List<GetPermissionsQueryRespResultObject> resultList = actualResponse.getResult();

		for (GetPermissionsQueryRespResultObject getPermissionsQueryRespResultObject : resultList) {
			assertThat(getPermissionsQueryRespResultObject.getRead(), isA(Boolean.class));
			assertThat(getPermissionsQueryRespResultObject.getWrite(), isA(Boolean.class));
			assertThat(getPermissionsQueryRespResultObject.getIsGroup(), isA(Boolean.class));
			assertThat(getPermissionsQueryRespResultObject.getUserAndGroupName(), notNullValue());
			assertThat(getPermissionsQueryRespResultObject.getFeatureName(), is(""));
			assertThat(getPermissionsQueryRespResultObject.getFeatureID(), is(0));
		}

	}

	@Test(description = "Make a request to get permissions query. Negative scenario.")
	public void GetPermissionsQuery_Missing_Plugin_Name_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		GetPermissionsQueryReqParams invalidPluginName = new GetPermissionsQueryReqParams
				.Builder()
				.defaults()
				.pluginName(null)
				.build();

		GetPermissionsQueryReq requestBody = new GetPermissionsQueryReq
				.Builder()
				.defaults()
				.id(id)
				.params(invalidPluginName)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, GToolManagementEndpoints.getPermissionsQueryError);

		CustomErrorResponse expectedError = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(1003)
				.message("Missing/invalid parameter: pluginname")
				.build();

		assertReflectionEquals(expectedError, actualError);

	}

	@Test(description = "Make a request to get permissions query. Negative scenario.")
	public void GetPermissionsQuery_Empty_Plugin_Name_Negative_Scenario() {

		String id = UUID.randomUUID().toString();

		GetPermissionsQueryReqParams invalidPluginName = new GetPermissionsQueryReqParams
				.Builder()
				.defaults()
				.pluginName("")
				.build();

		GetPermissionsQueryReq requestBody = new GetPermissionsQueryReq
				.Builder()
				.defaults()
				.id(id)
				.params(invalidPluginName)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, GToolManagementEndpoints.getPermissionsQueryError);

		CustomErrorResponse expectedError = new CustomErrorResponse
				.Builder()
				.defaults()
				.id(id)
				.code(1003)
				.message("Missing/invalid parameter: pluginname")
				.build();

		assertReflectionEquals(expectedError, actualError);

	}

}
