package tests.promotionsservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.promotionsservice.response.AdjustGoldenChipsResp;
import tests.promotionsservice.response.FreeSpinGameConfigResp;
import tests.promotionsservice.response.FreeSpinInfoResp;
import tests.promotionsservice.response.FreeSpinTransactionResp;
import tests.promotionsservice.response.GetCurrencyConversionMultipliersResp;
import tests.promotionsservice.response.GetFreeSpinTokenByTransactionIdResp;
import tests.promotionsservice.response.GetGoldenChipPromotionGameConfigurationsResp;
import tests.promotionsservice.response.GetGoldenChipUserPromotionDetailsResp;
import tests.promotionsservice.response.GetGoldenChipsByPromotionTokenResp;
import tests.promotionsservice.response.GetGoldenChipsByTransactionResp;
import tests.promotionsservice.response.GetTransactionIdsForFreeSpinResp;
import tests.promotionsservice.response.TryCloseUserPromotionResp;

public enum PromotionEndpoints implements ResponseEndpoints {

	getCurrencyConversionMultipliersSuccess(GetCurrencyConversionMultipliersResp.class, "GetCurrencyConversionMultipliers"),
	getCurrencyConversionMultipliersError(CustomErrorResponse.class, "GetCurrencyConversionMultipliers"),
	freeSpinGameConfigSuccess(FreeSpinGameConfigResp.class, "FreeSpinGameConfig"),
	freeSpinGameConfigError(CustomErrorResponse.class, "FreeSpinGameConfig"),
	tryCloseUserPromotionSuccess(TryCloseUserPromotionResp.class, "TryCloseUserPromotion"),
	tryCloseUserPromotionError(CustomErrorResponse.class, "TryCloseUserPromotion"),
	freeSpinTransactionSuccess(FreeSpinTransactionResp.class, "FreeSpinTransaction"),
	freeSpinTransactionError(CustomErrorResponse.class, "FreeSpinTransaction"),
	getFreeSpinTokenByTransactionIdSuccess(GetFreeSpinTokenByTransactionIdResp.class, "GetFreeSpinTokenByTransactionId"),
	getFreeSpinTokenByTransactionIdError(CustomErrorResponse.class, "GetFreeSpinTokenByTransactionId"),
	getTransactionIdsForFreeSpinSuccess(GetTransactionIdsForFreeSpinResp.class, "GetTransactionIdsForFreeSpin"),
	getTransactionIdsForFreeSpinError(CustomErrorResponse.class, "GetTransactionIdsForFreeSpin"),
	freeSpinInfoSuccess(FreeSpinInfoResp.class, "freespininfo"),
	freeSpinInfoError(CustomErrorResponse.class, "freespininfo"),
	adjustGoldenChipsSuccess(AdjustGoldenChipsResp.class, "AdjustGoldenChips"),
	adjustGoldenChipsError(CustomErrorResponse.class, "AdjustGoldenChips"),
	getGoldenChipsByTransactionSuccess(GetGoldenChipsByTransactionResp.class, "getgoldenchipsbytransaction"),
	getGoldenChipsByTransactionError(CustomErrorResponse.class, "getgoldenchipsbytransaction"),
	getGoldenChipsByPromotionTokenSuccess(GetGoldenChipsByPromotionTokenResp.class, "getgoldenchipsbypromotiontoken"),
	getGoldenChipsByPromotionTokenError(CustomErrorResponse.class, "getgoldenchipsbypromotiontoken"),
	getGoldenChipPromotionGameConfigurationsSuccess(GetGoldenChipPromotionGameConfigurationsResp.class, "getgoldenchippromotiongameconfigurations"),
	getGoldenChipPromotionGameConfigurationsError(CustomErrorResponse.class, "getgoldenchippromotiongameconfigurations"),
	getGoldenChipUserPromotionDetailsSuccess(GetGoldenChipUserPromotionDetailsResp.class, "GetGoldenChipUserPromotionDetails"),
	getGoldenChipUserPromotionDetailsError(CustomErrorResponse.class, "GetGoldenChipUserPromotionDetails");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> PromotionEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
