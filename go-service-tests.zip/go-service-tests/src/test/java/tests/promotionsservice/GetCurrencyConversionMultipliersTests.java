package tests.promotionsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.promotionsservice.enums.PromotionEndpoints;
import tests.promotionsservice.request.GetCurrencyConversionMultipliersReq;
import tests.promotionsservice.response.GetCurrencyConversionMultipliersResp;

public class GetCurrencyConversionMultipliersTests extends BaseClassSetup {

	@DataProvider(name = "getCurrencyConversionMultipliers")
	private Object[][] getCurrencyConversionMultipliers() {
		return new Object[][] {
			{new BigInteger("1"), new ArrayList<>(Arrays.asList("RUB", "AUD", "CAD", "CHF", "CZK", "DKK", "EUR", "GBP", "HKD", "HUF",
					"ISK", "JPY", "MXN", "MYR", "NOK", "NZD", "RMB", "BGN", "RON", "PLN", "ARS", "BRL", "SEK", "SGD",
					"THB", "TWD", "USD", "ZAR", "INR"))
				, new ArrayList<>(Arrays.asList("82", "2", "2", "1", "30", "10", "1", "1", "10", "300",
						"100", "150", "25", "5", "10", "2", "10", "2", "5", "5", "20", "5", "10", "2",
						"50", "40", "2", "20", "20"))},
			{new BigInteger("2"), new ArrayList<>(Arrays.asList("RUB", "AUD", "CAD", "CHF", "CZK", "DKK", "EUR", "GBP", "HKD", "HUF",
					"ISK", "JPY", "MXN", "MYR", "NOK", "NZD", "RMB", "BGN", "RON", "PLN", "ARS", "BRL", "SEK", "SGD",
					"THB", "TWD", "USD", "ZAR", "INR"))
							, new ArrayList<>(Arrays.asList("82", "2", "2", "2", "30", "10", "1", "1", "10", "300",
									"100", "200", "20", "5", "10", "2", "10", "2", "4", "5", "70", "5", "10", "2",
									"50", "50", "1", "20", "80"))},
			{new BigInteger("3"), new ArrayList<>(Arrays.asList("RUB", "AUD", "CAD", "CHF", "CZK", "DKK", "EUR", "GBP", "HKD", "HUF",
					"ISK", "JPY", "MXN", "MYR", "NOK", "NZD", "RMB", "BGN", "RON", "PLN", "ARS", "BRL", "SEK", "SGD",
					"THB", "TWD", "USD", "ZAR", "INR"))
										, new ArrayList<>(Arrays.asList("50", "1", "2", "1", "25", "10", "1", "1", "10", "200",
												"100", "100", "10", "5", "10", "2", "10", "2", "5", "5", "50", "5", "10", "1",
												"50", "25", "1", "10", "100"))},
			{new BigInteger("10"), new ArrayList<>()
													, new ArrayList<>()}
		};
	}

	@Test(description = "Make a request to getCurrencyConversionMultipliers. Positive scenario.", dataProvider = "getCurrencyConversionMultipliers")
	public void getCurrencyConversionMultipliers_Positive_Scenario(BigInteger currencyConversionMultiplierId,
			List<String> currencyCode, List<String> multiplier) {

		String id = UUID.randomUUID().toString();

		GetCurrencyConversionMultipliersReq requestBody = new GetCurrencyConversionMultipliersReq
				.Builder()
				.defaults()
				.id(id)
				.currencyConversionMultiplierId(currencyConversionMultiplierId)
				.build();

		GetCurrencyConversionMultipliersResp actualResponse =  BaseRequest.post(requestBody, PromotionEndpoints.getCurrencyConversionMultipliersSuccess);
		actualResponse.sortCurrencyConversionMultipliersByCurrencyCode();

		GetCurrencyConversionMultipliersResp expectedResponse =  new GetCurrencyConversionMultipliersResp
				.Builder()
				.defaults()
				.id(id)
				.currencyConversionMultipliers(currencyCode, multiplier)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getCurrencyConversionMultipliers with invalid method.")
	public void getCurrencyConversionMultipliers_Invalid_Method() {
		String id = UUID.randomUUID().toString();

		GetCurrencyConversionMultipliersReq requestBody = new GetCurrencyConversionMultipliersReq
				.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, PromotionEndpoints.getCurrencyConversionMultipliersError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getCurrencyConversionMultipliers with missing parameter currency_conversion_multiplier_id.")
	public void getCurrencyConversionMultipliers_Missing_Currency_Conversion_Multiplier_Id() {
		String id = UUID.randomUUID().toString();

		GetCurrencyConversionMultipliersReq requestBody = new GetCurrencyConversionMultipliersReq.Builder()
				.defaults()
				.currencyConversionMultiplierId(null)
				.id(id)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, PromotionEndpoints.getCurrencyConversionMultipliersError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: currency_conversion_multiplier_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getCurrencyConversionMultipliers - Out of Range - currency_conversion_multiplier_id.")
	public void getCurrencyConversionMultipliers_Out_Of_Range_Currency_Conversion_Multiplier_Id() {
		String id = UUID.randomUUID().toString();

		GetCurrencyConversionMultipliersReq requestBody = new GetCurrencyConversionMultipliersReq.Builder()
				.defaults()
				.currencyConversionMultiplierId(new BigInteger("2147483648"))
				.id(id)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, PromotionEndpoints.getCurrencyConversionMultipliersError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(4)
				.message("Couldn't unmarshal params into target type : json: cannot unmarshal number 2147483648 into Go struct field getCurrencyConversionMultipliersRequest.currency_conversion_multiplier_id of type int32")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}