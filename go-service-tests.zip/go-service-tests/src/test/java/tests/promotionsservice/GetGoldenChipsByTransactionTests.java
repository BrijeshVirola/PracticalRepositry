package tests.promotionsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.promotionsservice.enums.PromotionEndpoints;
import tests.promotionsservice.request.GetGoldenChipsByTransactionReq;
import tests.promotionsservice.response.GetGoldenChipsByTransactionResp;
import tests.promotionsservice.responseobjects.GoldenChip;

public class GetGoldenChipsByTransactionTests extends BaseClassSetup {

	@Test(description = "Make a request to getGoldenChipsByTransaction. One golden chip.")
	public void getGoldenChipsByTransaction_One_Golden_Chip() {

		String id = UUID.randomUUID().toString();

		GetGoldenChipsByTransactionReq requestBody = new GetGoldenChipsByTransactionReq
				.Builder()
				.defaults()
				.id(id)
				.bet365GamesTransactionId(new BigInteger("1"))
				.build();

		GetGoldenChipsByTransactionResp actualResponse =  BaseRequest.post(requestBody, PromotionEndpoints.getGoldenChipsByTransactionSuccess);

		GetGoldenChipsByTransactionResp expectedResponse =  new GetGoldenChipsByTransactionResp
				.Builder()
				.defaults()
				.id(id)
				.addGoldenChip(new GoldenChip(1, new BigDecimal("0.5")))
				.promotionToken("c4ce08f2-3b1b-11ec-8d3d-0242ac130003")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getGoldenChipsByTransaction. Two golden chips.")
	public void getGoldenChipsByTransaction_Two_Golden_Chips() {

		String id = UUID.randomUUID().toString();

		GetGoldenChipsByTransactionReq requestBody = new GetGoldenChipsByTransactionReq
				.Builder()
				.defaults()
				.id(id)
				.bet365GamesTransactionId(new BigInteger("3"))
				.build();

		GetGoldenChipsByTransactionResp actualResponse =  BaseRequest.post(requestBody, PromotionEndpoints.getGoldenChipsByTransactionSuccess);

		GetGoldenChipsByTransactionResp expectedResponse =  new GetGoldenChipsByTransactionResp
				.Builder()
				.defaults()
				.id(id)
				.addGoldenChip(new GoldenChip(1, new BigDecimal("0.5")))
				.addGoldenChip(new GoldenChip(1, new BigDecimal("1")))
				.promotionToken("c4ce08f2-3b1b-11ec-8d3d-0242ac130003")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getGoldenChipsByTransaction. Not existing transaction.")
	public void getGoldenChipsByTransaction_Not_Existing_Transaction() {

		String id = UUID.randomUUID().toString();

		GetGoldenChipsByTransactionReq requestBody = new GetGoldenChipsByTransactionReq
				.Builder()
				.defaults()
				.id(id)
				.bet365GamesTransactionId(new BigInteger("5"))
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, PromotionEndpoints.getGoldenChipsByTransactionError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1008)
				.message("GoldenChip transaction not found")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getGoldenChipsByTransaction with invalid method.")
	public void getGoldenChipsByTransaction_Invalid_Method() {

		String id = UUID.randomUUID().toString();

		GetGoldenChipsByTransactionReq requestBody = new GetGoldenChipsByTransactionReq
				.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, PromotionEndpoints.getGoldenChipsByTransactionError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getGoldenChipsByTransaction with missing parameter bet365_games_transaction_id.")
	public void getGoldenChipsByTransaction_Missing_Bet365_Games_Transaction_Id() {

		String id = UUID.randomUUID().toString();

		GetGoldenChipsByTransactionReq requestBody = new GetGoldenChipsByTransactionReq.Builder()
				.defaults()
				.bet365GamesTransactionId(null)
				.id(id)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, PromotionEndpoints.getGoldenChipsByTransactionError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing required parameter: bet365_games_transaction_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}