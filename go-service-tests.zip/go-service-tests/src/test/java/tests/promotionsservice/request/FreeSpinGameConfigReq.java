package tests.promotionsservice.request;

public class FreeSpinGameConfigReq {
	
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private Params Params;
	
	private FreeSpinGameConfigReq(Builder builder) {
		this.Method = builder.Method;
		this.ID = builder.ID;
		this.Params = new Params(builder);
	}
	
	public static class Builder {
		private String Method;
		private String ID;
		private Integer promotion_id;

		public Builder id(String id) {
			this.ID = id;
			return this;
		}
		
		public Builder promotionId(Integer promotionId) {
			this.promotion_id = promotionId;
			return this;
		}
		
		public Builder method(String method) {
			this.Method = method;
			return this;
		}
		
		public Builder defaults() {
			this.Method = "freespingameconfig";
			this.ID = "defaultTestId";
			this.promotion_id = 28618;
			return this;
		}
		
		public FreeSpinGameConfigReq build() {
			return new FreeSpinGameConfigReq(this);
		}
	}
	
	private class Params {
		@SuppressWarnings("unused")
		Integer promotion_id;
		
		public Params(Builder builder) {
			this.promotion_id = builder.promotion_id;
		}
	}
}