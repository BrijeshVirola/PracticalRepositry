package tests.promotionsservice.request;

public class FreeSpinInfoReq {
	
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private Params Params;
	
	private FreeSpinInfoReq(Builder builder) {
		this.Method = builder.Method;
		this.ID = builder.ID;
		this.Params = new Params(builder);
	}
	
	public static class Builder {
		private String Method;
		private String ID;
		private String promotion_token;

		public Builder id(String id) {
			this.ID = id;
			return this;
		}
		
		public Builder promotionToken(String promotionToken) {
			this.promotion_token = promotionToken;
			return this;
		}
		
		public Builder method(String method) {
			this.Method = method;
			return this;
		}
		
		public Builder defaults() {
			this.Method = "freespininfo";
			this.ID = "defaultTestId";
			this.promotion_token = "331E52D1-0E44-4CA8-A165-32F67568C560";
			return this;
		}
		
		public FreeSpinInfoReq build() {
			return new FreeSpinInfoReq(this);
		}
	}
	
	private class Params {
		@SuppressWarnings("unused")
		String promotion_token;
		
		public Params(Builder builder) {
			this.promotion_token = builder.promotion_token;
		}
	}
}