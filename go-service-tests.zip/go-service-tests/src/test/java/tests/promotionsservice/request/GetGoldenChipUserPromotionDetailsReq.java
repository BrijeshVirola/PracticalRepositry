package tests.promotionsservice.request;

public class GetGoldenChipUserPromotionDetailsReq {
	
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private Params Params;
	
	private GetGoldenChipUserPromotionDetailsReq(Builder builder) {
		this.Method = builder.Method;
		this.ID = builder.ID;
		this.Params = new Params(builder);
	}
	
	public static class Builder {
		private String Method;
		private String ID;
		private String promotion_token;
		private Integer user_id;

		public Builder id(String id) {
			this.ID = id;
			return this;
		}
		
		public Builder promotionToken(String promotionToken) {
			this.promotion_token = promotionToken;
			return this;
		}
		
		public Builder userId(Integer userId) {
			this.user_id = userId;
			return this;
		}
		
		public Builder method(String method) {
			this.Method = method;
			return this;
		}
		
		public Builder defaults() {
			this.Method = "getgoldenchipuserpromotiondetails";
			this.ID = "defaultTestId";
			this.promotion_token = "4bef7fec-2815-11ec-9621-0242ac130002";
			this.user_id = 234524;
			return this;
		}
		
		public GetGoldenChipUserPromotionDetailsReq build() {
			return new GetGoldenChipUserPromotionDetailsReq(this);
		}
	}
	
	private class Params {
		@SuppressWarnings("unused")
		private String promotion_token;
		@SuppressWarnings("unused")
		private Integer user_id;
		
		public Params(Builder builder) {
			this.promotion_token = builder.promotion_token;
			this.user_id = builder.user_id;
		}
	}
}