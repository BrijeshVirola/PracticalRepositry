package tests.promotionsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.util.UUID;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import tests.promotionsservice.enums.PromotionEndpoints;
import tests.promotionsservice.request.GetGoldenChipUserPromotionDetailsReq;
import tests.promotionsservice.response.GetGoldenChipUserPromotionDetailsResp;

public class GetGoldenChipUserPromotionDetailsTests extends BaseClassSetup {

	@Test(description = "Make a request to getGoldenChipUserPromotionDetail. Claimed and open promotion.")
	public void getGoldenChipUserPromotionDetails_Claimed_And_Open() {
		String id = UUID.randomUUID().toString();

		GetGoldenChipUserPromotionDetailsReq requestBody = new GetGoldenChipUserPromotionDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.promotionToken("e8850406-3802-11ec-8d3d-0242ac130003")
				.userId(4634818)
				.build();

		GetGoldenChipUserPromotionDetailsResp actualResponse =  BaseRequest.post(requestBody,
				PromotionEndpoints.getGoldenChipUserPromotionDetailsSuccess);

		GetGoldenChipUserPromotionDetailsResp expectedResponse =  new GetGoldenChipUserPromotionDetailsResp
				.Builder()
				.defaults()
				.id(id)
				.promotionId(28802)
				.expiryDateUtc("2023-03-12T15:28:31.833Z")
				.promotionCloseReasonId(0)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getGoldenChipUserPromotionDetail. Claimed and closed promotion.")
	public void getGoldenChipUserPromotionDetails_Claimed_And_Closed() {
		String id = UUID.randomUUID().toString();

		GetGoldenChipUserPromotionDetailsReq requestBody = new GetGoldenChipUserPromotionDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.promotionToken("f5403f6c-389d-11ec-8d3d-0242ac130003")
				.userId(4635144)
				.build();

		GetGoldenChipUserPromotionDetailsResp actualResponse =  BaseRequest.post(requestBody,
				PromotionEndpoints.getGoldenChipUserPromotionDetailsSuccess);

		GetGoldenChipUserPromotionDetailsResp expectedResponse =  new GetGoldenChipUserPromotionDetailsResp
				.Builder()
				.defaults()
				.id(id)
				.promotionId(28802)
				.expiryDateUtc("2023-03-13T09:52:55.44Z")
				.promotionCloseReasonId(2)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getGoldenChipUserPromotionDetails with invalid method.")
	public void getGoldenChipUserPromotionDetails_Invalid_Method() {
		String id = UUID.randomUUID().toString();

		GetGoldenChipUserPromotionDetailsReq requestBody = new GetGoldenChipUserPromotionDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, PromotionEndpoints.getGoldenChipUserPromotionDetailsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getGoldenChipUserPromotionDetails with missing parameter user_id.")
	public void getGoldenChipUserPromotionDetails_Missing_Promotion_Token() {
		String id = UUID.randomUUID().toString();

		GetGoldenChipUserPromotionDetailsReq requestBody = new GetGoldenChipUserPromotionDetailsReq.Builder()
				.defaults()
				.userId(null)
				.id(id)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, PromotionEndpoints.getGoldenChipUserPromotionDetailsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing required parameter: user_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getGoldenChipUserPromotionDetails invalid promotion token.")
	public void getGoldenChipUserPromotionDetails_Unknown_PromotionToken() {
		String id = UUID.randomUUID().toString();

		GetGoldenChipUserPromotionDetailsReq requestBody = new GetGoldenChipUserPromotionDetailsReq.Builder()
				.defaults()
				.id(id)
				.promotionToken("331E52D1-0E44-4CA8-A165-32F67568C561")
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, PromotionEndpoints.getGoldenChipUserPromotionDetailsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1005)
				.message("User promotion details not found")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getGoldenChipUserPromotionDetails invalid format range - promotion token.", dataProvider = "invalidFormatRangePromotionToken", dataProviderClass = DataProviders.class)
	public void getGoldenChipUserPromotionDetails_Invalid_Format_Range_PromotionToken(String promotion_token) {
		String id = UUID.randomUUID().toString();

		GetGoldenChipUserPromotionDetailsReq requestBody = new GetGoldenChipUserPromotionDetailsReq.Builder()
				.defaults()
				.id(id)
				.promotionToken(promotion_token)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, PromotionEndpoints.getGoldenChipUserPromotionDetailsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(4)
				.message("Couldn't unmarshal params into target type : json: cannot unmarshal guid into Go struct field getGoldenChipUserPromotionDetailsRequest.promotion_token of type *guuid.UUID")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}