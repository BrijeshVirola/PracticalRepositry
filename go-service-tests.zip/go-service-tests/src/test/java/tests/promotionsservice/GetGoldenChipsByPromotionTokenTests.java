package tests.promotionsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import tests.promotionsservice.enums.PromotionEndpoints;
import tests.promotionsservice.request.GetGoldenChipsByPromotionTokenReq;
import tests.promotionsservice.response.GetGoldenChipsByPromotionTokenResp;
import tests.promotionsservice.responseobjects.GoldenChip;

public class GetGoldenChipsByPromotionTokenTests extends BaseClassSetup {

	@Test(description = "Make a request to getGoldenChipsByPromotionToken. One Golden Chip.")
	public void getGoldenChipsByPromotionToken_One_Golden_Chip() {
		String id = UUID.randomUUID().toString();

		GetGoldenChipsByPromotionTokenReq requestBody = new GetGoldenChipsByPromotionTokenReq
				.Builder()
				.defaults()
				.id(id)
				.promotionToken("4a01df98-3bc2-11ec-8d3d-0242ac130003").build();

		GetGoldenChipsByPromotionTokenResp actualResponse =  BaseRequest.post(requestBody, PromotionEndpoints.getGoldenChipsByPromotionTokenSuccess);

		GoldenChip expGoldenChip = new GoldenChip(1, new BigDecimal("0.5"));

		GetGoldenChipsByPromotionTokenResp expectedResponse =  new GetGoldenChipsByPromotionTokenResp
				.Builder()
				.defaults()
				.id(id)
				.addGoldenChip(expGoldenChip)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getGoldenChipsByPromotionToken. Two Golden Chips.")
	public void getGoldenChipsByPromotionToken_Two_Golden_Chips() {
		String id = UUID.randomUUID().toString();

		GetGoldenChipsByPromotionTokenReq requestBody = new GetGoldenChipsByPromotionTokenReq
				.Builder()
				.defaults()
				.id(id)
				.promotionToken("ffeb7424-3bd4-11ec-8d3d-0242ac130003").build();

		GetGoldenChipsByPromotionTokenResp actualResponse =  BaseRequest.post(requestBody, PromotionEndpoints.getGoldenChipsByPromotionTokenSuccess);

		GoldenChip expGoldenChip1 = new GoldenChip(1, new BigDecimal("0.5"));
		GoldenChip expGoldenChip2 = new GoldenChip(1, new BigDecimal("1"));

		GetGoldenChipsByPromotionTokenResp expectedResponse =  new GetGoldenChipsByPromotionTokenResp
				.Builder()
				.defaults()
				.id(id)
				.addGoldenChip(expGoldenChip1)
				.addGoldenChip(expGoldenChip2)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getGoldenChipsByPromotionToken with invalid method.")
	public void getGoldenChipsByPromotionToken_Invalid_Method() {
		String id = UUID.randomUUID().toString();

		GetGoldenChipsByPromotionTokenReq requestBody = new GetGoldenChipsByPromotionTokenReq
				.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, PromotionEndpoints.getGoldenChipsByPromotionTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getGoldenChipsByPromotionToken with missing parameter promotion token.")
	public void getGoldenChipsByPromotionToken_Missing_Promotion_Token() {
		String id = UUID.randomUUID().toString();

		GetGoldenChipsByPromotionTokenReq requestBody = new GetGoldenChipsByPromotionTokenReq.Builder()
				.defaults()
				.promotionToken(null)
				.id(id)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, PromotionEndpoints.getGoldenChipsByPromotionTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing required parameter: promotion_token")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getGoldenChipUserPromotionDetails invalid promotion token.")
	public void getGoldenChipUserPromotionDetails_Unknown_PromotionToken() {
		String id = UUID.randomUUID().toString();

		GetGoldenChipsByPromotionTokenReq requestBody = new GetGoldenChipsByPromotionTokenReq.Builder()
				.defaults()
				.id(id)
				.promotionToken("331E52D1-0E44-4CA8-A165-32F67568C561")
				.build();

		GetGoldenChipsByPromotionTokenResp actualResp = BaseRequest.post(requestBody, PromotionEndpoints.getGoldenChipsByPromotionTokenSuccess);
		GetGoldenChipsByPromotionTokenResp expectedResp = new GetGoldenChipsByPromotionTokenResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResp, actualResp);
	}
	
	@Test(description = "Make a request to getGoldenChipUserPromotionDetails invalid format range promotion token.", dataProvider = "invalidFormatRangePromotionToken", dataProviderClass = DataProviders.class)
	public void getGoldenChipUserPromotionDetails_Invalid_Format_Range_PromotionToken(String promotion_token) {
		String id = UUID.randomUUID().toString();

		GetGoldenChipsByPromotionTokenReq requestBody = new GetGoldenChipsByPromotionTokenReq.Builder()
				.defaults()
				.id(id)
				.promotionToken(promotion_token)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, PromotionEndpoints.getGoldenChipsByPromotionTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(4)
				.message("Couldn't unmarshal params into target type : json: cannot unmarshal guid into Go struct field getGoldenChipsByPromotionTokenRequest.promotion_token of type *guuid.UUID")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}