package tests.promotionsservice.response;

import java.util.ArrayList;
import java.util.List;

import tests.promotionsservice.responseobjects.GoldenChipGameConfiguration;

public class GetGoldenChipPromotionGameConfigurationsResp {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Result result;

	private GetGoldenChipPromotionGameConfigurationsResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public static class Builder {
		
		private String id;
		List<GoldenChipGameConfiguration> game_configurations;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addGameConfiguration(GoldenChipGameConfiguration gameConfiguration) {
			game_configurations.add(gameConfiguration);
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultTestId";
			this.game_configurations = new ArrayList<GoldenChipGameConfiguration>();
			
			return this;
		}
		
		public GetGoldenChipPromotionGameConfigurationsResp build() {
			return new GetGoldenChipPromotionGameConfigurationsResp(this);
		}
	}
	
	private class Result {
		
		@SuppressWarnings("unused")
		List<GoldenChipGameConfiguration> game_configurations;

		public Result(Builder builder) {
			this.game_configurations = builder.game_configurations;
		}

	}
}