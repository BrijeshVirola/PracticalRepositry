package tests.promotionsservice.response;

public class FreeSpinTransactionResp {
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String result;
	
	private FreeSpinTransactionResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}

	public static class Builder {
		private String id;
		private String result;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder result(String result) {
			this.result = result;
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultId";
			this.result = "OK";
			return this;
		}
		
		public FreeSpinTransactionResp build() {
			return new FreeSpinTransactionResp(this);
		}
	}
}
