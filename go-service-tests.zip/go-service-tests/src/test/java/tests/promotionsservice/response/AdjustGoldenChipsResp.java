package tests.promotionsservice.response;

public class AdjustGoldenChipsResp {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Result result;

	private AdjustGoldenChipsResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public static class Builder {
		
		private String id;
		private Boolean ok;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder ok(Boolean ok) {
			this.ok = ok;
			return this;
		}
		
		public Builder defaults() {
			id = "defaultTestId";
			ok = true;
			return this;
		}
		
		public AdjustGoldenChipsResp build() {
			return new AdjustGoldenChipsResp(this);
		}
	}
	
	private class Result {
		
		@SuppressWarnings("unused")
		Boolean ok;

		public Result(Builder builder) {
			ok = builder.ok;
		}
	}
}