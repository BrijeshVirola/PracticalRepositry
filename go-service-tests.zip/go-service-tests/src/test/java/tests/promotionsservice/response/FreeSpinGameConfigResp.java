package tests.promotionsservice.response;

import java.util.ArrayList;
import java.util.List;

import tests.promotionsservice.responseobjects.FreeSpinGameConfiguration;

public class FreeSpinGameConfigResp {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Result result;

	private FreeSpinGameConfigResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public static class Builder {
		
		private String id;
		List<FreeSpinGameConfiguration> game_configurations;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addGameConfiguration(FreeSpinGameConfiguration gameConfiguration) {
			game_configurations.add(gameConfiguration);
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultTestId";
			this.game_configurations = new ArrayList<FreeSpinGameConfiguration>();
			
			return this;
		}
		
		public FreeSpinGameConfigResp build() {
			return new FreeSpinGameConfigResp(this);
		}
	}
	
	private class Result {
		
		@SuppressWarnings("unused")
		List<FreeSpinGameConfiguration> game_configurations;

		public Result(Builder builder) {
			this.game_configurations = builder.game_configurations;
		}

	}
}