package tests.promotionsservice.response;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import tests.promotionsservice.responseobjects.CurrencyConversionMultiplier;

public class GetCurrencyConversionMultipliersResp {
	
	@SuppressWarnings("unused")
	private String id;
	private Result result;

	private GetCurrencyConversionMultipliersResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public void sortCurrencyConversionMultipliersByCurrencyCode() {
		Collections.sort(result.getCurrencyConversionMultipliers());
	}
	
	public static class Builder {
		
		private String id;
		List<CurrencyConversionMultiplier> currency_conversion_multipliers;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder currencyConversionMultipliers(List<String> currencyCodes, List<String> multipliers) {
			
			int size = currencyCodes.size();
			
			for (int number = 0; number < size; number++) {
				
				CurrencyConversionMultiplier currencyConversionMultiplier = 
						new CurrencyConversionMultiplier(currencyCodes.get(number), multipliers.get(number));
				
				currency_conversion_multipliers.add(currencyConversionMultiplier);
			}
			
			Collections.sort(currency_conversion_multipliers);

			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultTestId";
			this.currency_conversion_multipliers = new ArrayList<CurrencyConversionMultiplier>();
			
			return this;
		}
		
		public GetCurrencyConversionMultipliersResp build() {
			return new GetCurrencyConversionMultipliersResp(this);
		}
	}
	
	private class Result {
		
		List<CurrencyConversionMultiplier> currency_conversion_multipliers;

		public List<CurrencyConversionMultiplier> getCurrencyConversionMultipliers() {
			return currency_conversion_multipliers;
		}

		public Result(Builder builder) {
			this.currency_conversion_multipliers = builder.currency_conversion_multipliers;
		}

	}
}