package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.request.UserBonusListQueryReq;
import tests.gamingbonusservice.response.BonusResult;

public class UserBonusListQueryTests extends BaseClassSetup {

	@Test(description = "Make a request to UserBonusListQuery. Positive scenario.")
	public void userBonusListQuery_Positive_Scenario() throws InterruptedException {

		Integer productId = 4;
		Double amount = 0.01;

		BonusResult expectedBonusResult = new BonusResult.Builder()
				.defaults()
				.build();

		Utils.createBonusAndVerifyThenReturnBonusDetails(4641188,  expectedBonusResult.bonustemplate_id, productId, expectedBonusResult, amount);
	}

	@Test(description = "Make a request to userBonusListQuery. Unknown user_id parameter.")
	public void userBonusListQuery_UnknownUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		UserBonusListQueryReq request = new UserBonusListQueryReq.Builder()
				.defaults()
				.userId(UsersId.NOT_EXISTING)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.userBonusListQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Error received while fetching active bonus. Could not retrieve UserData")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to userBonusListQuery. Missing user_id parameter.")
	public void userBonusListQuery_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		UserBonusListQueryReq request = new UserBonusListQueryReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.userBonusListQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to userBonusListQuery. Wrong method.")
	public void userBonusListQuery_Wrong_Method() {

		UserBonusListQueryReq request = new UserBonusListQueryReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.userBonusListQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}