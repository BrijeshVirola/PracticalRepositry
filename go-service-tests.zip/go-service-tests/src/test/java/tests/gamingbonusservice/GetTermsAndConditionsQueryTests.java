package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.request.GetTermsAndConditionsQueryReq;

public class GetTermsAndConditionsQueryTests extends BaseClassSetup {

	@Test(description = "Make a request to GetTermsAndConditionsQuery. Positive scenario.")
	public void getTermsAndConditionsQuery_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetTermsAndConditionsQueryReq request = new GetTermsAndConditionsQueryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.getTermsAndConditionsQuerySuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.result("https://games011.b365uat.com/promotions/en/anothertest")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to getTermsAndConditionsQuery. Unknown user_id parameter.")
	public void getTermsAndConditionsQuery_UnknownUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetTermsAndConditionsQueryReq request = new GetTermsAndConditionsQueryReq.Builder()
				.defaults()
				.userId(UsersId.NOT_EXISTING)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.getTermsAndConditionsQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Error in fetching UserData")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getTermsAndConditionsQuery. Missing user_id parameter.")
	public void getTermsAndConditionsQuery_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetTermsAndConditionsQueryReq request = new GetTermsAndConditionsQueryReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.getTermsAndConditionsQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getTermsAndConditionsQuery. Missing bonustemplate_id parameter.")
	public void getTermsAndConditionsQuery_MissingBonusTemplateId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetTermsAndConditionsQueryReq request = new GetTermsAndConditionsQueryReq.Builder()
				.defaults()
				.bonusTemplateId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.getTermsAndConditionsQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: bonustemplate_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getTermsAndConditionsQuery. Wrong method.")
	public void getTermsAndConditionsQuery_Wrong_Method() {

		GetTermsAndConditionsQueryReq request = new GetTermsAndConditionsQueryReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.getTermsAndConditionsQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}