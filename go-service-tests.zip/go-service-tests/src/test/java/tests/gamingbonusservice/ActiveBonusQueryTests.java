package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.request.ActiveBonusQueryReq;
import tests.gamingbonusservice.response.ActiveBonusResult;

public class ActiveBonusQueryTests extends BaseClassSetup {

	@Test(description = "Make a request to ActiveBonusQuery. Positive scenario.")
	public void activeBonusQuery_Positive_Scenario() throws InterruptedException {

		Integer userId =  4447826;
		Integer bonusTemplateId = 528;
		Integer productId = 2;
		Double amount = 0.01;

		ActiveBonusResult expectedActiveBonusResult = new ActiveBonusResult.Builder()
				.defaults()
				.bonusTemplateId(bonusTemplateId)
				.userBonusStatusId(1)
				.maximumBonus(0)
				.templateName("TestAutomationCredit")
				.isClaimed(false)
				.isRedeemed(false)
				.gameInPromotion(true)
				.acknowledged(true)
				.build();

		Utils.createActiveBonusAndVerifyThenReturnBonusDetails(userId, bonusTemplateId, productId, expectedActiveBonusResult, amount);

	}

	@Test(description = "Make a request to activeBonusQuery. Missing user_id parameter.")
	public void activeBonusQuery_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ActiveBonusQueryReq request = new ActiveBonusQueryReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.activeBonusQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to activeBonusQuery. Missing product_id parameter.")
	public void activeBonusQuery_MissingProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ActiveBonusQueryReq request = new ActiveBonusQueryReq.Builder()
				.defaults()
				.productId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.activeBonusQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to activeBonusQuery. Wrong method.")
	public void activeBonusQuery_Wrong_Method() {

		ActiveBonusQueryReq request = new ActiveBonusQueryReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.activeBonusQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}

