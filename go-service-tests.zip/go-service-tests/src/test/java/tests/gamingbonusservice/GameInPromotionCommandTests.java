package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.request.GameInPromotionCommandReq;
import tests.gamingbonusservice.response.GameInPromotionCommandResp;

public class GameInPromotionCommandTests extends BaseClassSetup {

	@Test(description = "Make a request to GameInPromotionCommand, eligible game. Positive scenario.")
	public void gameInPromotionCommand_EligibleGamePositive_Scenario() throws InterruptedException {

		String idForGameInPromotionCommand = UUID.randomUUID().toString();

		GameInPromotionCommandReq requestGameInPromotionCommand = new GameInPromotionCommandReq.Builder()
				.defaults()
				.id(idForGameInPromotionCommand)
				.build();

		GameInPromotionCommandResp actualResponse =  BaseRequest.post(requestGameInPromotionCommand, GamingBonusEndpoints.gameInPromotionCommandSuccess);

		GameInPromotionCommandResp expectedResponse = new GameInPromotionCommandResp.Builder()
				.defaults()
				.id(idForGameInPromotionCommand)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to GameInPromotionCommand, excluded game. Positive scenario.")
	public void gameInPromotionCommand_ExcludedGamePositive_Scenario() throws InterruptedException {

		Integer exludedGame = 10351;
		String idForGameInPromotionCommand = UUID.randomUUID().toString();

		GameInPromotionCommandReq requestGameInPromotionCommand = new GameInPromotionCommandReq.Builder()
				.defaults()
				.regulatedGameId(exludedGame)
				.id(idForGameInPromotionCommand)
				.build();

		GameInPromotionCommandResp actualResponse =  BaseRequest.post(requestGameInPromotionCommand, GamingBonusEndpoints.gameInPromotionCommandSuccess);

		GameInPromotionCommandResp expectedResponse = new GameInPromotionCommandResp.Builder()
				.defaults()
				.result(false)
				.id(idForGameInPromotionCommand)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to gameInPromotionCommand. Missing user_id parameter.")
	public void gameInPromotionCommand_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GameInPromotionCommandReq request = new GameInPromotionCommandReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.gameInPromotionCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to gameInPromotionCommand. Missing regulatedgame_id parameter.")
	public void gameInPromotionCommand_MissingUserBonusId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GameInPromotionCommandReq request = new GameInPromotionCommandReq.Builder()
				.defaults()
				.regulatedGameId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.gameInPromotionCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: regulatedgame_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to gameInPromotionCommand. Wrong method.")
	public void gameInPromotionCommand_Wrong_Method() {

		GameInPromotionCommandReq request = new GameInPromotionCommandReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.gameInPromotionCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}

