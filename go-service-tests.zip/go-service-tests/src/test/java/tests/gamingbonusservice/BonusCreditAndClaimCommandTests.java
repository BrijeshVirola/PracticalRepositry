package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.request.BonusCancelByUserCommandReq;
import tests.gamingbonusservice.request.BonusCreditAndClaimCommandReq;
import tests.gamingbonusservice.response.ActiveBonusResult;
import tests.gamingbonusservice.response.EligibleGame;

public class BonusCreditAndClaimCommandTests extends BaseClassSetup {

	@Test(description = "Make a request to BonusCreditAndClaimCommand. Positive scenario.")
	public void BonusCreditAndClaimCommand_Positive_Scenario() throws InterruptedException {

		Integer testUserId = 4408830;
		Integer productId = 4;
		Integer bonusTemplateId = 1575;
		Double amount = 0.0;

		ActiveBonusResult expectedBonusResult = new ActiveBonusResult.Builder()
				.defaults()
				.bonusTemplateId(bonusTemplateId)
				.templateName("UkComDepositPreWager01_automation")
				.bonusTypeId(5)
				.amountPence(0)
				.userBonusStatusId(15)
				.maximumBonus(0)
				.currency("GBP")
				.isClaimed(false)
				.addEligibleGame(new EligibleGame.Builder().gametokenId(11813).build())
				.addEligibleGame(new EligibleGame.Builder().gametokenId(15826).build())
				.addEligibleGame(new EligibleGame.Builder().gametokenId(10601).build())
				.addEligibleGame(new EligibleGame.Builder().gametokenId(10892).build())
				.isRedeemed(false)
				.depositMatched(true)
				.moreGamesAvailable(true)
				.acknowledged(true)
				.build();

		ActiveBonusResult actualNewlyCreatedUserBonus = Utils.createActiveBonusAndVerifyThenReturnBonusDetails(testUserId, expectedBonusResult.bonustemplate_id, productId, expectedBonusResult, amount);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusCreditAndClaimCommandReq request = new BonusCreditAndClaimCommandReq.Builder()
				.defaults()
				.bonusId(actualNewlyCreatedUserBonus.userbonus_id)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusCreditAndClaimCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	

		String idForBonusCancelByUserCommand = UUID.randomUUID().toString();

		BonusCancelByUserCommandReq requestBonusCancelByUserCommand = new BonusCancelByUserCommandReq.Builder()
				.defaults()
				.userId(testUserId)
				.sportsProductId(null)
				.userBonusId(actualNewlyCreatedUserBonus.userbonus_id)
				.id(idForBonusCancelByUserCommand)
				.build();

		ResultOKResp actualBonusCancelByUserCommandResponse =  BaseRequest.post(requestBonusCancelByUserCommand, GamingBonusEndpoints.bonusCancelByUserCommandSuccess);

		ResultOKResp expectedBonusCancelByUserCommandResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForBonusCancelByUserCommand)
				.build();

		assertReflectionEquals(expectedBonusCancelByUserCommandResponse, actualBonusCancelByUserCommandResponse);	
	}

	@Test(description = "Make a request to BonusCreditAndClaimCommand. Unknown user_id parameter.")
	public void BonusCreditAndClaimCommand_UnknownUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusCreditAndClaimCommandReq request = new BonusCreditAndClaimCommandReq.Builder()
				.defaults()
				.userId(UsersId.NOT_EXISTING)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusCreditAndClaimCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Error received while fetching deposit bonus. Could not retrieve UserData")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to BonusCreditAndClaimCommand. Missing user_id parameter.")
	public void BonusCreditAndClaimCommand_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusCreditAndClaimCommandReq request = new BonusCreditAndClaimCommandReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusCreditAndClaimCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to BonusCreditAndClaimCommand. Missing sports_product_id parameter.")
	public void BonusCreditAndClaimCommand_MissingSportsProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusCreditAndClaimCommandReq request = new BonusCreditAndClaimCommandReq.Builder()
				.defaults()
				.sportsProductId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusCreditAndClaimCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: sports_product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to BonusCreditAndClaimCommand. Wrong method.")
	public void BonusCreditAndClaimCommand_Wrong_Method() {

		BonusCreditAndClaimCommandReq request = new BonusCreditAndClaimCommandReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusCreditAndClaimCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}