package tests.gamingbonusservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.common.response.ResultOKResp;
import tests.gamingbonusservice.response.ActiveBonusQueryResp;
import tests.gamingbonusservice.response.ActiveRingFencedBonusesQueryResp;
import tests.gamingbonusservice.response.BonusProgressAmountQueryResp;
import tests.gamingbonusservice.response.BonusTypeQueryResp;
import tests.gamingbonusservice.response.CheckBonusEligibilityCommandResp;
import tests.gamingbonusservice.response.DepositBonusQueryResp;
import tests.gamingbonusservice.response.GameInPromotionCommandResp;
import tests.gamingbonusservice.response.GetBonusTemplatesForAccountManagerQueryResp;
import tests.gamingbonusservice.response.GetClosedBonusesQueryResp;
import tests.gamingbonusservice.response.UserBonusListQueryResp;

public enum GamingBonusEndpoints implements ResponseEndpoints {

	acknowledgeCashBonusCommandSuccess(ResultOKResp.class, "AcknowledgeCashBonusCommand"),
	acknowledgeCashBonusCommandError(CustomErrorResponse.class, "AcknowledgeCashBonusCommand"),
	activeBonusQuerySuccess(ActiveBonusQueryResp.class, "ActiveBonusQuery"),
	activeBonusQueryError(CustomErrorResponse.class, "ActiveBonusQuery"),
	getClosedBonusesQuerySuccess(GetClosedBonusesQueryResp.class, "GetClosedBonusesQuery"),
	getClosedBonusesQueryError(CustomErrorResponse.class, "GetClosedBonusesQuery"),
	activeRingFencedBonusesQuerySuccess(ActiveRingFencedBonusesQueryResp.class, "ActiveRingFencedBonusesQuery"),
	activeRingFencedBonusesQueryError(CustomErrorResponse.class, "ActiveRingFencedBonusesQuery"),
	checkBonusEligibilityCommandSuccess(CheckBonusEligibilityCommandResp.class, "CheckBonusEligibilityCommand"),
	checkBonusEligibilityCommandError(CustomErrorResponse.class, "CheckBonusEligibilityCommand"),
	depositBonusQuerySuccess(DepositBonusQueryResp.class, "DepositBonusQuery"),
	depositBonusQueryError(CustomErrorResponse.class, "DepositBonusQuery"),
	gameInPromotionCommandSuccess(GameInPromotionCommandResp.class, "GameInPromotionCommand"),
	gameInPromotionCommandError(CustomErrorResponse.class, "GameInPromotionCommand"),
	gameRoundEndCommandSuccess(ResultOKResp.class, "GameRoundEndCommand"),
	gameRoundEndCommandError(CustomErrorResponse.class, "GameRoundEndCommand"),
	gameRoundStakeCommandSuccess(ResultOKResp.class, "GameRoundStakeCommand"),
	gameRoundStakeCommandError(CustomErrorResponse.class, "GameRoundStakeCommand"),
	getBonusTemplatesForAccountManagerQuerySuccess(GetBonusTemplatesForAccountManagerQueryResp.class, "GetBonusTemplatesForAccountManagerQuery"),
	getBonusTemplatesForAccountManagerQueryError(CustomErrorResponse.class, "GetBonusTemplatesForAccountManagerQuery"),
	getTermsAndConditionsQuerySuccess(ResultOKResp.class, "GetTermsAndConditionsQuery"),
	getTermsAndConditionsQueryError(CustomErrorResponse.class, "GetTermsAndConditionsQuery"),
	userBonusListQuerySuccess(UserBonusListQueryResp.class, "UserBonusListQuery"),
	userBonusListQueryError(CustomErrorResponse.class, "UserBonusListQuery"),
	bonusTypeQuerySuccess(BonusTypeQueryResp.class, "BonusTypeQuery"),
	bonusTypeQueryError(CustomErrorResponse.class, "BonusTypeQuery"),
	bonusCancelByUserCommandSuccess(ResultOKResp.class, "BonusCancelByUserCommand"),
	bonusCancelByUserCommandError(CustomErrorResponse.class, "BonusCancelByUserCommand"),
	bonusClaimCommandSuccess(ResultOKResp.class, "BonusClaimCommand"),
	bonusClaimCommandError(CustomErrorResponse.class, "BonusClaimCommand"),
	bonusCreditAndClaimCommandSuccess(ResultOKResp.class, "BonusCreditAndClaimCommand"),
	bonusCreditAndClaimCommandError(CustomErrorResponse.class, "BonusCreditAndClaimCommand"),
	bonusNotInterestedCommandSuccess(ResultOKResp.class, "BonusNotInterestedCommand"),
	bonusNotInterestedCommandError(CustomErrorResponse.class, "BonusNotInterestedCommand"),
	bonusProgressAmountQuerySuccess(BonusProgressAmountQueryResp.class, "BonusProgressAmountQuery"),
	bonusProgressAmountQueryError(CustomErrorResponse.class, "BonusProgressAmountQuery"),
	addCreditedUserSuccess(ResultOKResp.class, "AddCreditedUser"),
	addCreditedUserError(CustomErrorResponse.class, "AddCreditedUser"),
	manualBonusCreditAndClaimCommandSuccess(ResultOKResp.class, "ManualBonusCreditAndClaimcommand"),
	manualBonusCreditAndClaimCommandError(CustomErrorResponse.class, "ManualBonusCreditAndClaimcommand");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> GamingBonusEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
