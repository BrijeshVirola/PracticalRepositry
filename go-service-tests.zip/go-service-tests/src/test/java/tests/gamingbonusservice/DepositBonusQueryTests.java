package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.request.DepositBonusQueryReq;
import tests.gamingbonusservice.response.DepositBonusQueryResp;
import tests.gamingbonusservice.response.DepositBonusQueryResult;

public class DepositBonusQueryTests extends BaseClassSetup {

	@Test(description = "Make a request to DepositBonusQuery. Positive scenario.")
	public void DepositBonusQuery_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		DepositBonusQueryReq request = new DepositBonusQueryReq.Builder()
				.defaults()
				.userId(UsersId.GO_SVC_TEST111)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		DepositBonusQueryResp actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.depositBonusQuerySuccess);

		DepositBonusQueryResult result = new DepositBonusQueryResult.Builder()
				.defaults()
				.maxAmount(50)
				.build();

		DepositBonusQueryResp expectedResponse = new DepositBonusQueryResp.Builder()
				.defaults()
				.addResult(result)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to DepositBonusQuery. Unknown user_id parameter.")
	public void DepositBonusQuery_UnknownUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		DepositBonusQueryReq request = new DepositBonusQueryReq.Builder()
				.defaults()
				.userId(UsersId.NOT_EXISTING)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.depositBonusQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Error received while fetching deposit bonus. Could not retrieve UserData")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to DepositBonusQuery. Missing user_id parameter.")
	public void DepositBonusQuery_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		DepositBonusQueryReq request = new DepositBonusQueryReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.depositBonusQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to DepositBonusQuery. Missing sports_product_id parameter.")
	public void DepositBonusQuery_MissingSportsProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		DepositBonusQueryReq request = new DepositBonusQueryReq.Builder()
				.defaults()
				.sportsProductId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.depositBonusQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: sports_product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to DepositBonusQuery. Wrong method.")
	public void DepositBonusQuery_Wrong_Method() {

		DepositBonusQueryReq request = new DepositBonusQueryReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.depositBonusQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}