package tests.gamingbonusservice.request;

import java.util.HashMap;
import java.util.Map;

public class ActiveRingFencedBonusesQueryReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private ActiveRingFencedBonusesQueryReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
	}

	public static class Builder {
		private String method, id;
		private Integer user_id;
		@SuppressWarnings("unused")
		private Integer userbonus_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.method = "activeringfencedbonusesquery";
			this.user_id = 4761730; //autoRingFenced/Gamtest_4697
			return this;
		}

		public ActiveRingFencedBonusesQueryReq build() {
			return new ActiveRingFencedBonusesQueryReq(this);
		}
	}
}

