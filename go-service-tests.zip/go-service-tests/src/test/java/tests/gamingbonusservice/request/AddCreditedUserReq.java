package tests.gamingbonusservice.request;

import java.util.HashMap;
import java.util.Map;

public class AddCreditedUserReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private AddCreditedUserReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("bonustemplate_id", builder.bonustemplate_id);
		this.params.put("amount", builder.amount);
		this.params.put("creditedby", builder.creditedby);
	}

	public static class Builder {
		private String method, id, creditedby;
		private Integer user_id, bonustemplate_id;
		private Double amount;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder creditedBy(String creditedby) {
			this.creditedby = creditedby;
			return this;
		}
		
		public Builder bonusTemplateId(Integer bonustemplate_id) {
			this.bonustemplate_id = bonustemplate_id;
			return this;
		}
		
		public Builder amount(Double amount) {
			this.amount = amount;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.method = "addcrediteduser";
			this.user_id = 4445879;
			this.bonustemplate_id = 49;
			this.amount = 0.01;
			this.creditedby = "gaming bonus api automated tests";
			
			return this;
		}

		public AddCreditedUserReq build() {
			return new AddCreditedUserReq(this);
		}
	}
}
