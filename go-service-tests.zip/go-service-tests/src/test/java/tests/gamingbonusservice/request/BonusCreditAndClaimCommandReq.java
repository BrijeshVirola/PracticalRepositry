package tests.gamingbonusservice.request;

import java.util.HashMap;
import java.util.Map;

public class BonusCreditAndClaimCommandReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private BonusCreditAndClaimCommandReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("bonus_id", builder.bonus_id);
		this.params.put("amount", builder.amount);
		this.params.put("transaction_id", builder.transaction_id);
		this.params.put("sports_product_id", builder.sports_product_id);
		this.params.put("remote_ip", builder.remote_ip);
		this.params.put("bonus_implementation", builder.bonus_implementation);
	}

	public static class Builder {
		private String method, id;
		private Integer user_id, bonus_id, amount, sports_product_id, bonus_implementation;
		private Long transaction_id;
		private String remote_ip;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder bonusId(Integer bonus_id) {
			this.bonus_id = bonus_id;
			return this;
		}
		
		public Builder amount(Integer amount) {
			this.amount = amount;
			return this;
		}
		
		public Builder transactionId(Long transaction_id) {
			this.transaction_id = transaction_id;
			return this;
		}
		
		public Builder sportsProductId(Integer sports_product_id) {
			this.sports_product_id = sports_product_id;
			return this;
		}
		
		public Builder remoteIp(String remote_ip) {
			this.remote_ip = remote_ip;
			return this;
		}
		
		public Builder bonusImplementation(Integer bonus_implementation) {
			this.bonus_implementation = bonus_implementation;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.method = "bonuscreditandclaimcommand";
			this.user_id = 4408830;
			this.amount = 50;
			this.transaction_id = 30000117678L;
			this.sports_product_id = 3;
			this.remote_ip = "125.12.3.4";
			this.bonus_id = 1234657;
			this.bonus_implementation = 1;
			return this;
		}

		public BonusCreditAndClaimCommandReq build() {
			return new BonusCreditAndClaimCommandReq(this);
		}
	}
}

