package tests.gamingbonusservice.request;

import java.util.HashMap;
import java.util.Map;

public class BonusNotInterestedCommandReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private BonusNotInterestedCommandReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("userbonus_id", builder.userbonus_id);
	}

	public static class Builder {
		private String method, id;
		private Integer user_id, userbonus_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder userBonusId(Integer userbonus_id) {
			this.userbonus_id = userbonus_id;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.method = "bonusnotinterestedcommand";
			this.user_id = 4641187;
			this.userbonus_id = 17059;
			return this;
		}

		public BonusNotInterestedCommandReq build() {
			return new BonusNotInterestedCommandReq(this);
		}
	}
}

