package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.ExpectedFailure;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.request.AddCreditedUserReq;
import tests.gamingbonusservice.request.GetClosedBonusesQueryReq;
import tests.gamingbonusservice.response.ClosedBonusResult;
import tests.gamingbonusservice.response.GetClosedBonusesQueryResp;

public class GetClosedBonusesQueryTests extends BaseClassSetup {

	@Test(description = "Make a request to GetClosedBonusesQuery. Positive scenario.")
	public void getClosedBonusesQuery_Positive_Scenario() throws InterruptedException {

		Instant testStartTime = Instant.now().minusSeconds(60);//the 60 second adjustment is required as the datetime on the server running the test and the service are not in sync;

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = 4518261;
		Integer bonusTemplateId = 305;

		AddCreditedUserReq acuRequest = new AddCreditedUserReq.Builder()
				.defaults()
				.userId(userId)
				.bonusTemplateId(bonusTemplateId)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualAcuResponse =  BaseRequest.post(acuRequest, GamingBonusEndpoints.addCreditedUserSuccess);

		ResultOKResp expectedAcuResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedAcuResponse, actualAcuResponse);	

		String idForGetClosedBonusesQuery = UUID.randomUUID().toString();

		GetClosedBonusesQueryReq request = new GetClosedBonusesQueryReq.Builder()
				.defaults()
				.userId(userId)
				.datefrom(testStartTime.toString())
				.id(idForGetClosedBonusesQuery)
				.build();

		GetClosedBonusesQueryResp actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.getClosedBonusesQuerySuccess);

		Assert.assertEquals(actualResponse.getResults().size(), 1);
		ClosedBonusResult actualResponseResult = actualResponse.getResults().get(0);

		ClosedBonusResult expectedClosedBonusResult = new ClosedBonusResult.Builder()
				.defaults()
				.currency("EUR")
				.build();

		Assert.assertEquals(actualResponse.getId(), idForGetClosedBonusesQuery);
		Assert.assertTrue(actualResponse != null);

		Assert.assertTrue(actualResponseResult.userbonus_id > 0);
		Assert.assertEquals(actualResponseResult.qualifyingtransaction_amount, expectedClosedBonusResult.qualifyingtransaction_amount);
		Assert.assertEquals(actualResponseResult.priority, expectedClosedBonusResult.priority);
		Assert.assertEquals(actualResponseResult.admin, expectedClosedBonusResult.admin);
		Assert.assertEquals(actualResponseResult.bonustype_id, expectedClosedBonusResult.bonustype_id);

		Assert.assertEquals(actualResponseResult.bonustemplate_id, expectedClosedBonusResult.bonustemplate_id);
		Assert.assertEquals(actualResponseResult.bonustype_id, expectedClosedBonusResult.bonustype_id);
		Assert.assertTrue(actualResponseResult.userbonus_id > 0);
		Assert.assertEquals(actualResponseResult.amount_pence, expectedClosedBonusResult.amount_pence);
		Assert.assertEquals(actualResponseResult.ringfencedamount_pence, expectedClosedBonusResult.ringfencedamount_pence);
		Assert.assertEquals(actualResponseResult.progressamount_pence, expectedClosedBonusResult.progressamount_pence);
		Assert.assertEquals(actualResponseResult.completion_percentage, expectedClosedBonusResult.completion_percentage);
		Assert.assertEquals(actualResponseResult.userbonusstatus_id, expectedClosedBonusResult.userbonusstatus_id);
		Assert.assertEquals(actualResponseResult.minimumtransaction, expectedClosedBonusResult.minimumtransaction);
		Assert.assertEquals(actualResponseResult.maximumbonus, expectedClosedBonusResult.maximumbonus);

		Assert.assertEquals(actualResponseResult.bonustype, expectedClosedBonusResult.bonustype);

		Assert.assertEquals(actualResponseResult.currency, expectedClosedBonusResult.currency);
		Assert.assertEquals(actualResponseResult.statusname, expectedClosedBonusResult.statusname);
		Assert.assertEquals(actualResponseResult.templatename, expectedClosedBonusResult.templatename);
		Assert.assertEquals(actualResponseResult.rolloverrequirement, expectedClosedBonusResult.rolloverrequirement);
		Assert.assertEquals(actualResponseResult.createdby, expectedClosedBonusResult.createdby);

		Assert.assertEquals(actualResponseResult.is_claimed, expectedClosedBonusResult.is_claimed);
		Assert.assertEquals(actualResponseResult.is_expired, expectedClosedBonusResult.is_expired);
		Assert.assertEquals(actualResponseResult.is_redeemed, expectedClosedBonusResult.is_redeemed);
		Assert.assertEquals(actualResponseResult.notinterested, expectedClosedBonusResult.notinterested);
		Assert.assertEquals(actualResponseResult.depositmatched, expectedClosedBonusResult.depositmatched);
		Assert.assertEquals(actualResponseResult.is_cancellable, expectedClosedBonusResult.is_cancellable);
		Assert.assertEquals(actualResponseResult.is_autocredited, expectedClosedBonusResult.is_autocredited);
		Assert.assertEquals(actualResponseResult.qualifyingtransaction_date, expectedClosedBonusResult.qualifyingtransaction_date);

		Long timeSinceTestStarted = Duration.between(testStartTime, Instant.parse(actualResponseResult.expiry)).toMillis();
		Assert.assertTrue(timeSinceTestStarted >= 0);

		//these times are usually the same but can randomly differ by 1 second
		Instant dateAdded = Instant.parse(actualResponseResult.dateadded);
		Instant bonusClosedDate = Instant.parse(actualResponseResult.bonuscloseddate);
		Instant expiry = Instant.parse(actualResponseResult.expiry);
		List<Instant> dates = new ArrayList<Instant>();
		dates.add(dateAdded);
		dates.add(expiry);
		dates.add(bonusClosedDate);
		dates.sort(Comparator.naturalOrder());

		Assert.assertTrue(Duration.between(dates.get(0), dates.get(2)).toMillis() <= 1000);
	}

	@Test(description = "Make a request to GetClosedBonusesQuery without optional fields datefrom and dateto. Positive scenario.")
	public void getClosedBonusesQuery_PositiveWithoutOptionalFieldsInRequest_Scenario() throws InterruptedException {

		Instant testStartTime = Instant.now().minusSeconds(60);//the 60 second adjustment is required as the datetime on the server running the test and the service are not in sync;

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = 4419877;
		Integer bonusTemplateId = 305;

		AddCreditedUserReq acuRequest = new AddCreditedUserReq.Builder()
				.defaults()
				.userId(userId)
				.bonusTemplateId(bonusTemplateId)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualAcuResponse =  BaseRequest.post(acuRequest, GamingBonusEndpoints.addCreditedUserSuccess);

		ResultOKResp expectedAcuResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedAcuResponse, actualAcuResponse);	

		String idForGetClosedBonusesQuery = UUID.randomUUID().toString();

		GetClosedBonusesQueryReq request = new GetClosedBonusesQueryReq.Builder()
				.defaults()
				.userId(userId)
				.datefrom(null)
				.dateto(null)
				.id(idForGetClosedBonusesQuery)
				.build();

		GetClosedBonusesQueryResp actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.getClosedBonusesQuerySuccess);

		List<ClosedBonusResult> results = actualResponse.getResults();

		ClosedBonusResult actualNewlyCreatedBonus = null;

		for (ClosedBonusResult result : results) {
			Long timeSinceTestStarted = Duration.between(testStartTime, Instant.parse(result.dateadded)).toMillis();
			if (timeSinceTestStarted >= 0) {
				actualNewlyCreatedBonus = result;
				break;
			}
		}

		Assert.assertTrue(actualResponse.getResults().size() > 1);

		ClosedBonusResult expectedClosedBonusResult = new ClosedBonusResult.Builder()
				.defaults()
				.build();

		Assert.assertEquals(actualResponse.getId(), idForGetClosedBonusesQuery);

		Assert.assertTrue(actualNewlyCreatedBonus.userbonus_id > 0);
		Assert.assertEquals(actualNewlyCreatedBonus.qualifyingtransaction_amount, expectedClosedBonusResult.qualifyingtransaction_amount);
		Assert.assertEquals(actualNewlyCreatedBonus.priority, expectedClosedBonusResult.priority);
		Assert.assertEquals(actualNewlyCreatedBonus.admin, expectedClosedBonusResult.admin);
		Assert.assertEquals(actualNewlyCreatedBonus.bonustype_id, expectedClosedBonusResult.bonustype_id);

		Assert.assertEquals(actualNewlyCreatedBonus.bonustemplate_id, expectedClosedBonusResult.bonustemplate_id);
		Assert.assertEquals(actualNewlyCreatedBonus.bonustype_id, expectedClosedBonusResult.bonustype_id);
		Assert.assertTrue(actualNewlyCreatedBonus.userbonus_id > 0);
		Assert.assertEquals(actualNewlyCreatedBonus.amount_pence, expectedClosedBonusResult.amount_pence);
		Assert.assertEquals(actualNewlyCreatedBonus.ringfencedamount_pence, expectedClosedBonusResult.ringfencedamount_pence);
		Assert.assertEquals(actualNewlyCreatedBonus.progressamount_pence, expectedClosedBonusResult.progressamount_pence);
		Assert.assertEquals(actualNewlyCreatedBonus.completion_percentage, expectedClosedBonusResult.completion_percentage);
		Assert.assertEquals(actualNewlyCreatedBonus.userbonusstatus_id, expectedClosedBonusResult.userbonusstatus_id);
		Assert.assertEquals(actualNewlyCreatedBonus.minimumtransaction, expectedClosedBonusResult.minimumtransaction);
		Assert.assertEquals(actualNewlyCreatedBonus.maximumbonus, expectedClosedBonusResult.maximumbonus);

		Assert.assertEquals(actualNewlyCreatedBonus.bonustype, expectedClosedBonusResult.bonustype);

		Assert.assertEquals(actualNewlyCreatedBonus.currency, expectedClosedBonusResult.currency);
		Assert.assertEquals(actualNewlyCreatedBonus.statusname, expectedClosedBonusResult.statusname);
		Assert.assertEquals(actualNewlyCreatedBonus.templatename, expectedClosedBonusResult.templatename);
		Assert.assertEquals(actualNewlyCreatedBonus.rolloverrequirement, expectedClosedBonusResult.rolloverrequirement);
		Assert.assertEquals(actualNewlyCreatedBonus.createdby, expectedClosedBonusResult.createdby);

		Assert.assertEquals(actualNewlyCreatedBonus.is_claimed, expectedClosedBonusResult.is_claimed);
		Assert.assertEquals(actualNewlyCreatedBonus.is_expired, expectedClosedBonusResult.is_expired);
		Assert.assertEquals(actualNewlyCreatedBonus.is_redeemed, expectedClosedBonusResult.is_redeemed);
		Assert.assertEquals(actualNewlyCreatedBonus.notinterested, expectedClosedBonusResult.notinterested);
		Assert.assertEquals(actualNewlyCreatedBonus.depositmatched, expectedClosedBonusResult.depositmatched);
		Assert.assertEquals(actualNewlyCreatedBonus.is_cancellable, expectedClosedBonusResult.is_cancellable);
		Assert.assertEquals(actualNewlyCreatedBonus.is_autocredited, expectedClosedBonusResult.is_autocredited);
		Assert.assertEquals(actualNewlyCreatedBonus.qualifyingtransaction_date, expectedClosedBonusResult.qualifyingtransaction_date);

		Long timeSinceTestStarted = Duration.between(testStartTime, Instant.parse(actualNewlyCreatedBonus.expiry)).toMillis();
		Assert.assertTrue(timeSinceTestStarted >= 0);

		//these times are usually the same but can randomly differ by 1 second
		Instant dateAdded = Instant.parse(actualNewlyCreatedBonus.dateadded);
		Instant bonusClosedDate = Instant.parse(actualNewlyCreatedBonus.bonuscloseddate);
		Instant expiry = Instant.parse(actualNewlyCreatedBonus.expiry);

		List<Instant> dates = new ArrayList<Instant>();
		dates.add(dateAdded);
		dates.add(expiry);
		dates.add(bonusClosedDate);
		dates.sort(Comparator.naturalOrder());

		Assert.assertTrue(Duration.between(dates.get(0), dates.get(2)).toMillis() <= 1000);

		Assert.assertEquals(actualNewlyCreatedBonus.expiry, actualNewlyCreatedBonus.dateadded);
		Assert.assertEquals(actualNewlyCreatedBonus.expiry, actualNewlyCreatedBonus.bonuscloseddate);
	}

	@ExpectedFailure(jiraRef = "PRJSAK-2278", action="test disabled")
	@Test(enabled=false, description = "Make a request to getClosedBonusesQuery. Unknown user_id parameter.")
	public void getClosedBonusesQuery_UnknownUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetClosedBonusesQueryReq request = new GetClosedBonusesQueryReq.Builder()
				.defaults()
				.userId(UsersId.NOT_EXISTING)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.getClosedBonusesQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Could not retrieve UserData")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getClosedBonusesQuery. Missing user_id parameter.")
	public void getClosedBonusesQuery_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetClosedBonusesQueryReq request = new GetClosedBonusesQueryReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.getClosedBonusesQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getClosedBonusesQuery. Wrong method.")
	public void getClosedBonusesQuery_Wrong_Method() {

		GetClosedBonusesQueryReq request = new GetClosedBonusesQueryReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.getClosedBonusesQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}