package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.request.AcknowledgeCashBonusCommandReq;
import tests.gamingbonusservice.request.GetClosedBonusesQueryReq;
import tests.gamingbonusservice.response.ClosedBonusResult;
import tests.gamingbonusservice.response.GetClosedBonusesQueryResp;

public class AcknowledgeCashBonusCommandTests extends BaseClassSetup {

	@Test(description = "Make a request to AcknowledgeCashBonusCommand. Positive scenario.")
	public void acknowledgeCashBonusCommand_Positive_Scenario() throws InterruptedException {

		Instant testStartTime = Instant.now().minusSeconds(60);//the 60 second adjustment is required as the date-time on the server running the test and the service are not in sync;

		Integer userId = 4508920;
		Integer bonusTemplateId = 305;
		Double amount = 0.01;

		Utils.createBonus(userId, bonusTemplateId, amount);

		String idForGetClosedBonusesQuery = UUID.randomUUID().toString();

		GetClosedBonusesQueryReq request = new GetClosedBonusesQueryReq.Builder()
				.defaults()
				.userId(userId)
				.datefrom(testStartTime.toString())
				.id(idForGetClosedBonusesQuery)
				.build();

		GetClosedBonusesQueryResp actualResponse = BaseRequest.post(request, GamingBonusEndpoints.getClosedBonusesQuerySuccess);

		Assert.assertEquals(actualResponse.getResults().size(), 1);
		ClosedBonusResult actualResponseResult = actualResponse.getResults().get(0);

		ClosedBonusResult expectedClosedBonusResult = new ClosedBonusResult.Builder()
				.defaults()
				.currency("EUR")
				.build();

		Assert.assertEquals(actualResponse.getId(), idForGetClosedBonusesQuery);
		Assert.assertTrue(actualResponse != null);

		Assert.assertTrue(actualResponseResult.userbonus_id > 0);
		Assert.assertEquals(actualResponseResult.qualifyingtransaction_amount, expectedClosedBonusResult.qualifyingtransaction_amount);
		Assert.assertEquals(actualResponseResult.priority, expectedClosedBonusResult.priority);
		Assert.assertEquals(actualResponseResult.admin, expectedClosedBonusResult.admin);
		Assert.assertEquals(actualResponseResult.bonustype_id, expectedClosedBonusResult.bonustype_id);

		Assert.assertEquals(actualResponseResult.bonustemplate_id, expectedClosedBonusResult.bonustemplate_id);
		Assert.assertEquals(actualResponseResult.bonustype_id, expectedClosedBonusResult.bonustype_id);
		Assert.assertTrue(actualResponseResult.userbonus_id > 0);
		Assert.assertEquals(actualResponseResult.amount_pence, expectedClosedBonusResult.amount_pence);
		Assert.assertEquals(actualResponseResult.ringfencedamount_pence, expectedClosedBonusResult.ringfencedamount_pence);
		Assert.assertEquals(actualResponseResult.progressamount_pence, expectedClosedBonusResult.progressamount_pence);
		Assert.assertEquals(actualResponseResult.completion_percentage, expectedClosedBonusResult.completion_percentage);
		Assert.assertEquals(actualResponseResult.userbonusstatus_id, expectedClosedBonusResult.userbonusstatus_id);
		Assert.assertEquals(actualResponseResult.minimumtransaction, expectedClosedBonusResult.minimumtransaction);
		Assert.assertEquals(actualResponseResult.maximumbonus, expectedClosedBonusResult.maximumbonus);

		Assert.assertEquals(actualResponseResult.bonustype, expectedClosedBonusResult.bonustype);

		Assert.assertEquals(actualResponseResult.currency, expectedClosedBonusResult.currency);
		Assert.assertEquals(actualResponseResult.statusname, expectedClosedBonusResult.statusname);
		Assert.assertEquals(actualResponseResult.templatename, expectedClosedBonusResult.templatename);
		Assert.assertEquals(actualResponseResult.rolloverrequirement, expectedClosedBonusResult.rolloverrequirement);
		Assert.assertEquals(actualResponseResult.createdby, expectedClosedBonusResult.createdby);

		Assert.assertEquals(actualResponseResult.is_claimed, expectedClosedBonusResult.is_claimed);
		Assert.assertEquals(actualResponseResult.is_expired, expectedClosedBonusResult.is_expired);
		Assert.assertEquals(actualResponseResult.is_redeemed, expectedClosedBonusResult.is_redeemed);
		Assert.assertEquals(actualResponseResult.notinterested, expectedClosedBonusResult.notinterested);
		Assert.assertEquals(actualResponseResult.depositmatched, expectedClosedBonusResult.depositmatched);
		Assert.assertEquals(actualResponseResult.is_cancellable, expectedClosedBonusResult.is_cancellable);
		Assert.assertEquals(actualResponseResult.is_autocredited, expectedClosedBonusResult.is_autocredited);
		Assert.assertEquals(actualResponseResult.qualifyingtransaction_date, expectedClosedBonusResult.qualifyingtransaction_date);

		Long timeSinceTestStarted = Duration.between(testStartTime, Instant.parse(actualResponseResult.expiry)).toMillis();
		Assert.assertTrue(timeSinceTestStarted >= 0);

		//these times are usually the same but can randomly differ by 1 second
		Instant dateAdded = Instant.parse(actualResponseResult.dateadded);
		Instant bonusClosedDate = Instant.parse(actualResponseResult.bonuscloseddate);
		Instant expiry = Instant.parse(actualResponseResult.expiry);
		List<Instant> dates = new ArrayList<Instant>();
		dates.add(dateAdded);
		dates.add(expiry);
		dates.add(bonusClosedDate);
		dates.sort(Comparator.naturalOrder());

		Assert.assertTrue(Duration.between(dates.get(0), dates.get(2)).toMillis() <= 1000);
		String idForAcknowledgeCashBonusCommand = UUID.randomUUID().toString();

		AcknowledgeCashBonusCommandReq requestAcknowledgeCashBonusCommand = new AcknowledgeCashBonusCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(actualResponseResult.userbonus_id)
				.id(idForAcknowledgeCashBonusCommand)
				.build();

		ResultOKResp actualAcknowledgeCashBonusCommandResp =  BaseRequest.post(requestAcknowledgeCashBonusCommand, GamingBonusEndpoints.acknowledgeCashBonusCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForAcknowledgeCashBonusCommand)
				.build();

		assertReflectionEquals(expectedResponse, actualAcknowledgeCashBonusCommandResp);	

		//TODO move this over to verify via activebonusquery endpoint once PRJSAK-2288 is complete

	}

	@Test(description = "Make a request to acknowledgeCashBonusCommand. Missing user_id parameter.")
	public void acknowledgeCashBonusCommand_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		AcknowledgeCashBonusCommandReq request = new AcknowledgeCashBonusCommandReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.acknowledgeCashBonusCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to acknowledgeCashBonusCommand. Missing userbonus_id parameter.")
	public void acknowledgeCashBonusCommand_MissingUserBonusId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		AcknowledgeCashBonusCommandReq request = new AcknowledgeCashBonusCommandReq.Builder()
				.defaults()
				.userBonusId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.acknowledgeCashBonusCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: userbonus_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to acknowledgeCashBonusCommand. Wrong method.")
	public void acknowledgeCashBonusCommand_Wrong_Method() {

		AcknowledgeCashBonusCommandReq request = new AcknowledgeCashBonusCommandReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.acknowledgeCashBonusCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}

