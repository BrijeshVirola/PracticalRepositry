package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.request.ActiveRingFencedBonusesQueryReq;
import tests.gamingbonusservice.response.ActiveRingFencedBonusesQueryResp;
import tests.gamingbonusservice.response.ActiveRingFencedBonusesQueryResult;

public class ActiveRingFencedBonusesQueryTests extends BaseClassSetup {

	@Test(description = "Make a request to ActiveRingFencedBonusesQuery. Positive scenario.")
	public void activeRingFencedBonusesQuery_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ActiveRingFencedBonusesQueryReq request = new ActiveRingFencedBonusesQueryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ActiveRingFencedBonusesQueryResp actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.activeRingFencedBonusesQuerySuccess);

		ActiveRingFencedBonusesQueryResult result = new ActiveRingFencedBonusesQueryResult.Builder()
				.defaults()
				.build();

		ActiveRingFencedBonusesQueryResp expectedResponse = new ActiveRingFencedBonusesQueryResp.Builder()
				.defaults()
				.addResult(result)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to activeRingFencedBonusesQuery. Missing user_id parameter.")
	public void activeRingFencedBonusesQuery_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ActiveRingFencedBonusesQueryReq request = new ActiveRingFencedBonusesQueryReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.activeRingFencedBonusesQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to activeRingFencedBonusesQuery. Wrong method.")
	public void activeRingFencedBonusesQuery_Wrong_Method() {

		ActiveRingFencedBonusesQueryReq request = new ActiveRingFencedBonusesQueryReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.activeRingFencedBonusesQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}

