package tests.gamingbonusservice.response;

public class BonusType {	
	
	@SuppressWarnings("unused")
	private Integer BonusTypeID;
	@SuppressWarnings("unused")
	private String BonusName;

	private BonusType(Builder builder) {
		
		this.BonusName = builder.bonusName;
		this.BonusTypeID = builder.bonusTypeID;
	}

	public static class Builder {
		private Integer bonusTypeID;
		private String bonusName;

		public Builder bonusName(String bonusName) {
			this.bonusName = bonusName;
			return this;
		}
		
		public Builder bonusTypeId(Integer bonusTypeID) {
			this.bonusTypeID = bonusTypeID;
			return this;
		}
		
		public Builder defaults() {
			this.bonusTypeID = 3;
			this.bonusName = "Cash";
			return this;
		}

		public BonusType build() {
			return new BonusType(this);
		}
	}
}

