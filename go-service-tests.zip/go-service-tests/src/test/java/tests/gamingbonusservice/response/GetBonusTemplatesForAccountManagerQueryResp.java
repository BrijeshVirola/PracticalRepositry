package tests.gamingbonusservice.response;

import java.util.ArrayList;
import java.util.List;

public class GetBonusTemplatesForAccountManagerQueryResp {

	private String id;
	private List<GetBonusTemplatesForAccountManagerQueryResult> result;
 
	private GetBonusTemplatesForAccountManagerQueryResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public String getId() {
		return this.id;
	}
	
	public List<GetBonusTemplatesForAccountManagerQueryResult> getResults() {
		return this.result;
	}
	
	public static class Builder {
		private String id;
		private List<GetBonusTemplatesForAccountManagerQueryResult> result = new ArrayList<GetBonusTemplatesForAccountManagerQueryResult>();

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder addResult(GetBonusTemplatesForAccountManagerQueryResult getBonusTemplatesForAccountManagerQueryResult) {
			this.result.add(getBonusTemplatesForAccountManagerQueryResult);
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			return this;
		}

		public GetBonusTemplatesForAccountManagerQueryResp build() {
			return new GetBonusTemplatesForAccountManagerQueryResp(this);
		}
	}
}