package tests.gamingbonusservice.response;

public class EligibleGame {	
	
	private Integer gametoken_id;

	private EligibleGame(Builder builder) {
		this.gametoken_id = builder.gametoken_id;
	}
	
	public Integer getGameTokenId() {
		return this.gametoken_id;
	}
	
	public static class Builder {
		private Integer gametoken_id;
		
		public Builder gametokenId(Integer gametoken_id) {
			this.gametoken_id = gametoken_id;
			return this;
		}
		
		public Builder defaults() {
			this.gametoken_id = 3;
			return this;
		}

		public EligibleGame build() {
			return new EligibleGame(this);
		}
	}
}
