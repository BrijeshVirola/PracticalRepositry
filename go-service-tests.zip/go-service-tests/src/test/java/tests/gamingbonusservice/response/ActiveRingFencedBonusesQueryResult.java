package tests.gamingbonusservice.response;

public class ActiveRingFencedBonusesQueryResult {	
	
	public Integer bonus_implementation, userbonus_id, sports_product_id;
	public String title, ringfencedamount;
	public ActiveRingFencedBonusesQueryResult(Builder builder) {
		
		this.bonus_implementation = builder.bonus_implementation;
		this.sports_product_id = builder.sports_product_id;
		this.userbonus_id = builder.userbonus_id;
		this.title = builder.title;
		this.ringfencedamount = builder.ringfencedamount;
	}

	public static class Builder {
		private Integer bonus_implementation, userbonus_id, sports_product_id;
		private String title, ringfencedamount;
		
		public Builder bonusImplementation(Integer bonus_implementation) {
			this.bonus_implementation = bonus_implementation;
			return this;
		}
		
		public Builder sportsProductId(Integer sports_product_id) {
			this.sports_product_id = sports_product_id;
			return this;
		}
		
		public Builder userBonusId(Integer userbonus_id) {
			this.userbonus_id = userbonus_id;
			return this;
		}
		
		public Builder title(String title) {
			this.title = title;
			return this;
		}
		
		public Builder ringFencedAmount(String ringfencedamount) {
			this.ringfencedamount = ringfencedamount;
			return this;
		}
		
		public Builder defaults() {
			
			this.title = "NPB Deposit Bonus";
			this.ringfencedamount ="10";
			this.userbonus_id = 12130; //bonus id 181 
			this.sports_product_id = 3;
			this.bonus_implementation = 2;			
			return this;
		}

		public ActiveRingFencedBonusesQueryResult build() {
			return new ActiveRingFencedBonusesQueryResult(this);
		}
	}
}
