package tests.gamingbonusservice.response;

import java.util.ArrayList;
import java.util.List;

public class BonusTypeQueryResp {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private List<BonusType> result;
 
	private BonusTypeQueryResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public static class Builder {
		private String id;
		private List<BonusType> result = new ArrayList<BonusType>();

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder addResult(BonusType bonusType) {
			this.result.add(bonusType);
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			return this;
		}

		public BonusTypeQueryResp build() {
			return new BonusTypeQueryResp(this);
		}
	}
}