package tests.gameplaylimitservice.request;

import java.util.ArrayList;
import java.util.List;

import common.enumsconstants.UsersId;
import tests.gameplaylimitservice.requestobjects.PerGroupLimitDetails;

public class GetCurrentSummaryReq {

	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private Params params;

	private GetCurrentSummaryReq(Builder builder) {
		this.Id = builder.id;
		this.Method = builder.method;
		this.params = new Params(builder);
	}

	public static class Builder {

		private String id;
		private String method;
		private Integer user_id;
		public List<Integer> spend_group_user_ids;
		public PerGroupLimitDetails per_group_limit_details;
		public Long local_date_utc_offset;
		public Integer week_start_day;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder addSpendGroupUserIds(Integer spend_group_user_id) {
	        this.spend_group_user_ids.add(spend_group_user_id);
			return this;
		}

		public Builder addPerGroupLimitDetails(PerGroupLimitDetails perGroupLimitDetails) {

			this.per_group_limit_details = perGroupLimitDetails;
			return this;
		}

		public Builder localDateUtcOffset(Long local_date_utc_offset) {
			this.local_date_utc_offset = local_date_utc_offset;
			return this;
		}

		public Builder weekStartDay(Integer week_start_day) {
			this.week_start_day = week_start_day;
			return this;
		}

		public Builder defaults() {
			this.id = "Id";
			this.method = "getcurrentsummary";
			this.user_id = UsersId.GO_SVC_TESTS80;
			this.local_date_utc_offset = -10800000000000L;
			this.spend_group_user_ids = new ArrayList<>();
			this.week_start_day = 0;
			return this;
		}

		public GetCurrentSummaryReq build() {
			return new GetCurrentSummaryReq(this);
		}

		public Builder spendGroupDefaultsMax() {
			this.spend_group_user_ids.add(2147483647);
			this.spend_group_user_ids.add(2147483647);

			return this;
		}

		public Builder spendGroupDefaultsMin() {
			this.spend_group_user_ids.add(-2147483648);
			this.spend_group_user_ids.add(-2147483648);

			return this;
		}
	}



	public class Params {

		@SuppressWarnings("unused")
		private Integer user_id;
		@SuppressWarnings("unused")
		private List<Integer> spend_group_user_ids;
		@SuppressWarnings("unused")
		private PerGroupLimitDetails per_group_limit_details;
		@SuppressWarnings("unused")
		private Long local_date_utc_offset;
		@SuppressWarnings("unused")
		private Integer local_date_utc_offset_Max_Value;
		@SuppressWarnings("unused")
		private Integer week_start_day;
		@SuppressWarnings("unused")
		private Long user_idLong;

		public Params(Builder builder) {
			this.user_id = builder.user_id;
			this.spend_group_user_ids = builder.spend_group_user_ids;
			this.per_group_limit_details = builder.per_group_limit_details;
			this.local_date_utc_offset = builder.local_date_utc_offset;
			this.week_start_day = builder.week_start_day;
		}

		public Params weekDay(Integer week_start_day) {
			this.week_start_day = week_start_day;
			return this;
		}

		public Params localDateUtcOffset(Long local_date_utc_offset) {
			this.local_date_utc_offset = local_date_utc_offset;
			return this;
		}

		public Params spendGroupUserIds(List<Integer> spend_group_user_ids) {
			this.spend_group_user_ids = spend_group_user_ids;
			return this;
		}

		public Params userIdLong(Long user_idLong) {
			this.user_idLong = user_idLong;
			return this;
		}
	}
}
