package tests.gameplaylimitservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.gameplaylimitservice.enums.GameplayLimitEndpoints;
import tests.gameplaylimitservice.request.ApplySpendReq;
import tests.gameplaylimitservice.request.GetCurrentSummaryReq;
import tests.gameplaylimitservice.requestobjects.PerGroupLimitDetails;
import tests.gameplaylimitservice.response.ApplySpendResp;
import tests.gameplaylimitservice.response.GetCurrentSummaryResp;
import tests.gameplaylimitservice.responseobjects.GameplaySummary;


public class ApplySpendTests extends BaseClassSetup {

	@Test(description = "Make a request to ApplySpend. Positive scenario.")
	public void applySpend_Positive_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		//1. Create  per group limit details for GetCurrentSummary request
		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier("A")
				.build();

		//2. Send GetCurrentySummary request to obtain user's current summary
		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TEST101)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST101)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		//3. Store actual response for verification
		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		String idApplySpendResponseId = UUID.randomUUID().toString();

		BigDecimal spendAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		//4. Send ApplySpend request to apply spend for a user
		ApplySpendReq requestApplySpend = new ApplySpendReq.Builder().defaults()
				.id(idApplySpendResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TEST101)
				.spendAmount(spendAmount)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST101)
				.build();

		ApplySpendResp actualResponseApplySpend =  BaseRequest.post(requestApplySpend, GameplayLimitEndpoints.applySpendSuccess);

		//5. Build the response for validation
		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		//6. Validate the response from ApplySpend request
		ApplySpendResp expResponse = new ApplySpendResp.Builder()
				.defaults()
				.id(idApplySpendResponseId)
				.applySpendDatetimeUtc(actualResponseApplySpend.getSpendDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponseApplySpend);
	}

	@Test(description = "Make a request to ApplySpend. Week Start Day parameter - Positive scenario.", dataProvider = "setWeekStartDaySuccess", dataProviderClass = DataProviders.class)
	public void ApplySpend_Week_Start_Day_Range_Parameter(Integer week_start_day) {
		BigDecimal spendAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String idApplySpendResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier("B")
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.weekStartDay(week_start_day)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST102)
				.userId(UsersId.GO_SVC_TEST102)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		ApplySpendReq requestApplySpend = new ApplySpendReq.Builder().defaults()
				.id(idApplySpendResponseId)
				.weekStartDay(week_start_day)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TEST102)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST102)
				.spendAmount(spendAmount)
				.build();

		ApplySpendResp actualResponseApplySpend =  BaseRequest.post(requestApplySpend, GameplayLimitEndpoints.applySpendSuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		ApplySpendResp expResponse = new ApplySpendResp.Builder()
				.defaults()
				.id(idApplySpendResponseId)
				.applySpendDatetimeUtc(actualResponseApplySpend.getSpendDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponseApplySpend);
	}

	@Test(description = "Make a request to ApplySpend. Bucket_type - success range parameter for Per Group Limit Details - Positive Scenario.", dataProvider = "bucketTypeRangeSuccess", dataProviderClass = DataProviders.class)
	public void ApplySpend_Per_Group_Limit_Details_Bucket_Type_range_success_Parameter(String bucket_type) {
		BigDecimal spendAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String idApplySpendResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.bucketType(bucket_type)
				.groupIdentifier("C")
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST103)
				.userId(UsersId.GO_SVC_TEST103)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		ApplySpendReq requestApplySpend = new ApplySpendReq.Builder().defaults()
				.id(idApplySpendResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TEST103)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST103)
				.spendAmount(spendAmount)
				.build();

		ApplySpendResp actualResponseApplySpend =  BaseRequest.post(requestApplySpend, GameplayLimitEndpoints.applySpendSuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType(bucket_type)
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		ApplySpendResp expResponse = new ApplySpendResp.Builder()
				.defaults()
				.id(idApplySpendResponseId)
				.applySpendDatetimeUtc(actualResponseApplySpend.getSpendDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponseApplySpend);
	}

	@Test(description = "Make a request to ApplySpend. Group_identifier range parameter for Per Group Limit Details - Positive Scenario.", dataProvider = "groupIdentifierSuccess", dataProviderClass = DataProviders.class)
	public void ApplySpend_Per_Group_Limit_Details_group_identifier_range_success_Parameter(String group_identifier) {
		BigDecimal spendAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String idApplySpendResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier(group_identifier)
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST104)
				.userId(UsersId.GO_SVC_TEST104)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		ApplySpendReq requestApplySpend = new ApplySpendReq.Builder().defaults()
				.id(idApplySpendResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TEST104)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST104)
				.spendAmount(spendAmount)
				.build();

		ApplySpendResp actualResponseApplySpend =  BaseRequest.post(requestApplySpend, GameplayLimitEndpoints.applySpendSuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		ApplySpendResp expResponse = new ApplySpendResp.Builder()
				.defaults()
				.id(idApplySpendResponseId)
				.applySpendDatetimeUtc(actualResponseApplySpend.getSpendDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponseApplySpend);
	}

	@Test(description = "Make a request to ApplySpend - Min Spend Amount - 0.01. Positive scenario.")
	public void ApplySpend_Spend_Amount_0_01_Positive_Scenario() {
		BigDecimal spendAmount = new BigDecimal(0.01).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String idApplySpendResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier("D")
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TEST105)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST105)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		ApplySpendReq requestApplySpend = new ApplySpendReq.Builder().defaults()
				.id(idApplySpendResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TEST105)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST105)
				.spendAmount(spendAmount)
				.build();

		ApplySpendResp actualResponseApplySpend =  BaseRequest.post(requestApplySpend, GameplayLimitEndpoints.applySpendSuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		ApplySpendResp expResponse = new ApplySpendResp.Builder()
				.defaults()
				.id(idApplySpendResponseId)
				.applySpendDatetimeUtc(actualResponseApplySpend.getSpendDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponseApplySpend);
	}

	@Test(description = "Make a request to ApplySpend. Local Date Time - Range parameter - Positive Scenario.", dataProvider = "localDateTimeSuccess", dataProviderClass = DataProviders.class)
	public void ApplySpend_Local_Date_Utc_Offset_Range_Parameter_positive_scenario(Long local_date_utc_offset) {
		BigDecimal spendAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String idApplySpendResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier("E")
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.localDateUtcOffset(local_date_utc_offset)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TEST106)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST106)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		ApplySpendReq requestApplySpend = new ApplySpendReq.Builder().defaults()
				.id(idApplySpendResponseId)
				.localDateUtcOffset(local_date_utc_offset)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TEST106)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST106)
				.spendAmount(spendAmount)
				.build();

		ApplySpendResp actualResponseApplySpend =  BaseRequest.post(requestApplySpend, GameplayLimitEndpoints.applySpendSuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		ApplySpendResp expResponse = new ApplySpendResp.Builder()
				.defaults()
				.id(idApplySpendResponseId)
				.applySpendDatetimeUtc(actualResponseApplySpend.getSpendDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponseApplySpend);
	}

	@Test(description = "Make a request to ApplySpend. Local Date Time - Defaults to 0 - Positive Scenario.")
	public void ApplySpend_Local_Date_Utc_Offset_Defaults_To_0_positive_scenario() {
		BigDecimal spendAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String idApplySpendResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier("F")
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TEST107)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST107)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		ApplySpendReq requestApplySpend = new ApplySpendReq.Builder().defaults()
				.id(idApplySpendResponseId)
				.localDateUtcOffset(null)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TEST107)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST107)
				.spendAmount(spendAmount)
				.build();

		ApplySpendResp actualResponseApplySpend =  BaseRequest.post(requestApplySpend, GameplayLimitEndpoints.applySpendSuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		ApplySpendResp expResponse = new ApplySpendResp.Builder()
				.defaults()
				.id(idApplySpendResponseId)
				.applySpendDatetimeUtc(actualResponseApplySpend.getSpendDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponseApplySpend);
	}

	@Test(description = "Make a request to ApplySpend. Week Start Day - Defaults to 0 - Positive Scenario.")
	public void ApplySpend_Week_Start_Day_Defaults_To_0_positive_scenario() {
		BigDecimal spendAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String idApplySpendResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier("G")
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TEST108)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST108)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		ApplySpendReq requestApplySpend = new ApplySpendReq.Builder().defaults()
				.id(idApplySpendResponseId)
				.weekStartDay(null)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TEST108)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST108)
				.spendAmount(spendAmount)
				.build();

		ApplySpendResp actualResponseApplySpend =  BaseRequest.post(requestApplySpend, GameplayLimitEndpoints.applySpendSuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		ApplySpendResp expResponse = new ApplySpendResp.Builder()
				.defaults()
				.id(idApplySpendResponseId)
				.applySpendDatetimeUtc(actualResponseApplySpend.getSpendDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponseApplySpend);
	}

	@Test(description = "Make a request to ApplySpend - Per Group Limit Details - Optional Field. Positive scenario.")
	public void applySpend_Per_Group_Limit_Details_Optional_Positive_Scenario() {
		BigDecimal spendAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String idApplySpendResponseId = UUID.randomUUID().toString();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(UsersId.GO_SVC_TEST109)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST109)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();

		ApplySpendReq requestApplySpend = new ApplySpendReq.Builder().defaults()
				.id(idApplySpendResponseId)
				.userId(UsersId.GO_SVC_TEST109)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST109)
				.spendAmount(spendAmount)
				.build();

		ApplySpendResp actualResponseApplySpend =  BaseRequest.post(requestApplySpend, GameplayLimitEndpoints.applySpendSuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).add(spendAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		ApplySpendResp expResponse = new ApplySpendResp.Builder()
				.defaults()
				.id(idApplySpendResponseId)
				.applySpendDatetimeUtc(actualResponseApplySpend.getSpendDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.build();

		assertReflectionEquals(expResponse, actualResponseApplySpend);
	}

	@Test(description = "Make a request to ApplySpend. Wrong method.")
	public void ApplySpend_Wrong_Method() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		ApplySpendReq request = new ApplySpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applySpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to ApplySpend. Missing user_id parameter.")
	public void ApplySpend_UserId_Missing_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplySpendReq request = new ApplySpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applySpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: user_id is missing")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to ApplySpend. Missing spend_group_user_ids parameter.")
	public void ApplySpend_Spend_Group_User_Ids_Missing_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplySpendReq request = new ApplySpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applySpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: spend_group_user_ids is missing")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to ApplySpend. Missing spend_amount parameter.")
	public void ApplySpend_Spend_Amount_Missing_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplySpendReq request = new ApplySpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST103)
				.spendAmount(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applySpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: spend_amount must be > 0")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to ApplySpend - Apply Amount - 0. Negative scenario.")
	public void ApplySpend_Spend_Amount_0_Negative_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		ApplySpendReq request = new ApplySpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST103)
				.spendAmount(new BigDecimal(0.00))
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applySpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: spend_amount must be > 0")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to ApplySpend. Week start day out of range parameter - Negative scenario.", dataProvider = "setWeekStartDayFailure", dataProviderClass = DataProviders.class)
	public void ApplySpend_Week_Start_Day_Out_Of_Range_Parameter(Integer week_start_day) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		ApplySpendReq request = new ApplySpendReq.Builder()
				.defaults()
				.weekStartDay(week_start_day)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST103)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applySpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: week_start_day must be between 0 and 6")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to ApplySpend. Local time out of range - parameter.", dataProvider = "localDateTimeFailure", dataProviderClass = DataProviders.class)
	public void ApplySpend_Local_Date_Utc_Offset_Out_Of_Range_Parameter(Long local_date_utc_offset) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		ApplySpendReq request = new ApplySpendReq.Builder()
				.defaults()
				.localDateUtcOffset(local_date_utc_offset)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST103)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applySpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: local_date_utc_offset must be between -86400000000000 and 86400000000000")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to ApplySpend. bucket_type out of range - parameter.", dataProvider = "bucketTypeRangeFailure", dataProviderClass = DataProviders.class)
	public void ApplySpend_Bucket_Type_Out_Of_Range_Parameter(String bucket_type) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.bucketType(bucket_type)
				.build();

		ApplySpendReq request = new ApplySpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST103)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applySpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: per_group_limit_details.bucket_type must be between 1 and 20 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to ApplySpend. group_identifier out of range - parameter.", dataProvider = "groupIdentifierFailure", dataProviderClass = DataProviders.class)
	public void ApplySpend_Group_Identifier_Out_Of_Range_Parameter(String group_identifier) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier(group_identifier)
				.build();

		ApplySpendReq request = new ApplySpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(UsersId.GO_SVC_TEST103)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applySpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: per_group_limit_details.group_identifier must be between 1 and 100 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}


