package tests.gameplaylimitservice;

import static org.junit.Assert.assertNotNull;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.gameplaylimitservice.enums.GameplayLimitEndpoints;
import tests.gameplaylimitservice.request.GetCurrentSummaryReq;
import tests.gameplaylimitservice.request.RevertReturnReq;
import tests.gameplaylimitservice.requestobjects.PerGroupLimitDetails;
import tests.gameplaylimitservice.response.GetCurrentSummaryResp;
import tests.gameplaylimitservice.response.RevertReturnResp;
import tests.gameplaylimitservice.responseobjects.GameplaySummary;

public class RevertReturnTests extends BaseClassSetup {

	@Test(description = "Make a request to revertReturn. Positive scenario.")
	public void revertReturn_Positive_Scenario() {
		String idForGetCurrentSummaryResponseId = UUID.randomUUID().toString();

		//1. Create  per group limit details for GetCurrentSummary request
		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		//2. Send GetCurrentySummary request to obtain user's current summary
		GetCurrentSummaryReq getCurrentSummaryRequest = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TESTS78)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS78)
				.build();

		GetCurrentSummaryResp gtCurrentSummaryActualResponse =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		//3. Store actual response for verification
		String getCurrentSummaryDaySpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getReturnTotal();

		BigDecimal returnAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertReturnReq request = new RevertReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.returnAmount(returnAmount)
				.userId(UsersId.GO_SVC_TESTS78)
				.build();

		RevertReturnResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertReturnSuccess);

		assertNotNull(actualResponse.getRevertReturnDatetimeUtc());

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		//8. Build the GetCurrentSummary response for a user for validation
		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		//9. Validate GetCurrentSummary response for a user
		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to RevertReturn - Week Start Day. Positive scenario.", dataProvider = "setWeekStartDaySuccess", dataProviderClass = DataProviders.class)
	public void revertReturn_Week_Start_Day_Range_Parameter_Positive_Scenario(Integer week_start_day){
		String idForGetCurrentSummaryResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq getCurrentSummaryRequest = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.weekStartDay(week_start_day)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TESTS79)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS79)
				.build();

		GetCurrentSummaryResp gtCurrentSummaryActualResponse =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getReturnTotal();

		BigDecimal returnAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertReturnReq request = new RevertReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.weekStartDay(week_start_day)
				.returnAmount(returnAmount)
				.userId(UsersId.GO_SVC_TESTS79)
				.build();

		RevertReturnResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertReturnSuccess);

		assertNotNull(actualResponse.getRevertReturnDatetimeUtc());

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to RevertReturn - Min Revert Amount - 0.01. Positive scenario.")
	public void RevertReturn_Min_Revert_Amount_0_01_Positive_Scenario(){
		String idForGetCurrentSummaryResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq getCurrentSummaryRequest = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TESTS80)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS80)
				.build();

		GetCurrentSummaryResp gtCurrentSummaryActualResponse =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getReturnTotal();

		BigDecimal returnAmount = new BigDecimal(0.01).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertReturnReq request = new RevertReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.returnAmount(returnAmount)
				.userId(UsersId.GO_SVC_TESTS80)
				.build();

		RevertReturnResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertReturnSuccess);

		assertNotNull(actualResponse.getRevertReturnDatetimeUtc());

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to RevertReturn - Local Date Time - Range parameter. Positive scenario.", dataProvider = "localDateTimeSuccess", dataProviderClass = DataProviders.class)
	public void revertReturn_Local_Date_Time_Range_Parameter_Positive_Scenario(Long local_date_utc_offset){
		String idForGetCurrentSummaryResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq getCurrentSummaryRequest = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.localDateUtcOffset(local_date_utc_offset)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TESTS82)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS82)
				.build();

		GetCurrentSummaryResp gtCurrentSummaryActualResponse =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getReturnTotal();

		BigDecimal returnAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertReturnReq request = new RevertReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.localDateUtcOffset(local_date_utc_offset)
				.returnAmount(returnAmount)
				.userId(UsersId.GO_SVC_TESTS82)
				.build();

		RevertReturnResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertReturnSuccess);

		assertNotNull(actualResponse.getRevertReturnDatetimeUtc());

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to RevertReturn - Max UserId - Range parameter. Positive scenario.", dataProvider = "UserIdSuccess", dataProviderClass = DataProviders.class)
	public void revertReturn_Max_UserId_Range_Parameter_Positive_Scenario(Integer User_Id){
		String idForGetCurrentSummaryResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq getCurrentSummaryRequest = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.userId(User_Id)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TESTS83)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS83)
				.build();

		GetCurrentSummaryResp gtCurrentSummaryActualResponse =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getReturnTotal();

		BigDecimal returnAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertReturnReq request = new RevertReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(User_Id)
				.returnAmount(returnAmount)
				.userId(UsersId.GO_SVC_TESTS83)
				.build();

		RevertReturnResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertReturnSuccess);

		assertNotNull(actualResponse.getRevertReturnDatetimeUtc());

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to RevertReturn - Local Date UTC Offset - Defaults to 0. Positive scenario.")
	public void revertReturn_Local_Date_UTC_Offset_Defaults_To_0_Positive_Scenario(){
		String idForGetCurrentSummaryResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq getCurrentSummaryRequest = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TESTS84)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS84)
				.build();

		GetCurrentSummaryResp gtCurrentSummaryActualResponse =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getReturnTotal();

		BigDecimal returnAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertReturnReq request = new RevertReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.localDateUtcOffset(null)
				.returnAmount(returnAmount)
				.userId(UsersId.GO_SVC_TESTS84)
				.build();

		RevertReturnResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertReturnSuccess);

		assertNotNull(actualResponse.getRevertReturnDatetimeUtc());

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to RevertReturn - Week Start Day - Defaults to 0. Positive scenario.")
	public void revertReturn_Week_Start_Day_Defaults_To_0_Positive_Scenario(){
		String idForGetCurrentSummaryResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq getCurrentSummaryRequest = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TESTS85)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS85)
				.build();

		GetCurrentSummaryResp gtCurrentSummaryActualResponse =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getReturnTotal();

		BigDecimal returnAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertReturnReq request = new RevertReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.localDateUtcOffset(null)
				.returnAmount(returnAmount)
				.userId(UsersId.GO_SVC_TESTS85)
				.build();

		RevertReturnResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertReturnSuccess);

		assertNotNull(actualResponse.getRevertReturnDatetimeUtc());

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).subtract(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to RevertReturn. Missing user_id parameter.")
	public void revertReturn_UserId_Missing_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertReturnReq request = new RevertReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertReturnError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: user_id is missing")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to RevertReturn. Missing return_amount parameter.")
	public void revertReturn_Return_Amount_Missing_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertReturnReq request = new RevertReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.returnAmount(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertReturnError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: return_amount must be > 0")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to RevertReturn. return_amount - 0. Negative Scenario")
	public void revertReturn_Return_Amount_0_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertReturnReq request = new RevertReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.returnAmount(new BigDecimal(0.00))
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertReturnError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: return_amount must be > 0")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to RevertReturn. local_date_utc_offset - Out Of Range. Negative Scenario", dataProvider = "localDateTimeFailure", dataProviderClass = DataProviders.class)
	public void revertReturn_Local_Date_Utc_Offset_Out_Of_Range_Parameter(Long local_date_utc_offset) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertReturnReq request = new RevertReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.localDateUtcOffset(local_date_utc_offset)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertReturnError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: local_date_utc_offset must be between -86400000000000 and 86400000000000")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to RevertReturn. Week start day out of range parameter. Negative Scenario", dataProvider = "setWeekStartDayFailure", dataProviderClass = DataProviders.class)
	public void revertReturn_Week_Start_Day_Out_Of_Range_Parameter(Integer week_start_day) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertReturnReq request = new RevertReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.weekStartDay(week_start_day)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertReturnError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: week_start_day must be between 0 and 6")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to RevertReturn. Wrong method.")
	public void revertReturn_Wrong_Method() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertReturnReq request = new RevertReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertReturnError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}
