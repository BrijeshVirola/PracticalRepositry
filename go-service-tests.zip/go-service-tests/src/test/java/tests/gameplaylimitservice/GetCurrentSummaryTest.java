package tests.gameplaylimitservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.math.BigDecimal;
import java.util.UUID;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.gameplaylimitservice.enums.GameplayLimitEndpoints;
import tests.gameplaylimitservice.request.GetCurrentSummaryReq;
import tests.gameplaylimitservice.requestobjects.PerGroupLimitDetails;
import tests.gameplaylimitservice.response.GetCurrentSummaryResp;
import tests.gameplaylimitservice.responseobjects.GameplaySummary;

public class GetCurrentSummaryTest extends BaseClassSetup {

	@Test(description = "Make a request to GetCurrentSummary. Positive scenario.")
	public void getCurrentSummary_Positive_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TESTS69)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS69)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();


		GetCurrentSummaryResp expResponse = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponse.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponse);		
	}

	@Test(description = "Make a request to GetCurrentSummary. Max Value - spend_group_user_ids parameters - Positive scenario.")
	public void getCurrentSummary_Max_Value_spend_group_user_ids_Positive_Scenario() throws InterruptedException {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.spendGroupDefaultsMax()
				.userId(UsersId.GO_SVC_TESTS70)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS70)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponse = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponse.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponse);		
	}	

	@Test(description = "Make a request to GetCurrentSummary. Local Date Time - Max Value parameter - Positive Scenario.", dataProvider = "localDateTimeSuccess", dataProviderClass = DataProviders.class)
	public void GetCurrentSummary_Local_Date_Utc_Offset_Max_Value_Positive_Scenario_Parameter(Long local_date_utc_offset) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.localDateUtcOffset(local_date_utc_offset)
				.userId(UsersId.GO_SVC_TESTS71)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS71)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponse = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponse.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponse);		
	}

	@Test(description = "Make a request to GetCurrentSummary. User Id - Max value parameter - Positive Scenario.", dataProvider = "UserIdSuccess", dataProviderClass = DataProviders.class)
	public void GetCurrentSummary_Max_Value_User_Id_Positive_Scenario_Parameter(Integer UserId) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UserId)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS69)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponse = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponse.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponse);		
	}

	@Test(description = "Make a request to GetCurrentSummary. Week Start Day - parameter - Positive Scenario.", dataProvider = "setWeekStartDaySuccess", dataProviderClass = DataProviders.class)
	public void GetCurrentSummary_Week_Start_Day_Positive_Scenario_Parameter(Integer week_start_day) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.weekStartDay(week_start_day)
				.userId(UsersId.GO_SVC_TESTS72)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS72)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponse = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponse.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponse);		
	}

	@Test(description = "Make a request to GetCurrentSummary. Group Identifier Range - parameter - Positive Scenario.", dataProvider = "groupIdentifierSuccess", dataProviderClass = DataProviders.class)
	public void GetCurrentSummary_Group_Identifier_Range_Range_Positive_Scenario_Parameter(String group_identifier) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier(group_identifier)
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TESTS73)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS73)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponse = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponse.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponse);		
	}

	@Test(description = "Make a request to GetCurrentSummary. Bucket Type Range - parameter - Positive Scenario.", dataProvider = "bucketTypeRangeSuccess", dataProviderClass = DataProviders.class)
	public void GetCurrentSummary_Bucket_Type_Range_Range_Positive_Scenario_Parameter(String bucket_type) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.bucketType(bucket_type)
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TESTS74)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS74)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType(bucket_type)
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponse = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponse.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponse);		
	}

	@Test(description = "Make a request to GetCurrentSummary. Per Group Limit Details - Optional Field - Positive Scenario.")
	public void GetCurrentSummary_Per_Group_Limit_Details_Optional_Scenario_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(UsersId.GO_SVC_TESTS75)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS75)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponse = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponse.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.build();

		assertReflectionEquals(expResponse, actualResponse);		
	}

	@Test(description = "Make a request to GetCurrentSummary. Local Date UTC Offset - Default to 0 - Positive Scenario.")
	public void GetCurrentSummary_Local_Date_UTC_Offset_Default_To_0_Positive_Scenario_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.localDateUtcOffset(null)
				.userId(UsersId.GO_SVC_TESTS76)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS76)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponse = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponse.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponse);		
	}

	@Test(description = "Make a request to GetCurrentSummary. Week Start Day - Default to 0 - Positive Scenario.")
	public void GetCurrentSummary_Week_Start_Day_Default_To_0_Positive_Scenario_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(UsersId.GO_SVC_TESTS77)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS77)
				.weekStartDay(null)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpendTotal();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpendTotal();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpendTotal();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpendTotal();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturnTotal();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturnTotal();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturnTotal();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturnTotal();

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponse = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponse.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponse);		
	}

	@Test(description = "Make a request to GetCurrentSummary. Wrong method.")
	public void getCurrentSummary_Wrong_Method() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS77)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetCurrentSummary. Missing user_id parameter.")
	public void GetCurrentSummary_UserId_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(null)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS69)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: user_id is missing")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetCurrentSummary. Local time out of range - Max parameter.")
	public void GetCurrentSummary_Local_Date_Utc_Offset_Out_Of_Range__Max_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.localDateUtcOffset(86400000000001L)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS69)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: local_date_utc_offset must be between -86400000000000 and 86400000000000")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetCurrentSummary. Local time out of range - Min parameter.")
	public void GetCurrentSummary_Local_Date_Utc_Offset_Out_Of_Range__Min_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.localDateUtcOffset(-86400000000001L)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS69)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: local_date_utc_offset must be between -86400000000000 and 86400000000000")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetCurrentSummary. Week day out of range parameter.", dataProvider = "setWeekStartDayFailure", dataProviderClass = DataProviders.class)
	public void GetCurrentSummary_Week_Day_Out_Of_Range_Parameter(Integer week_start_day) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.weekStartDay(week_start_day)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS69)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: week_start_day must be between 0 and 6")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetCurrentSummary. Missing spend_group_user_ids parameter.")
	public void GetCurrentSummary_Spend_Group_User_Ids_Missing_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: spend_group_user_ids is missing")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}	

	@Test(description = "Make a request to GetCurrentSummary. Missing per_group_limit_details_bucket_type parameter.")
	public void GetCurrentSummary_Per_Group_Limit_Details_Bucket_Type_Missing_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.bucketType(null)
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS69)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: per_group_limit_details.bucket_type must be between 1 and 20 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetCurrentSummary. Max Out of range per_group_limit_details_group_identifier parameter.")
	public void GetCurrentSummary_Per_Group_Limit_Details_Group_Identifier_Max_Out_Of_Range_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier("ka0S2o7r9d6yPx4PfM1X%HppOcn6+kCd4z%bjRz0!XGss07!U#VMXgam4A=X$D*YU4NFUtpSCzw=HuO1$MRaDg%4&2g$74h1%bgNN")
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS69)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: per_group_limit_details.group_identifier must be between 1 and 100 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetCurrentSummary. Max out of range per_group_limit_details_bucket_type parameter.")
	public void GetCurrentSummary_Per_Group_Limit_Details_Bucket_Type_Max_Out_Of_Range_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.bucketType("sessionsessionsession")
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(UsersId.GO_SVC_TESTS69)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: per_group_limit_details.bucket_type must be between 1 and 20 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
