package tests.gameplaylimitservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.gameplaylimitservice.response.ApplyReturnResp;
import tests.gameplaylimitservice.response.ApplySpendResp;
import tests.gameplaylimitservice.response.GetCurrentSummaryResp;
import tests.gameplaylimitservice.response.RevertReturnResp;
import tests.gameplaylimitservice.response.RevertSpendResp;

public enum GameplayLimitEndpoints implements ResponseEndpoints {

	getCurrentSummaryError(CustomErrorResponse.class, "GetCurrentSummary"),
	getCurrentSummarySuccess(GetCurrentSummaryResp.class, "GetCurrentSummary"),
	revertSpendSuccess(RevertSpendResp.class, "revertspend"),
	revertSpendError(CustomErrorResponse.class, "revertspend"),
	applySpendSuccess(ApplySpendResp.class, "ApplySpend"),
	applySpendError(CustomErrorResponse.class, "ApplySpend"),
	applyReturnSuccess(ApplyReturnResp.class, "ApplyReturn"),
	applyReturnError(CustomErrorResponse.class, "ApplyReturn"),
	revertReturnSuccess(RevertReturnResp.class, "RevertReturn"),
	revertReturnError(CustomErrorResponse.class, "RevertReturn");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> GameplayLimitEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
