package tests.clientnetpositionservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.util.UUID;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import domain.BaseRequest;
import tests.clientnetpositionservice.enums.ClientNetPositionEndPoints;
import tests.clientnetpositionservice.request.GetNetPositionGameConfigReq;
import tests.clientnetpositionservice.response.GetNetPositionGameConfigResp;

public class GetNetPositionGameConfigTests extends BaseClassSetup {
	
	@Test(description = "Make a request to getNetPositionGameConfig. Positive scenario.")
	public void GetNetPositionGameConfig_Positive_Scenario() {

		//String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetNetPositionGameConfigReq request = new GetNetPositionGameConfigReq.Builder()
				.defaults()
				.build();

		GetNetPositionGameConfigResp actResponse =  BaseRequest.get(request.getParameters(), ClientNetPositionEndPoints.getNetPositionGameConfigSuccess);

		GetNetPositionGameConfigResp expResponse =  new GetNetPositionGameConfigResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}
	

}
