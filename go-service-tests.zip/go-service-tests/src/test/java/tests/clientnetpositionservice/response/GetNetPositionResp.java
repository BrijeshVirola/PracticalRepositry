package tests.clientnetpositionservice.response;

public class GetNetPositionResp {

}
