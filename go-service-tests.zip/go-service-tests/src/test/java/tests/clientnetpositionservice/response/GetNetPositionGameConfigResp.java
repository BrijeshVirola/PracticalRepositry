package tests.clientnetpositionservice.response;


public class GetNetPositionGameConfigResp {
	@SuppressWarnings("unused")
	private Boolean npr;
	
	private GetNetPositionGameConfigResp(Builder builder) {
		this.npr = builder.npr;
	}

	public static class Builder {
		private Boolean npr;
		
		public Builder IsReplayerEnabled(Boolean npr) {
			this.npr = npr;
			return this;
		}
		
		public Builder defaults() {
			this.npr = true;
			return this;
		}
		
		public GetNetPositionGameConfigResp build() {
			return new GetNetPositionGameConfigResp(this);
		}
	}


}
