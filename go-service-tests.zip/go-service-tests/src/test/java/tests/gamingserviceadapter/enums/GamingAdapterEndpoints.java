package tests.gamingserviceadapter.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;

public enum GamingAdapterEndpoints implements ResponseEndpoints {

	getCurrentSummaryBACError(CustomErrorResponse.class, "GetCurrentSummary"),
	getCurrentSummaryBACSuccess(tests.gamingserviceadapter.response.GetCurrentSummaryResp.class, "GetCurrentSummary");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> GamingAdapterEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
