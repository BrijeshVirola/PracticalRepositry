package tests.gamingserviceadapter.responseobjects;

public class GameplaySummary {	
	private String bucket_type;
	private String spend_total;
	private String return_total;

	private GameplaySummary(Builder builder) {
		bucket_type = builder.bucket_type;
		spend_total = builder.spend_total;
		return_total = builder.return_total;
	}

	public String getBucketType() {
		return bucket_type;
	}

	public String getSpendTotal() {
		return spend_total;
	}

	public String getReturnTotal() {
		return return_total;
	}

	public static class Builder{
		private String bucket_type;
		private String spend_total;
		private String return_total;

		public Builder bucketType(String bucket_type){
			this.bucket_type = bucket_type;
			return this;
		}

		public Builder spendTotal(String spend_total) {
			this.spend_total = spend_total;
			return this;
		}

		public Builder returnTotal(String return_total) {
			this.return_total = return_total;
			return this;
		}

		public Builder defaults() {
			bucket_type = "";
			spend_total = "";
			return_total = "";	
			return this;
		}

		public GameplaySummary build() {
			return new GameplaySummary(this);
		}
	}
}
