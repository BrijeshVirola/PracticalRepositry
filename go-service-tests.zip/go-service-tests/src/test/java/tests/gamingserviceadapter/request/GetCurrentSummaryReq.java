package tests.gamingserviceadapter.request;

import common.enumsconstants.UsersId;

public class GetCurrentSummaryReq {

	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private Params params;

	private GetCurrentSummaryReq(Builder builder) {
		this.Id = builder.id;
		this.Method = builder.method;
		this.params = new Params(builder);
	}

	public static class Builder {

		private String id;
		private String method;
		private Integer user_id;
		private String session_id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder sessionId(String session_id) {
			this.session_id = session_id;
			return this;
		}

		public Builder defaults() {
			this.id = "Id";
			this.method = "getcurrentsummary";
			this.user_id = UsersId.GO_SVC_TESTS82;
			this.session_id = "E3C36F861FEF4CFB9414A174144C5A98000004";
			return this;
		}

		public GetCurrentSummaryReq build() {
			return new GetCurrentSummaryReq(this);
		}
	}

	private class Params {
		@SuppressWarnings("unused")
		Integer user_id;
		@SuppressWarnings("unused")
		String session_id;

		public Params(Builder builder) {
			this.user_id = builder.user_id;
			this.session_id = builder.session_id;

		}
	}
}
