package tests.playtechlivedealerfeedservice.responseobjects;

public class Event {
	
	protected String topic;
	protected String key;
	protected Message message;
	
	private Event(Builder builder) {
		topic = builder.topic;
		key = builder.key;
		message = builder.message;
	}
	
	public Message getMessage() {
		return message;
	}
	
	public String getTopic() {
		return topic;
	}
	
	public String getKey() {
		return key;
	}
	
	public static class Builder {
		
		protected String topic;
		protected String key;
		protected Message message;
		
		public Builder topic(String topic) {
			this.topic = topic;
			return this;
		}
		
		public Builder key(String key) {
			this.key = key;
			return this;
		}
		
		public Builder message(Message message) {
			this.message = message;
			return this;
		}
		
		public Builder gameInfoEvent(int gameTableId) {
			key = gameTableId + "_GameInfoEvent";
			return this;
		}
		
		public Builder dealerInfoEvent(int gameTableId) {
			key = gameTableId + "_DealerInfoEvent";
			return this;
		}
		
		public Builder onlinePlayersEvent(int gameTableId) {
			key = gameTableId + "_OnlinePlayersEvent";
			return this;
		}
		
		public Builder gameStatusEvent(int gameTableId) {
			key = gameTableId + "_GameStatusEvent";
			return this;
		}
		
		public Builder defaults() {
			topic = "livecasinogame_1";
			key = "";
			return this;
		}
		
		public Event build() {
			return new Event(this);
		}
	}
}
