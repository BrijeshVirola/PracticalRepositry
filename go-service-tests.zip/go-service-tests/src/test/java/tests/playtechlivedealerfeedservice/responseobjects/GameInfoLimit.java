package tests.playtechlivedealerfeedservice.responseobjects;

public class GameInfoLimit implements Comparable<GameInfoLimit> {
	
	private String currency;
	private Integer vip_level;
	private String min;
	private String max;
	
	@Override
	public int compareTo(GameInfoLimit gameInfoLimit) {
		return this.getCurrency().compareTo(gameInfoLimit.getCurrency());
	}
	
	public String getCurrency() {
		return currency;
	}
	
	public Integer getVipLevel() {
		return vip_level;
	}
	
	public String getMin() {
		return min;
	}
	
	public String getMax() {
		return max;
	}
	
	private GameInfoLimit(Builder builder) {
		currency = builder.currency;
		vip_level = builder.vip_level;
		min = builder.min;
		max = builder.max;
	}
	
	public static class Builder {
		
		private String currency;
		private Integer vip_level;
		private String min;
		private String max;
		
		public Builder currency(String currency) {
			this.currency = currency;
			return this;
		}
		
		public Builder vipLevel(Integer vip_level) {
			this.vip_level = vip_level;
			return this;
		}
		
		public Builder min(String min) {
			this.min = min;
			return this;
		}
		
		public Builder max(String max) {
			this.max = max;
			return this;
		}
		
		public GameInfoLimit build() {
			return new GameInfoLimit(this);
		}
	}
}
