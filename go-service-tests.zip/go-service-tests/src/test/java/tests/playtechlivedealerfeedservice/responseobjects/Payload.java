package tests.playtechlivedealerfeedservice.responseobjects;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class Payload {
	
	private List<GameInfoLimit> limits;
	private String dealer_name;
	@SuppressWarnings("unused")
	private String dealer_picture_url;
	@SuppressWarnings("unused")
	private BigInteger game_round_id;
	@SuppressWarnings("unused")
	private BigInteger game_round_start_date;
	@SuppressWarnings("unused")
	private String result;
	@SuppressWarnings("unused")
	private Integer available_seats_count;
	@SuppressWarnings("unused")
	private Map<String, Boolean> seats_availability;
	@SuppressWarnings("unused")
	private Integer player_count;
	@SuppressWarnings("unused")
	private String status;
	@SuppressWarnings("unused")
	private Integer opening_timestamp;
	
	private Payload(Builder builder) {
		limits = builder.limits;
		dealer_name = builder.dealer_name;
		dealer_picture_url = builder.dealer_picture_url;
		game_round_id = builder.game_round_id;
		game_round_start_date = builder.game_round_start_date;
		result = builder.result;
		available_seats_count = builder.available_seats_count;
		seats_availability = builder.seats_availability;
		player_count = builder.player_count;
		status = builder.status;
		opening_timestamp = builder.opening_timestamp;
	}
	
	public List<GameInfoLimit> getLimits() {
		return limits;
	}
	
	public String getDealerName() {
		return dealer_name;
	}
	
	public Integer getOpeningTimestamp() {
		return opening_timestamp;
	}

	public static class Builder {
		
		private List<GameInfoLimit> limits;
		private String dealer_name;
		private String dealer_picture_url;
		private BigInteger game_round_id;
		private BigInteger game_round_start_date;
		private String result;
		private Integer available_seats_count;
		private Map<String, Boolean> seats_availability;
		private Integer player_count;
		private String status;
		private Integer opening_timestamp;
		
		public Builder openingTimestamp(Integer opening_timestamp) {
			this.opening_timestamp = opening_timestamp;
			return this;
		}
		
		public Builder status(String status) {
			this.status = status;
			return this;
		}
		
		public Builder playerCount(Integer player_count) {
			this.player_count = player_count;
			return this;
		}
		
		public Builder seatsAvailability(Map<String, Boolean> seats_availability) {
			this.seats_availability = seats_availability;
			return this;
		}
		
		public Builder availableSeatsCount(Integer available_seats_count) {
			this.available_seats_count = available_seats_count;
			return this;
		}
		
		public Builder result(String result) {
			this.result = result;
			return this;
		}
		
		public Builder gameRoundStartDate(BigInteger game_round_start_date) {
			this.game_round_start_date = game_round_start_date;
			return this;
		}
		
		public Builder gameRoundId(BigInteger game_round_id) {
			this.game_round_id = game_round_id;
			return this;
		}
		
		public Builder limits(List<GameInfoLimit> limits) {
			this.limits = limits;
			return this;
		}
		
		public Builder defaultLimits() {
			limits = new ArrayList<>();
			limits.add(new GameInfoLimit.Builder().currency("EUR").vipLevel(1).min("500").max("200000").build());
			limits.add(new GameInfoLimit.Builder().currency("GBP").vipLevel(1).min("500").max("200000").build());
			limits.add(new GameInfoLimit.Builder().currency("USD").vipLevel(1).min("500").max("200000").build());
			Collections.sort(limits);
			return this;
		}
		
		public Builder dealerName(String dealer_name) {
			this.dealer_name = dealer_name;
			return this;
		}
		
		public Builder dealerPictureUrl(String dealer_picture_url) {
			this.dealer_picture_url = dealer_picture_url;
			return this;
		}
		
		public Payload build() {
			return new Payload(this);
		}
	}
}
