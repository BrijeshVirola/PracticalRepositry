package tests.playtechlivedealerfeedservice.request;

public class GetAllTablesReq {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private Params params;

	private GetAllTablesReq(Builder builder) {
		this.id = builder.id;
		method = builder.method;
		params = new Params();
	}
	
	public void removeParams() {
		params = null;
	}

	public static class Builder {
		
		private String id;
		private String method;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder defaults() {
			id = "defaultTestId";
			method = "getalltables";
			return this;
		}
		
		public GetAllTablesReq build() {
			return new GetAllTablesReq(this);
		}
		
	}

	private class Params {
	}
}
