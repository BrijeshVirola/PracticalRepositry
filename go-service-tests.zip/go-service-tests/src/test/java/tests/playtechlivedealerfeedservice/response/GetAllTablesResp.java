package tests.playtechlivedealerfeedservice.response;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import tests.playtechlivedealerfeedservice.responseobjects.Event;

public class GetAllTablesResp {

	@SuppressWarnings("unused")
	private String id;
	private List<Event> result;
	
	public GetAllTablesResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	/**
	 * This leaves only the list of first number of events based on the passed parameter.
	 * @param firstNumEvents
	 */
	public void leaveEventsInResp(int firstNumEvents) {
		result = result.subList(0, firstNumEvents);
	}
	
	public Integer getGameTableId(int eventIndex) {
		return result.get(eventIndex).getMessage().getGameTableId();
	}
	
	public String getDealerName(int eventIndex) {
		return result.get(eventIndex).getMessage().getDealerName();
	}
	
	public String getTopic(int eventIndex) {
		return result.get(eventIndex).getTopic();
	}
	
	public void sortGameInfoEventLimits() {
		Collections.sort(result.get(0).getMessage().getPayload().getLimits());
	}
	
	public Event getResultEvent(int event) {
		return result.get(event);
	}
	
	public static class Builder {
		
		private String id;
		private List<Event> result;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addEvent(Event event) {
			this.result.add(event);
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultTestId";
			this.result = new ArrayList<>();
			
			return this;
		}
		
		public GetAllTablesResp build() {
			return new GetAllTablesResp(this);
		}
	}
}
