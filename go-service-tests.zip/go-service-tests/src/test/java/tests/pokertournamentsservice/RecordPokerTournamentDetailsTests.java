package tests.pokertournamentsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DatabaseQueries;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.pokertournamentsservice.enums.PokerTourEndpoints;
import tests.pokertournamentsservice.request.PokerTournamentsDB;
import tests.pokertournamentsservice.request.RecordPokerTournamentDetailsReq;
public class RecordPokerTournamentDetailsTests extends BaseClassSetup{

	@Test(description = "Make a request to RecordPokerTournamentDetails. Positive scenario.")
	public void recordPokerTournamentDetails_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RecordPokerTournamentDetailsReq request = new RecordPokerTournamentDetailsReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();


		ResultOKResp actualResponse =  BaseRequest.post(request, PokerTourEndpoints.recordPokerTournamentDetailsSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	

		PokerTournamentsDB dbData = DatabaseQueries.getPokerTournamentDetails(request.getTransactionFlakeId());

		Assert.assertEquals(dbData.getTournamentId(), request.getTournamentId());
		Assert.assertEquals(dbData.getFeeAmount(), request.getFeeAmount());
		Assert.assertEquals(dbData.getDisplayAmount(), request.getDisplayAmount());
		Assert.assertEquals(dbData.getTransactionFlakeId(), request.getTransactionFlakeId()); 
		Assert.assertEquals(dbData.getFeeCurrencyId(), request.getFeeCurrencyId());
		Assert.assertEquals(dbData.getDisplayCurrencyId(), request.getDisplayCurrencyId());
	}

	@Test(description = "Make a request to recordPokerTournamentDetails. Missing fee_amount parameter.")
	public void recordPokerTournamentDetails_MissingFeeAmount_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RecordPokerTournamentDetailsReq request = new RecordPokerTournamentDetailsReq.Builder()
				.defaults()
				.feeAmount(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, PokerTourEndpoints.recordPokerTournamentDetailsError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: fee_amount")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to recordPokerTournamentDetails. Missing display_amount parameter.")
	public void recordPokerTournamentDetails_MissingDisplayAmount_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RecordPokerTournamentDetailsReq request = new RecordPokerTournamentDetailsReq.Builder()
				.defaults()
				.displayAmount(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, PokerTourEndpoints.recordPokerTournamentDetailsError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: display_amount")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to recordPokerTournamentDetails. Wrong method.")
	public void recordPokerTournamentDetails_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RecordPokerTournamentDetailsReq request = new RecordPokerTournamentDetailsReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, PokerTourEndpoints.recordPokerTournamentDetailsError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
