package tests.pokertournamentsservice.request;

public class PokerTournamentsDB {
	private String tournamentId;
	private Double feeAmount;
	private Double displayAmount;
	private Long transactionFlakeId;
	private Integer feeCurrencyId;
	private Integer displayCurrencyId;
	
	public void setTournamentId(String outputData) {
		this.tournamentId = outputData;
	}
	
	public void setFeeAmount(Double feeAmount) {
		this.feeAmount = feeAmount;
	}
	
	public void setDisplayAmount(Double displayAmount) {
		this.displayAmount = displayAmount;
	}
	
	public void setTransactionFlakeId(Long transactionFlakeId) {
		this.transactionFlakeId = transactionFlakeId;
	}
	
	public void setFeeCurrencyId(Integer feeCurrencyId) {
		this.feeCurrencyId = feeCurrencyId;
	}
	
	public void setDisplayCurrencyId(Integer displayCurrencyId) {
		this.displayCurrencyId = displayCurrencyId;
	}
	
	public String getTournamentId() {
		return tournamentId;
	}
	
	public Double getFeeAmount() {
		return feeAmount;
	}
	
	public Double getDisplayAmount() {
		return displayAmount;
	}
	
	public Long getTransactionFlakeId() {
		return transactionFlakeId;
	}
	
	public Integer getFeeCurrencyId() {
		return feeCurrencyId;
	}
	
	public Integer getDisplayCurrencyId() {
		return displayCurrencyId;
	}
}
