package tests.pokertournamentsservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.common.response.ResultOKResp;

public enum PokerTourEndpoints implements ResponseEndpoints {

	recordPokerGameSessionSuccess(ResultOKResp.class, "RecordPokerGameSession"),
	recordPokerGameSessionError(CustomErrorResponse.class, "RecordPokerGameSession"),
	recordPokerTournamentDetailsSuccess(ResultOKResp.class, "RecordPokerTournamentDetails"),
	recordPokerTournamentDetailsError(CustomErrorResponse.class, "RecordPokerTournamentDetails");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> PokerTourEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
