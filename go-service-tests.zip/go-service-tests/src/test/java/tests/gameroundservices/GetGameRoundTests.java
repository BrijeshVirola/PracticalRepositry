package tests.gameroundservices;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.util.UUID;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gameroundservices.enums.GameRoundEndpoints;
import tests.gameroundservices.request.CreateGameRoundReq;
import tests.gameroundservices.request.GetGameRoundReq;
import tests.gameroundservices.response.CreateGameRoundResp;

public class GetGameRoundTests extends BaseClassSetup {

	@Test(description = "Make a request to GetGameRound. Positive scenario.")
	public void getGameRound_Positive_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CreateGameRoundResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundSuccess); 

		String idForRequestGetGameRoundResponseId = UUID.randomUUID().toString();

		GetGameRoundReq getGameRoundrequest = new GetGameRoundReq.Builder()
				.defaults()
				.id(idForRequestGetGameRoundResponseId)
				.bet365GameRoundId(actualResponse.getBet365GameRoundId())
				.build();

		CreateGameRoundResp getGameRoundActualResponse =  BaseRequest.post(getGameRoundrequest, GameRoundEndpoints.getGameRoundSuccess);

		assertReflectionEquals(actualResponse, getGameRoundActualResponse);
	}

	@Test(description = "Make a request to GetGameRound. Wrong method.")
	public void getGameRound_Wrong_Method() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGameRoundReq request = new GetGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();   	

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.getGameRoundError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetGameRound. Missing parameter: user_id.")
	public void GetGameRound_Missing_User_Id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGameRoundReq request = new GetGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(null)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.getGameRoundError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetGameRound. Invalid parameter: invalid user_id.")
	public void GetGameRound_Invalid_User_Id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGameRoundReq request = new GetGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(100017904)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.getGameRoundError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid user_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetGameRound. Missing parameter: bet365_game_round_id.")
	public void GetGameRound_Missing_Bet365_Game_Round_Id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGameRoundReq request = new GetGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.bet365GameRoundId(null)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.getGameRoundError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1006)
				.message("Game round not found")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
