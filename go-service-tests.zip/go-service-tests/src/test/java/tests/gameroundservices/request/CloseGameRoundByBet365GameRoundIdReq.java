package tests.gameroundservices.request;

public class CloseGameRoundByBet365GameRoundIdReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Params params;

	private CloseGameRoundByBet365GameRoundIdReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params = new Params(builder);
	}

	public static class Builder {
		private String method;
		private String id;
		private Integer user_id;
		private String bet365_game_round_id;
		private String partner_end_timestamp_utc;
		private Integer closed_reason_id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder bet365GameRoundId(String bet365_game_round_id) {
			this.bet365_game_round_id = bet365_game_round_id;
			return this;
		}

		public Builder partnerEndTimestampTtc(String partner_end_timestamp_utc) {
			this.partner_end_timestamp_utc = partner_end_timestamp_utc;
			return this;
		}

		public Builder closedReasonId(Integer closed_reason_id) {
			this.closed_reason_id = closed_reason_id;
			return this;
		}
		
		public Builder defaults() {
			this.method = "closegameroundbybet365gameroundid";
			this.id = "1";
			this.user_id = 100017904;
			this.bet365_game_round_id = "490fe9a2-f564-4b05-8c74-34766637b15e";
			this.partner_end_timestamp_utc = "0001-01-01T00:00:00Z";
			this.closed_reason_id = 1;
			return this;
		}

		public CloseGameRoundByBet365GameRoundIdReq build() {
			return new CloseGameRoundByBet365GameRoundIdReq(this);
		}
	}

	public class Params {
		@SuppressWarnings("unused")
		private Integer user_id;
		@SuppressWarnings("unused")
		private String bet365_game_round_id;
		@SuppressWarnings("unused")
		private String partner_end_timestamp_utc;
		@SuppressWarnings("unused")
		private Integer closed_reason_id;
		
		public Params(Builder builder) {	
			this.user_id = builder.user_id;
			this.bet365_game_round_id = builder.bet365_game_round_id;
			this.partner_end_timestamp_utc = builder.partner_end_timestamp_utc;
			this.closed_reason_id = builder.closed_reason_id;
		}
	}
}
