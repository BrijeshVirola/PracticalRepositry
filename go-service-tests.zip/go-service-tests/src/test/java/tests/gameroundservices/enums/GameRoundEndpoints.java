package tests.gameroundservices.enums;

import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.gameroundservices.response.CloseGameRoundByBet365GameRoundIdResp;
import tests.gameroundservices.response.CreateGameRoundResp;
import tests.gameroundservices.response.InsertRngDetailsResp;
public enum GameRoundEndpoints implements ResponseEndpoints {

	getGameRoundByIdSuccess(CreateGameRoundResp.class, "GetGameRoundById"),
	getGameRoundByIdError(CustomErrorResponse.class, "GetGameRoundById"),
	insertRngDetailsSuccess(InsertRngDetailsResp.class, "InsertRngDetails"),
	insertRngDetailsError(CustomErrorResponse.class, "InsertRngDetails"),
	getGameRoundByPartnerGameRoundIdSuccess(CreateGameRoundResp.class, "GetGameRoundByPartnerGameRoundId"),
	getGameRoundByPartnerGameRoundIdError(CustomErrorResponse.class, "GetGameRoundByPartnerGameRoundId"),
	getGameRoundSuccess(CreateGameRoundResp.class, "GetGameRound"),
	getGameRoundError(CustomErrorResponse.class, "GetGameRound"),
	createGameRoundSuccess(CreateGameRoundResp.class, "CreateGameRound"),
	createGameRoundError(CustomErrorResponse.class, "CreateGameRound"),
	closeGameRoundByBet365GameRoundIdSuccess(CloseGameRoundByBet365GameRoundIdResp.class, "CloseGameRoundByBet365GameRoundId"),
	closeGameRoundByBet365GameRoundIdError(CustomErrorResponse.class, "CloseGameRoundByBet365GameRoundId");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> GameRoundEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
