package tests.balanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigInteger;
import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.FlakeGenerator;
import common.TransactionType;
import common.enumsconstants.Constants;
import domain.BaseRequest;
import tests.balanceservice.enums.BalanceEndpoints;
import tests.balanceservice.request.AdjustBalanceReq;
import tests.balanceservice.request.GetTransactionByIdReq;
import tests.balanceservice.response.AdjustBalanceResp;
import tests.balanceservice.response.GetTransactionByIdResp;

public class GetTransactionByIdTests extends BaseClassSetup {

	@Test(description = "Get Transaction By Id - Stake and Return transactions")
	public void get_TransactionById_Positive_Scenario() {

		String id = UUID.randomUUID().toString();

		//Create new stake transaction
		AdjustBalanceReq request = new AdjustBalanceReq.Builder()
				.defaults()
				.build();
		AdjustBalanceResp actResp = BaseRequest.post(request, BalanceEndpoints.adjustBalance);

		long getBet365_games_transaction_id = actResp.getResult().getBet365_games_transaction_id();

		GetTransactionByIdReq getTransactionByIdReq = new GetTransactionByIdReq(id, BigInteger.valueOf(getBet365_games_transaction_id));

		GetTransactionByIdResp actResponse = BaseRequest.post(getTransactionByIdReq, BalanceEndpoints.getTransactionById);
		GetTransactionByIdResp expResponse = new GetTransactionByIdResp(request, actResp);
		assertReflectionEquals(expResponse, actResponse);

		//Create new return transaction
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);
		request = new AdjustBalanceReq.Builder()
				.defaults()
				.transactionType(TransactionType.RETURN)
				.realAmount("2.00")
				.totalAmount("2.00")
				.flakeId(flakeId)
				.sourceBet365GamesTransactionIid(getBet365_games_transaction_id)
				.partnerTransactionId("Transaction" + flakeId)
				.build();
		actResp = BaseRequest.post(request, BalanceEndpoints.adjustBalance);

		getBet365_games_transaction_id = actResp.getResult().getBet365_games_transaction_id();

		getTransactionByIdReq = new GetTransactionByIdReq(id, BigInteger.valueOf(getBet365_games_transaction_id));

		actResponse = BaseRequest.post(getTransactionByIdReq, BalanceEndpoints.getTransactionById);
		expResponse = new GetTransactionByIdResp(request, actResp);
		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Get Transaction By Id - Transaction not found 1010")
	public void get_TransactionByI_dNo_tFound() {

		String id = UUID.randomUUID().toString();

		BigInteger notExistingId = new BigInteger("21571616161111");
		GetTransactionByIdReq getTransactionByIdReq = new GetTransactionByIdReq(id, notExistingId);

		CustomErrorResponse actError = BaseRequest.post(getTransactionByIdReq, BalanceEndpoints.getTransactionByIdError);
		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(1010)
				.message("Transaction not found")
				.id(id)
				.build();

		assertReflectionEquals(expError, actError);
	}

	@Test(description = "Get Transaction By Id - Above max value Invalid request 4")
	public void get_TransactionById_Above_Max_Value() {

		String id = UUID.randomUUID().toString();

		BigInteger notExistingId = new BigInteger("9223372036854775808");
		GetTransactionByIdReq getTransactionByIdReq = new GetTransactionByIdReq(id, notExistingId);

		CustomErrorResponse actError = BaseRequest.post(getTransactionByIdReq, BalanceEndpoints.getTransactionByIdError);
		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(4)
				.message("Couldn't unmarshal params into target type : json: cannot unmarshal number 9223372036854775808 into Go struct field getTransactionByIDRequest.id of type int64")
				.build();

		assertReflectionEquals(expError, actError);
	}

	@Test(description = "Get Transaction By Id - Missing parameter id")
	public void getTransactionById_Missing_Id() {

		String id = UUID.randomUUID().toString();

		GetTransactionByIdReq getTransactionByIdReq = new GetTransactionByIdReq(id, null);

		CustomErrorResponse actError = BaseRequest.post(getTransactionByIdReq, BalanceEndpoints.getTransactionByIdError);
		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: ID")
				.id(id)
				.build();

		assertReflectionEquals(expError, actError);
	}
}
