package tests.balanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import common.FlakeGenerator;
import common.TransactionType;
import common.enumsconstants.Constants;
import common.enumsconstants.ServiceErrors;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import domain.Transaction;
import io.restassured.response.Response;
import tests.balanceservice.enums.BalanceEndpoints;
import tests.balanceservice.request.AdjustBalanceReq;
import tests.balanceservice.request.BalanceRequest;
import tests.balanceservice.response.AdjustBalanceResp;

public class AdjustBalanceTests extends BaseClassSetup {
	@Test(dataProvider = "group1TransactionTypeAmountProvider", dataProviderClass = DataProviders.class)
	public void valid_TransferAmountAndAGroup1TransactionType_When_AdjustBalance_Then_TheExpectedTransactionIsReturned(
			TransactionType transactionType,
			int regulatedGameId,
			int cmscoreGameId,
			String realAmount,
			String totalAmount) {

		int gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;		
		long bet365TransactionId = -1;
		long bet365GamesTransactionId = -1;
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);

		Response response = BalanceRequest.adjustBalance(
				transactionType,
				bet365TransactionId,
				bet365GamesTransactionId,
				realAmount,
				totalAmount,
				gameRoundId,
				UsersId.GO_SVC_TESTS,
				regulatedGameId,
				cmscoreGameId,
				partnerId,
				providerRegionId,
				flakeId);

		Transaction result = new Transaction(response);
		Assert.assertEquals(result.game_round_id, gameRoundId);
		Assert.assertEquals(result.transaction_type_id, transactionType.getValue());
		Assert.assertEquals(result.provider_region_id, providerRegionId);
	}

	@Test(dataProvider = "group3TransactionTypeAmountProvider", dataProviderClass = DataProviders.class)
	public void valid_TransferAmountAndAGroup3TransactionType_When_AdjustBalance_Then_TheExpectedTransactionIsReturned(
			TransactionType transactionType,
			int regulatedGameIdForTest,
			int cmscoreGameId,
			String realAmount,
			String totalAmount) {

		long gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;		
		long bet365TransactionId = -1;
		long bet365GamesTransactionId = 6789;
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.id("testId")
				.flakeId(flakeId)
				.transactionType(transactionType)
				.regulatedGameId(regulatedGameIdForTest)
				.cmscoreGameId(cmscoreGameId)
				.realAmount(realAmount)
				.totalAmount(totalAmount)
				.gameRoundId(gameRoundId)
				.userId(UsersId.GO_SVC_TESTS)
				.partnerId(partnerId)
				.providerRegionId(providerRegionId)
				.bet365TransactionId(bet365TransactionId)
				.sourceBet365GamesTransactionIid(bet365GamesTransactionId)
				.build();

		AdjustBalanceResp actResp = BaseRequest.post(adjBalanceReq, BalanceEndpoints.adjustBalance);
		AdjustBalanceResp expResp = new AdjustBalanceResp(adjBalanceReq, actResp, true);

		assertReflectionEquals(expResp, actResp);
	}

	@Test(dataProvider = "group6TransactionTypeAmountProvider", dataProviderClass = DataProviders.class)
	public void valid_TransferAmountAndAGroup6TransactionType_When_AdjustBalance_Then_TheExpectedTransactionIsReturned(
			TransactionType transactionType,
			int regulatedGameIdForTest,
			int cmscoreGameId,
			String realAmount,
			String totalAmount) {

		int gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;		
		long bet365TransactionId = -1;
		long bet365GamesTransactionId = 6789;
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);


		Response response = BalanceRequest.adjustBalance(
				transactionType,
				bet365TransactionId,
				bet365GamesTransactionId,
				realAmount,
				totalAmount,
				gameRoundId,
				UsersId.GO_SVC_TESTS,
				regulatedGameIdForTest,
				cmscoreGameId,
				partnerId,
				providerRegionId,
				flakeId);

		Transaction result = new Transaction(response);
		Assert.assertEquals(result.game_round_id, gameRoundId);
		Assert.assertEquals(result.transaction_type_id, transactionType.getValue());
		Assert.assertEquals(result.provider_region_id, providerRegionId);
	}


	@Test(dataProvider = "invalidTransferAmountProvider", dataProviderClass = DataProviders.class)
	public void invalid_TransferAmount_When_AdjustBalance_Then_TheExpectedErrorIsReturned(
			TransactionType transactionType,
			int regulatedGameId,
			int cmscoreGameId,
			String realAmount,
			String totalAmount,
			int expectedErrorCode) {

		int gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;		
		long bet365TransactionId = -1;
		long bet365GamesTransactionId = -1;
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);
		String partnerTransactionId = "Transaction" + flakeId;
		int actionTypeId = 1;


		//TODO update to use builder
		AdjustBalanceReq request = new AdjustBalanceReq(
				transactionType,
				bet365TransactionId,
				bet365GamesTransactionId,
				realAmount,
				totalAmount,
				gameRoundId,
				UsersId.GO_SVC_TESTS,
				regulatedGameId,
				cmscoreGameId,
				partnerId,
				providerRegionId,
				flakeId,
				partnerTransactionId,
				actionTypeId);

		AdjustBalanceResp actResp = BaseRequest.post(request, BalanceEndpoints.adjustBalance);
		AdjustBalanceResp expResp = new AdjustBalanceResp(ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT);

		assertReflectionEquals(expResp, actResp);
	}

	@Test
	public void instant_GamesStake_When_AdjustBalance_Then_TheExpectedTransactionIsReturned() {

		int regulatedGameId = 6403;
		int cmscoreGameId = 2885;
		int gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;
		long bet365TransactionId = 8765L;
		long bet365GamesTransactionId = -1L;
		String amount = "-1";
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);
		String partnerTransactionId = "Transaction" + flakeId;
		int actionTypeId = 1;


		//TODO update to use builder
		AdjustBalanceReq request = new AdjustBalanceReq(
				TransactionType.INSTANT_GAMES_STAKE,
				bet365TransactionId,
				bet365GamesTransactionId,
				amount,
				amount,
				gameRoundId,
				UsersId.GO_SVC_TESTS,
				regulatedGameId,
				cmscoreGameId,
				partnerId,
				providerRegionId,
				flakeId,
				partnerTransactionId,
				actionTypeId);

		AdjustBalanceResp actResp = BaseRequest.post(request, BalanceEndpoints.adjustBalance);
		AdjustBalanceResp expResp = new AdjustBalanceResp(request, actResp, true);

		assertReflectionEquals(expResp, actResp);
	}

	@Test
	public void instant_GamesReturn_When_AdjustBalance_Then_TheExpectedTransactionIsReturned() {

		int regulatedGameId = 6403;
		int cmscoreGameId = 2885;
		int gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;
		long bet365TransactionId = 8765L;
		long bet365GamesTransactionId = 7654L;
		String amount = "1";
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);
		String partnerTransactionId = "Transaction" + flakeId;
		int actionTypeId = 1;


		//TODO update to use builder
		AdjustBalanceReq request = new AdjustBalanceReq(
				TransactionType.INSTANT_GAMES_RETURN,
				bet365TransactionId,
				bet365GamesTransactionId,
				amount,
				amount,
				gameRoundId,
				UsersId.GO_SVC_TESTS,
				regulatedGameId,
				cmscoreGameId,
				partnerId,
				providerRegionId,
				flakeId,
				partnerTransactionId,
				actionTypeId);

		AdjustBalanceResp actResp = BaseRequest.post(request, BalanceEndpoints.adjustBalance);
		AdjustBalanceResp expResp = new AdjustBalanceResp(request, actResp, true);

		assertReflectionEquals(expResp, actResp);
	}

	@Test
	public void gaming_PrizeAward_When_AdjustBalance_Then_TheExpectedTransactionIsReturned() {

		int regulatedGameId = 6403;
		int cmscoreGameId = 2885;
		int gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;
		long bet365TransactionId = 8765L;
		long bet365GamesTransactionId = 7654L;
		String amount = "1";
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);
		String partnerTransactionId = "Transaction" + flakeId;
		int actionTypeId = 1;


		//TODO update to use builder
		AdjustBalanceReq req = new AdjustBalanceReq(
				TransactionType.GAMING_PRIZE_AWARD,
				bet365TransactionId,
				bet365GamesTransactionId,
				amount,
				amount,
				gameRoundId,
				UsersId.GO_SVC_TESTS,
				regulatedGameId,
				cmscoreGameId,
				partnerId,
				providerRegionId,
				flakeId,
				partnerTransactionId,
				actionTypeId);


		AdjustBalanceResp actResp = BaseRequest.post(req, BalanceEndpoints.adjustBalance);
		AdjustBalanceResp expResp = new AdjustBalanceResp(req, actResp, true);

		assertReflectionEquals(expResp, actResp);
	}

	@Test
	public void void_InstantGamesStake_When_AdjustBalance_Then_TheExpectedTransactionIsReturned() {

		int regulatedGameId = 6403;
		int cmscoreGameId = 2885;
		int gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;
		long bet365TransactionId = 8765L;
		long bet365GamesTransactionId = 7654L;
		String amount = "1";
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);
		String partnerTransactionId = "Transaction" + flakeId;
		int actionTypeId = 1;


		//TODO update to use builder
		AdjustBalanceReq req = new AdjustBalanceReq(
				TransactionType.VOID_INSTANT_GAMES_STAKE,
				bet365TransactionId,
				bet365GamesTransactionId,
				amount,
				amount,
				gameRoundId,
				UsersId.GO_SVC_TESTS,
				regulatedGameId,
				cmscoreGameId,
				partnerId,
				providerRegionId,
				flakeId,
				partnerTransactionId,
				actionTypeId);

		AdjustBalanceResp actResp = BaseRequest.post(req, BalanceEndpoints.adjustBalance);
		AdjustBalanceResp expResp = new AdjustBalanceResp(req, actResp, true);

		assertReflectionEquals(expResp, actResp);
	}

	@Test(dataProvider = "group1TransactionTypeAmountProvider", dataProviderClass = DataProviders.class)
	public void GivenADuplicateTransactionWithDifferentGameRoundId_WhenAdjustBalance_ThenTheExpectedErrorIsReturned(
			TransactionType transactionType,
			int regulatedGameId,
			int cmscoreGameId,
			String realAmount,
			String totalAmount) {
		int gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;            
		long bet365TransactionId = -1;
		long bet365GamesTransactionId = -1;
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);
		String partnerTransactionId = "Transaction" + flakeId;
		int actionTypeId = 1;


		//TODO update to use builder
		AdjustBalanceReq request = new AdjustBalanceReq(
				transactionType,
				bet365TransactionId,
				bet365GamesTransactionId,
				realAmount,
				totalAmount,
				gameRoundId,
				UsersId.GO_SVC_TESTS,
				regulatedGameId,
				cmscoreGameId,
				partnerId,
				providerRegionId, 
				flakeId,
				partnerTransactionId,
				actionTypeId);
		BaseRequest.post(request, BalanceEndpoints.adjustBalance);

		//     Create a duplicate transaction
		partnerTransactionId = "DuplicateTransaction" + flakeId;
		//TODO update to use builder
		request = new AdjustBalanceReq(
				transactionType,
				bet365TransactionId,
				bet365GamesTransactionId,
				realAmount,
				totalAmount,
				gameRoundId + 1,
				UsersId.GO_SVC_TESTS,
				regulatedGameId,
				cmscoreGameId,
				partnerId,
				providerRegionId, 
				flakeId,
				partnerTransactionId,
				actionTypeId);


		AdjustBalanceResp actualResponse = BaseRequest.post(request, BalanceEndpoints.adjustBalance);
		AdjustBalanceResp expectedResponse = new AdjustBalanceResp(ServiceErrors.Balance.TRANSACTION_FAILED_FOR_UNKNOWN_REASON);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(dataProvider = "group1TransactionTypeAmountProvider", dataProviderClass = DataProviders.class)
	public void GivenADuplicateTransactionWithDifferentPartnerTransactionId_WhenAdjustBalance_ThenTheExpectedErrorIsReturned(
			TransactionType transactionType,
			int regulatedGameId,
			int cmscoreGameId,
			String realAmount,
			String totalAmount) {
		int gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;            
		long bet365TransactionId = -1;
		long bet365GamesTransactionId = -1;
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);
		String partnerTransactionId = "Transaction" + flakeId;
		int actionTypeId = 1;


		//TODO update to use builder
		AdjustBalanceReq request = new AdjustBalanceReq(
				transactionType,
				bet365TransactionId,
				bet365GamesTransactionId,
				realAmount,
				totalAmount,
				gameRoundId,
				UsersId.GO_SVC_TESTS,
				regulatedGameId,
				cmscoreGameId,
				partnerId,
				providerRegionId, 
				flakeId,
				partnerTransactionId,
				actionTypeId);
		BaseRequest.post(request, BalanceEndpoints.adjustBalance);

		//     Create a duplicate transaction
		partnerTransactionId = "DuplicateTransaction" + flakeId;
		//TODO update to use builder
		request = new AdjustBalanceReq(
				transactionType,
				bet365TransactionId,
				bet365GamesTransactionId,
				realAmount,
				totalAmount,
				gameRoundId,
				UsersId.GO_SVC_TESTS,
				regulatedGameId,
				cmscoreGameId,
				partnerId,
				providerRegionId, 
				flakeId,
				partnerTransactionId,
				actionTypeId);


		AdjustBalanceResp actualResponse = BaseRequest.post(request, BalanceEndpoints.adjustBalance);
		AdjustBalanceResp expectedResponse = new AdjustBalanceResp(ServiceErrors.Balance.TRANSACTION_FAILED_FOR_UNKNOWN_REASON);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test()
	public void GivenInsufficientFunds_WhenAdjustBalance_ThenTheExpectedErrorIsReturned() {
		TransactionType transactionType = TransactionType.STAKE;
		int gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;            
		long bet365TransactionId = -1;
		long bet365GamesTransactionId = -1;
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);
		String partnerTransactionId = "Transaction" + flakeId;
		String realAmount = "0.0";
		String totalAmount = "-10000";
		int regulatedGameId = 6403;
		int cmscoreGameId = 2885;
		int actionTypeId = 1;


		//TODO update to use builder
		AdjustBalanceReq request = new AdjustBalanceReq(
				transactionType,
				bet365TransactionId,
				bet365GamesTransactionId,
				realAmount,
				totalAmount,
				gameRoundId,
				UsersId.GO_SVC_TESTS25,
				regulatedGameId,
				cmscoreGameId,
				partnerId,
				providerRegionId, 
				flakeId,
				partnerTransactionId,
				actionTypeId);
		AdjustBalanceResp actualResponse = BaseRequest.post(request, BalanceEndpoints.adjustBalance);

		AdjustBalanceResp expectedResponse = new AdjustBalanceResp(ServiceErrors.Balance.INSUFFICIENT_FUNDS);
		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test()
	public void GivenAnInvalidTransactionType_WhenAdjustBalance_ThenTheExpectedErrorIsReturned() {

		TransactionType transactionType = TransactionType.INVALID;
		int gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;            
		long bet365TransactionId = -1;
		long bet365GamesTransactionId = -1;
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);
		String partnerTransactionId = "Transaction" + flakeId;
		String realAmount = "0.0";
		String totalAmount = "-1";
		int regulatedGameId = 6403;
		int cmscoreGameId = 2885;
		int actionTypeId = 1;


		//TODO update to use builder
		AdjustBalanceReq request = new AdjustBalanceReq(
				transactionType,
				bet365TransactionId,
				bet365GamesTransactionId,
				realAmount,
				totalAmount,
				gameRoundId,
				UsersId.GO_SVC_TESTS,
				regulatedGameId,
				cmscoreGameId,
				partnerId,
				providerRegionId, 
				flakeId,
				partnerTransactionId,
				actionTypeId);
		AdjustBalanceResp actualResponse = BaseRequest.post(request, BalanceEndpoints.adjustBalance);

		AdjustBalanceResp expectedResponse = new AdjustBalanceResp(ServiceErrors.Balance.INVALID_TRANSFER_TYPE);
		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test()
	public void GivenANegativeActionTypeId_WhenAdjustBalance_ThenTheExpectedErrorIsReturned() {

		TransactionType transactionType = TransactionType.STAKE;
		int gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;            
		long bet365TransactionId = -1;
		long bet365GamesTransactionId = -1;
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);
		String partnerTransactionId = "A123456789B123456789C123456789D123456789E123456789F123456789G123456789H123456789I123456789J123456789K" + flakeId;
		String realAmount = "0.0";
		String totalAmount = "-1";
		int regulatedGameId = 6403;
		int cmscoreGameId = 2885;
		int actionTypeId = -1;


		//TODO update to use builder
		AdjustBalanceReq request = new AdjustBalanceReq(
				transactionType,
				bet365TransactionId,
				bet365GamesTransactionId,
				realAmount,
				totalAmount,
				gameRoundId,
				UsersId.GO_SVC_TESTS,
				regulatedGameId,
				cmscoreGameId,
				partnerId,
				providerRegionId, 
				flakeId,
				partnerTransactionId,
				actionTypeId);
		AdjustBalanceResp actualResponse = BaseRequest.post(request, BalanceEndpoints.adjustBalance);

		AdjustBalanceResp expectedResponse = new AdjustBalanceResp(ServiceErrors.Balance.INVALID_PARAMETER_VALUE);
		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Adjust balance with missing transaction type id")
	public void Given_Missing_TransactionTypeId_WhenAdjustBalance_ThenTheExpectedErrorIsReturned() {

		String id = UUID.randomUUID().toString();

		TransactionType transactionType = TransactionType.MISSING;
		long gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;            
		long bet365TransactionId = -1;
		long bet365GamesTransactionId = -1;
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);
		String partnerTransactionId = "A123456789B123456789C123456789D123456789E123456789F123456789G123456789H123456789I123456789J123456789K" + flakeId;
		String realAmount = "0.0";
		String totalAmount = "-1";
		int regulatedGameId = 6403;
		int cmscoreGameId = 2885;
		int actionTypeId = -1;

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.id(id)
				.actionTypeId(actionTypeId)
				.partnerTransactionId(partnerTransactionId)
				.flakeId(flakeId)
				.transactionType(transactionType)
				.regulatedGameId(regulatedGameId)
				.cmscoreGameId(cmscoreGameId)
				.realAmount(realAmount)
				.totalAmount(totalAmount)
				.gameRoundId(gameRoundId)
				.userId(UsersId.GO_SVC_TESTS)
				.partnerId(partnerId)
				.providerRegionId(providerRegionId)
				.bet365TransactionId(bet365TransactionId)
				.sourceBet365GamesTransactionIid(bet365GamesTransactionId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(adjBalanceReq, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: transaction_type_id")
				.id(id)
				.build();
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(dataProvider = "externalBalanceChangeNegativeAmounts", dataProviderClass = DataProviders.class)
	public void adjustBalance_External_Balance_Change_Negative_Amounts(
			int productid,
			TransactionType transactionType,
			int regulatedGameIdForTest,
			int cmscoreGameId,
			String realAmount,
			String totalAmount,
			String externalBonusAmount,
			String externalRingFencedAmount) {

		long gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;		
		long bet365TransactionId = -1;
		long bet365GamesTransactionId = 6789;
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.id("testId")
				.flakeId(flakeId)
				.transactionType(transactionType)
				.regulatedGameId(regulatedGameIdForTest)
				.cmscoreGameId(cmscoreGameId)
				.realAmount(realAmount)
				.totalAmount(totalAmount)
				.gameRoundId(gameRoundId)
				.userId(UsersId.GO_SVC_TESTS28)
				.partnerId(partnerId)
				.providerRegionId(providerRegionId)
				.bet365TransactionId(bet365TransactionId)
				.sourceBet365GamesTransactionIid(bet365GamesTransactionId)
				.externalBalanceChange(externalBonusAmount, externalRingFencedAmount)
				.productId(productid)
				.build();

		AdjustBalanceResp actResp = BaseRequest.post(adjBalanceReq, BalanceEndpoints.adjustBalance);
		AdjustBalanceResp expResp = new AdjustBalanceResp(adjBalanceReq, actResp, true);

		assertReflectionEquals(expResp, actResp);
	}

	@Test(dataProvider = "externalBalanceChangePositiveAmounts", dataProviderClass = DataProviders.class)
	public void adjustBalance_External_Balance_Change_Positive_Amounts(
			int productid,
			TransactionType transactionType,
			int regulatedGameIdForTest,
			int cmscoreGameId,
			String realAmount,
			String totalAmount,
			String externalBonusAmount,
			String externalRingFencedAmount) {

		long gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;		
		long bet365TransactionId = -1;
		long bet365GamesTransactionId = 6789;
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.id("testId")
				.flakeId(flakeId)
				.transactionType(transactionType)
				.regulatedGameId(regulatedGameIdForTest)
				.cmscoreGameId(cmscoreGameId)
				.realAmount(realAmount)
				.totalAmount(totalAmount)
				.gameRoundId(gameRoundId)
				.userId(UsersId.GO_SVC_TESTS29)
				.partnerId(partnerId)
				.providerRegionId(providerRegionId)
				.bet365TransactionId(bet365TransactionId)
				.sourceBet365GamesTransactionIid(bet365GamesTransactionId)
				.externalBalanceChange(externalBonusAmount, externalRingFencedAmount)
				.productId(productid)
				.build();

		AdjustBalanceResp actResp = BaseRequest.post(adjBalanceReq, BalanceEndpoints.adjustBalance);
		AdjustBalanceResp expResp = new AdjustBalanceResp(adjBalanceReq, actResp, true);

		assertReflectionEquals(expResp, actResp);
	}


	@Test(dataProvider = "externalBalanceChangeErrors", dataProviderClass = DataProviders.class)
	public void adjustBalance_External_Balance_Change_Errors(
			int productid,
			TransactionType transactionType,
			int regulatedGameIdForTest,
			int cmscoreGameId,
			String realAmount,
			String totalAmount,
			String externalBonusAmount,
			String externalRingFencedAmount,
			String errorMessage,
			int errorCode) {

		long gameRoundId = 1234;
		int partnerId = 4567;
		int providerRegionId = 5678;		
		long bet365TransactionId = -1;
		long bet365GamesTransactionId = 6789;
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.id("testId")
				.flakeId(flakeId)
				.transactionType(transactionType)
				.regulatedGameId(regulatedGameIdForTest)
				.cmscoreGameId(cmscoreGameId)
				.realAmount(realAmount)
				.totalAmount(totalAmount)
				.actionTypeId(0)
				.gameRoundId(gameRoundId)
				.userId(UsersId.GO_SVC_TESTS29)
				.partnerId(partnerId)
				.providerRegionId(providerRegionId)
				.bet365TransactionId(bet365TransactionId)
				.sourceBet365GamesTransactionIid(bet365GamesTransactionId)
				.externalBalanceChange(externalBonusAmount, externalRingFencedAmount)
				.productId(productid)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(adjBalanceReq, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(errorCode)
				.message(errorMessage)
				.id("testId")
				.build();
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(dataProvider = "externalBalanceChangeMissingParameters", dataProviderClass = DataProviders.class)
	public void adjustBalance_External_Balance_Change_Missing_Parameters(
			int productid,
			TransactionType transactionType,
			String parameter,
			String errorMessage,
			int errorCode) {

		String realAmount = "0";
		String totalAmount = "0";
		String externalBonusAmount = "0";
		String externalRingFencedAmount = "0";
		int regulatedGameIdForTest = 6403;
		int cmscoreGameId = 2885;
		Long gameRoundId = 1234L;
		Integer partnerId = parameter.equals("partner_id") ? null : 4567;
		Integer providerRegionId = parameter.equals("provider_region_id") ? null : 5678;		
		long bet365TransactionId = -1;
		long bet365GamesTransactionId = 6789;
		Long flakeId = parameter.equals("flake_id") ? null : FlakeGenerator.nextId(Constants.nodeId);
		String partnerTimestampUtc = parameter.equals("partner_timestamp_utc") ? null : "2020-09-22T14:54:33.86Z";
		String partnerTransactionId = parameter.equals("partner_transaction_id") ? null : "Transaction9712523662586467";
		Integer userId = parameter.equals("user_id") ? null : UsersId.GO_SVC_TESTS30;
		String token = parameter.equals("token") ? null : "private token";
		Integer currencyId = parameter.equals("currency_id") ? null : 1;
		Integer actionTypeId = parameter.equals("action_type_id") ? -1 : 1;

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.id("testId")
				.flakeId(flakeId)
				.actionTypeId(actionTypeId)
				.partnerTimestampUtc(partnerTimestampUtc)
				.partnerTransactionId(partnerTransactionId)
				.transactionType(transactionType)
				.regulatedGameId(regulatedGameIdForTest)
				.cmscoreGameId(cmscoreGameId)
				.realAmount(realAmount)
				.totalAmount(totalAmount)
				.gameRoundId(gameRoundId)
				.userId(userId)
				.currencyId(currencyId)
				.token(token)
				.partnerId(partnerId)
				.providerRegionId(providerRegionId)
				.bet365TransactionId(bet365TransactionId)
				.sourceBet365GamesTransactionIid(bet365GamesTransactionId)
				.externalBalanceChange(externalBonusAmount, externalRingFencedAmount)
				.productId(productid)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(adjBalanceReq, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(errorCode)
				.message(errorMessage)
				.id("testId")
				.build();
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(dataProvider = "handleGbtPositiveAmounts", dataProviderClass = DataProviders.class)
	public void adjustBalance_Gbt_Positive_Amounts(
			int productid,
			TransactionType transactionType) {

		String realAmount = "-0.1";
		String totalAmount = "0.1";

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.id("testId")
				.transactionType(transactionType)
				.realAmount(realAmount)
				.totalAmount(totalAmount)
				.productId(productid)
				.userBonusId(1234)
				.userId(UsersId.GO_SVC_TESTS31)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(adjBalanceReq, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1006)
				.message("Stakes must use a negative total_amount")
				.id("testId")
				.build();
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(dataProvider = "handleGbtNegativeAmounts", dataProviderClass = DataProviders.class)
	public void adjustBalance_Gbt_Negative_Amounts(
			int productid,
			TransactionType transactionType, int code, String errorMessage) {

		String realAmount = "-0.1";
		String totalAmount = "0.1";
		long bet365GamesTransactionId = 6789;

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.id("testId")
				.transactionType(transactionType)
				.realAmount(realAmount)
				.totalAmount(totalAmount)
				.productId(productid)
				.userBonusId(1234)
				.sourceBet365GamesTransactionIid(bet365GamesTransactionId)
				.userId(UsersId.GO_SVC_TESTS31)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(adjBalanceReq, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(code)
				.message(errorMessage)
				.id("testId")
				.build();
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(dataProvider = "handleGbtMissingParameters", dataProviderClass = DataProviders.class)
	public void adjustBalance_Gbt_Missing_Parameters(
			int productid,
			TransactionType transactionType,
			String parameter,
			String errorMessage,
			int errorCode) {

		String realAmount = "0";
		String totalAmount = "0";
		Integer regulatedGameIdForTest = parameter.equals("regulated_game_id") ? null : 6403;
		int cmscoreGameId = 2885;
		Long gameRoundId = parameter.equals("game_round_id") ? null : 123l;
		Integer partnerId = parameter.equals("partner_id") ? null : 4567;
		Integer providerRegionId = parameter.equals("provider_region_id") ? null : 5678;		
		long bet365TransactionId = -1;
		long bet365GamesTransactionId = 6789;
		Long flakeId = parameter.equals("flake_id") ? null : FlakeGenerator.nextId(Constants.nodeId);
		String partnerTimestampUtc = parameter.equals("partner_timestamp_utc") ? null : "2020-09-22T14:54:33.86Z";
		String partnerTransactionId = parameter.equals("partner_transaction_id") ? null : "Transaction9712523662586467";
		Integer userId = parameter.equals("user_id") ? null : UsersId.GO_SVC_TESTS31;
		String token = parameter.equals("token") ? null : "private token";
		Integer currencyId = parameter.equals("currency_id") ? null : 1;
		Integer actionTypeId = parameter.equals("action_type_id") ? -1 : 1;

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.id("testId")
				.flakeId(flakeId)
				.actionTypeId(actionTypeId)
				.partnerTimestampUtc(partnerTimestampUtc)
				.partnerTransactionId(partnerTransactionId)
				.transactionType(transactionType)
				.regulatedGameId(regulatedGameIdForTest)
				.gameRoundId(gameRoundId)
				.cmscoreGameId(cmscoreGameId)
				.realAmount(realAmount)
				.totalAmount(totalAmount)
				.userId(userId)
				.currencyId(currencyId)
				.token(token)
				.userBonusId(1234)
				.partnerId(partnerId)
				.providerRegionId(providerRegionId)
				.bet365TransactionId(bet365TransactionId)
				.sourceBet365GamesTransactionIid(bet365GamesTransactionId)
				.productId(productid)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(adjBalanceReq, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(errorCode)
				.message(errorMessage)
				.id("testId")
				.build();
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(dataProvider = "handleStakeMissingParameters", dataProviderClass = DataProviders.class)
	public void adjustBalance_Handle_Stake_Missing_Parameters(
			int productid,
			TransactionType transactionType,
			String parameter,
			String errorMessage,
			int errorCode) {

		String realAmount = "0";
		String totalAmount = "0";
		Long flakeId = parameter.equals("flake_id") ? 0 : FlakeGenerator.nextId(Constants.nodeId);
		Long gameRoundId = parameter.equals("game_round_id") ? 0 : 123l;
		String partnerTimestampUtc = parameter.equals("partner_timestamp_utc") ? null : "2020-09-22T14:54:33.86Z";
		String partnerTransactionId = parameter.equals("partner_transaction_id") ? "" : "Transaction9712523662586467";
		Integer userId = parameter.equals("user_id") ? null : UsersId.GO_SVC_TESTS31;
		Integer regulatedGameIdForTest = parameter.equals("regulated_game_id") ? 0 : 6403;
		Integer cmscoreGameId = parameter.equals("cmscore_game_id") ? 0 :  2885;
		Integer partnerId = parameter.equals("partner_id") ? 0 : 4567;
		Integer providerRegionId = parameter.equals("provider_region_id") ? 0 : 5678;		
		String token = parameter.equals("token") ? null : "private token";
		Integer currencyId = parameter.equals("currency_id") ? 0 : 1;
		long bet365TransactionId = -1;
		Integer actionTypeId = 1;

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.id("testId")
				.flakeId(flakeId)
				.actionTypeId(actionTypeId)
				.partnerTimestampUtc(partnerTimestampUtc)
				.partnerTransactionId(partnerTransactionId)
				.transactionType(transactionType)
				.regulatedGameId(regulatedGameIdForTest)
				.gameRoundId(gameRoundId)
				.cmscoreGameId(cmscoreGameId)
				.realAmount(realAmount)
				.totalAmount(totalAmount)
				.userId(userId)
				.currencyId(currencyId)
				.token(token)
				.partnerId(partnerId)
				.providerRegionId(providerRegionId)
				.bet365TransactionId(bet365TransactionId)
				.productId(productid)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(adjBalanceReq, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(errorCode)
				.message(errorMessage)
				.id("testId")
				.build();
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(dataProvider = "handleInstantGamesStakeMissingParameters", dataProviderClass = DataProviders.class)
	public void adjustBalance_Handle_Instant_Games_Stake_Missing_Parameters(
			int productid,
			TransactionType transactionType,
			String parameter,
			String errorMessage,
			int errorCode) {

		String realAmount = "0";
		String totalAmount = "0";
		Long flakeId = parameter.equals("flake_id") ? 0 : FlakeGenerator.nextId(Constants.nodeId);
		Long gameRoundId = parameter.equals("game_round_id") ? 0 : 123l;
		String partnerTimestampUtc = parameter.equals("partner_timestamp_utc") ? null : "2020-09-22T14:54:33.86Z";
		String partnerTransactionId = parameter.equals("partner_transaction_id") ? "" : "Transaction9712523662586467";
		Integer userId = parameter.equals("user_id") ? 0 : UsersId.GO_SVC_TESTS31;
		Integer regulatedGameIdForTest = parameter.equals("regulated_game_id") ? 0 : 6403;
		Integer cmscoreGameId = 2885;
		Integer partnerId = parameter.equals("partner_id") ? 0 : 4567;
		Integer providerRegionId = parameter.equals("provider_region_id") ? 0 : 5678;		
		String token = parameter.equals("token") ? null : "private token";
		Integer currencyId = parameter.equals("currency_id") ? 0 : 1;
		long bet365TransactionId = -1;
		Integer actionTypeId = parameter.equals("action_type_id") ? -1 : 1;

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.id("testId")
				.flakeId(flakeId)
				.actionTypeId(actionTypeId)
				.partnerTimestampUtc(partnerTimestampUtc)
				.partnerTransactionId(partnerTransactionId)
				.transactionType(transactionType)
				.regulatedGameId(regulatedGameIdForTest)
				.gameRoundId(gameRoundId)
				.cmscoreGameId(cmscoreGameId)
				.realAmount(realAmount)
				.totalAmount(totalAmount)
				.userId(userId)
				.currencyId(currencyId)
				.token(token)
				.partnerId(partnerId)
				.providerRegionId(providerRegionId)
				.bet365TransactionId(bet365TransactionId)
				.productId(productid)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(adjBalanceReq, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(errorCode)
				.message(errorMessage)
				.id("testId")
				.build();
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(dataProvider = "handleReturnMissingParameters", dataProviderClass = DataProviders.class)
	public void adjustBalance_Handle_Return_And_Instant_Games_Return_Missing_Parameters(
			int productid,
			TransactionType transactionType,
			String parameter,
			String errorMessage,
			int errorCode) {

		String realAmount = "0";
		String totalAmount = "0";
		Long flakeId = parameter.equals("flake_id") ? 0 : FlakeGenerator.nextId(Constants.nodeId);
		Long gameRoundId = parameter.equals("game_round_id") ? 0 : 123l;
		String partnerTimestampUtc = parameter.equals("partner_timestamp_utc") ? null : "2020-09-22T14:54:33.86Z";
		String partnerTransactionId = parameter.equals("partner_transaction_id") ? "" : "Transaction9712523662586467";
		Integer userId = parameter.equals("user_id") ? 0 : UsersId.GO_SVC_TESTS31;
		Integer regulatedGameIdForTest = parameter.equals("regulated_game_id") ? 0 : 6403;
		Integer cmscoreGameId = 2885;
		Integer partnerId = parameter.equals("partner_id") ? 0 : 4567;
		Integer providerRegionId = parameter.equals("provider_region_id") ? 0 : 5678;		
		String token = parameter.equals("token") ? null : "private token";
		Integer currencyId = parameter.equals("currency_id") ? 0 : 1;
		long bet365TransactionId = -1;
		Long sourceBet365GamesTransactionIid = parameter.equals("source_bet365_games_transaction_id") ? null : 6789l;
		Integer actionTypeId = parameter.equals("action_type_id") ? -1 : 1;

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.id("testId")
				.flakeId(flakeId)
				.actionTypeId(actionTypeId)
				.partnerTimestampUtc(partnerTimestampUtc)
				.partnerTransactionId(partnerTransactionId)
				.transactionType(transactionType)
				.regulatedGameId(regulatedGameIdForTest)
				.gameRoundId(gameRoundId)
				.cmscoreGameId(cmscoreGameId)
				.realAmount(realAmount)
				.totalAmount(totalAmount)
				.userId(userId)
				.currencyId(currencyId)
				.token(token)
				.partnerId(partnerId)
				.providerRegionId(providerRegionId)
				.bet365TransactionId(bet365TransactionId)
				.sourceBet365GamesTransactionIid(sourceBet365GamesTransactionIid)
				.productId(productid)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(adjBalanceReq, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(errorCode)
				.message(errorMessage)
				.id("testId")
				.build();
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(dataProvider = "handlePrizeMissingParameters", dataProviderClass = DataProviders.class)
	public void adjustBalance_Handle_Prize_Missing_Parameters(
			int productid,
			TransactionType transactionType,
			String parameter,
			String errorMessage,
			int errorCode) {

		String realAmount = "0";
		String totalAmount = "0";
		Long flakeId = parameter.equals("flake_id") ? 0 : FlakeGenerator.nextId(Constants.nodeId);
		Long gameRoundId = 123l;
		String partnerTimestampUtc = parameter.equals("partner_timestamp_utc") ? null : "2020-09-22T14:54:33.86Z";
		String partnerTransactionId = parameter.equals("partner_transaction_id") ? "" : "Transaction9712523662586467";
		Integer userId = parameter.equals("user_id") ? 0 : UsersId.GO_SVC_TESTS31;
		Integer regulatedGameIdForTest = 6403;
		Integer cmscoreGameId = 2885;
		Integer partnerId = parameter.equals("partner_id") ? 0 : 4567;
		Integer providerRegionId = parameter.equals("provider_region_id") ? 0 : 5678;		
		String token = parameter.equals("token") ? null : "private token";
		Integer currencyId = parameter.equals("currency_id") ? 0 : 1;
		long bet365TransactionId = -1;
		Long sourceBet365GamesTransactionIid = 6789l;
		Integer actionTypeId = 1;

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.id("testId")
				.flakeId(flakeId)
				.actionTypeId(actionTypeId)
				.partnerTimestampUtc(partnerTimestampUtc)
				.partnerTransactionId(partnerTransactionId)
				.transactionType(transactionType)
				.regulatedGameId(regulatedGameIdForTest)
				.gameRoundId(gameRoundId)
				.cmscoreGameId(cmscoreGameId)
				.realAmount(realAmount)
				.totalAmount(totalAmount)
				.userId(userId)
				.currencyId(currencyId)
				.token(token)
				.partnerId(partnerId)
				.providerRegionId(providerRegionId)
				.bet365TransactionId(bet365TransactionId)
				.sourceBet365GamesTransactionIid(sourceBet365GamesTransactionIid)
				.productId(productid)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(adjBalanceReq, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(errorCode)
				.message(errorMessage)
				.id("testId")
				.build();
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(dataProvider = "handleVoidStake", dataProviderClass = DataProviders.class)
	public void adjustBalance_Handle_Void_Stake_And_Intant_Games_Void_Stake_Missing_Parameters(
			int productid,
			TransactionType transactionType,
			String parameter,
			String errorMessage,
			int errorCode) {

		String realAmount = "0";
		String totalAmount = "0";
		Long flakeId = parameter.equals("flake_id") ? 0 : FlakeGenerator.nextId(Constants.nodeId);
		Long gameRoundId = parameter.equals("game_round_id") ? 0 : 123l;
		String partnerTimestampUtc = parameter.equals("partner_timestamp_utc") ? null : "2020-09-22T14:54:33.86Z";
		String partnerTransactionId = parameter.equals("partner_transaction_id") ? "" : "Transaction9712523662586467";
		Integer userId = parameter.equals("user_id") ? null : UsersId.GO_SVC_TESTS31;
		Integer regulatedGameIdForTest = parameter.equals("regulated_game_id") ? 0 : 6403;
		Integer cmscoreGameId = 2885;
		Integer partnerId = parameter.equals("partner_id") ? 0 : 4567;
		Integer providerRegionId = parameter.equals("provider_region_id") ? 0 : 5678;		
		String token = parameter.equals("token") ? null : "private token";
		Integer currencyId = parameter.equals("currency_id") ? 0 : 1;
		long bet365TransactionId = -1;
		Integer actionTypeId = parameter.equals("action_type_id") ? -1 : 1;

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.id("testId")
				.flakeId(flakeId)
				.actionTypeId(actionTypeId)
				.partnerTimestampUtc(partnerTimestampUtc)
				.partnerTransactionId(partnerTransactionId)
				.transactionType(transactionType)
				.regulatedGameId(regulatedGameIdForTest)
				.gameRoundId(gameRoundId)
				.cmscoreGameId(cmscoreGameId)
				.realAmount(realAmount)
				.totalAmount(totalAmount)
				.userId(userId)
				.currencyId(currencyId)
				.token(token)
				.partnerId(partnerId)
				.providerRegionId(providerRegionId)
				.bet365TransactionId(bet365TransactionId)
				.productId(productid)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(adjBalanceReq, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(errorCode)
				.message(errorMessage)
				.id("testId")
				.build();
		assertReflectionEquals(expectedError, actualError);
	}
}
