package tests.balanceservice.request;

import com.google.gson.JsonObject;

import common.TransactionType;
import domain.BaseRequest;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BalanceRequest extends BaseRequest {
	
	private static ThreadLocal<Long> flakeIdPerThread = new ThreadLocal<Long>();

	/**
	 * 
	 * @param baseUri
	 * @param transactionType
	 * @param bet365TransactionId
	 * @param source_bet365_games_transaction_id this equal to bet365GamesTransactionId from the previous transaction,
	 *  e.g if stake is made first, then bet365GamesTransactionId of the stake is used as source_bet365_games_transaction_id for the return
	 * @param realAmount
	 * @param totalAmount
	 * @param gameRoundId
	 * @param userId
	 * @param regulatedGameId
	 * @param cmscoreGameId
	 * @param partnerId
	 * @param providerRegionId
	 * @return
	 */
	public static Response adjustBalance(
			TransactionType transactionType,
			long bet365TransactionId,
			long source_bet365_games_transaction_id,
			String realAmount,
			String totalAmount,
			int gameRoundId,
			int userId,
			int regulatedGameId,
			int cmscoreGameId,
			int partnerId,
			int providerRegionId,
			long flakeId) {
		
		JsonObject body = getBodyForAdjustBalance(transactionType,
				bet365TransactionId,
				source_bet365_games_transaction_id,
				realAmount,
				totalAmount,
				gameRoundId,
				userId,
				regulatedGameId,
				cmscoreGameId,
				partnerId,
				providerRegionId,
				flakeId);

		RequestSpecification request = createRequest(body);
		
		Response response = request.post("adjustbalance");
		response.then().statusCode(200);

		return response;
	}
	
	private static JsonObject getBodyForAdjustBalance(TransactionType transactionType,
			long bet365TransactionId,
			long source_bet365_games_transaction_id,
			String realAmount,
			String totalAmount,
			int gameRoundId,
			int userId,
			int regulatedGameId,
			int cmscoreGameId,
			int partnerId,
			int providerRegionId,
			long flakeId) {

		String method = "adjustbalance";

		JsonObject body = new JsonObject();
		body.addProperty("method", method);
		body.addProperty("id", "1");

		JsonObject params = new JsonObject();

		int currencyId = 1;
		String bonusGameType = "G";
		setFlakeId(flakeId);
		String partnerTransactionId = "Transaction" + flakeId;
		String partnerTimestampUtc = "2020-09-22T14:54:33.8606455Z";
		int productId = 4;
		String token = "private token";
		int actionTypeId = 1;

		params.addProperty("bet365_transaction_id", bet365TransactionId);
		params.addProperty("source_bet365_games_transaction_id", source_bet365_games_transaction_id);
		params.addProperty("real_amount", realAmount);
		params.addProperty("total_amount", totalAmount);
		params.addProperty("currency_id", currencyId);
		params.addProperty("bonus_game_type", bonusGameType);
		params.addProperty("user_id", userId);
		params.addProperty("cmscore_game_id", cmscoreGameId);
		params.addProperty("regulated_game_id", regulatedGameId);
		params.addProperty("transaction_type_id", transactionType.getValue());
		params.addProperty("partner_transaction_id", partnerTransactionId);
		params.addProperty("partner_timestamp_utc", partnerTimestampUtc);
		params.addProperty("partner_id", partnerId);
		params.addProperty("game_round_id", gameRoundId);
		params.addProperty("product_id", productId);
		params.addProperty("token", token);
		params.addProperty("action_type_id", actionTypeId);
		params.addProperty("provider_region_id", providerRegionId);
		params.addProperty("user_bonus_id", 0);
		params.addProperty("flake_id", flakeId);
		params.addProperty("allow_ring_fenced", true);
		params.addProperty("allow_bonus", true);
		params.addProperty("ring_fenced_amount", 0);
		params.addProperty("bonus_amount", 0);
		
		params = formatParams(params, transactionType);

		body.add("params", params);

		return body;
	}
	
	/**
	 * Based on transactionType remove not used Json properties.
	 * @param params
	 * @param transactionType
	 * @return
	 */
	public static JsonObject formatParams(JsonObject params, TransactionType transactionType) {
		
		switch (transactionType) {
		case INSTANT_GAMES_STAKE:
			params.remove("source_bet365_games_transaction_id");
			params.remove("ring_fenced_amount");
			params.remove("bonus_amount");
			params.remove("user_bonus_id");
			break;
			
		case INSTANT_GAMES_RETURN:	
		case GAMING_PRIZE_AWARD:
			params.remove("user_bonus_id");
			params.remove("bet365_transaction_id");
			break;
			
		case STAKE:
		case FREE_SPIN_STAKE:
		case GOLDEN_CHIP_STAKE:
		case GAMING_STAKE:
		case TRANSFER_TO_PLAYTECH_BONUS_CASINO:
		case TRANSFER_TO_BINGO_BONUS_BALANCE:
		case TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO:
		case POKER_BUY_CHIPS:
		case POKER_TOURNAMENT_ENTRY:
		case POKER_TOURNAMENT_REBUY:
		case TRANSFER_TO_PLAYTECH_BONUS_POKER:
			params.remove("source_bet365_games_transaction_id");
			params.remove("ring_fenced_amount");
			params.remove("bonus_amount");
			break;
			
		case VOID_STAKE:
		case VOID_GAMING_STAKE:
		case VOID_POKER_BUY_CHIPS:
		case VOID_POKER_TOURNAMENT_ENTRY:
		case VOID_POKER_TOURNAMENT_REBUY:
		case VOID_INSTANT_GAMES_STAKE:
			params.remove("bet365_transaction_id");
			params.remove("allow_ring_fenced");
			params.remove("allow_bonus");
			break;
			
		case RETURN:
		case FREE_SPIN_RETURN:
		case GOLDEN_CHIP_RETURN:
		case GAMING_RETURN:
		case TRANSFER_FROM_BINGO_BONUS_BALANCE:
		case TRANSFER_FROM_PLAYTECH_BONUS_CASINO:
		case TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO:
		case POKER_SELL_CHIPS:
		case POKER_TOURNAMENT_WIN:
		case TRANSFER_FROM_PLAYTECH_BONUS_POKER:
			params.remove("bet365_transaction_id");
			break;
		default:
			break;
		}
		
		return params;
	}
	
	public static Long getFlakeId() {
		return flakeIdPerThread.get();
	}

	public static void setFlakeId(Long flakeIdPerThread) {
		BalanceRequest.flakeIdPerThread.set(flakeIdPerThread);
	}
}
