package tests.balanceservice.request;

import java.util.HashMap;
import java.util.Map;

import common.enumsconstants.Constants;
import common.enumsconstants.UsersId;
import common.FlakeGenerator;
import common.TransactionType;
import domain.ErrorResponse;

public class AdjustBalanceReq extends ErrorResponse {
	
	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method = "AdjustBalance";
	private Map<String, Object> Params = new HashMap<>();
	
	private AdjustBalanceReq(Builder builder) {
	
		BalanceRequest.setFlakeId(builder.flakeId);
		
		this.Id = builder.id;
		Params.put("bet365_transaction_id", builder.bet365TransactionId);
		Params.put("source_bet365_games_transaction_id", builder.sourceBet365GamesTransactionId);
		Params.put("real_amount", builder.realAmount);
		Params.put("total_amount", builder.totalAmount);
		Params.put("currency_id", builder.currencyId);
		Params.put("bonus_game_type", "G");
		Params.put("user_id", builder.userId);
		Params.put("cmscore_game_id", builder.cmscoreGameId);
		Params.put("regulated_game_id", builder.regulatedGameId);
		Params.put("transaction_type_id", builder.transactionType.getValue());
		Params.put("partner_transaction_id", builder.partnerTransactionId);
		Params.put("partner_timestamp_utc", builder.partnerTimestampUtc);
		Params.put("partner_id", builder.partnerId);
		Params.put("game_round_id", builder.gameRoundId);
		Params.put("product_id", builder.productId);
		Params.put("token", builder.token);
		Params.put("action_type_id", builder.actionTypeId);
		Params.put("provider_region_id", builder.providerRegionId);
		Params.put("user_bonus_id", builder.userBonusId);
		Params.put("flake_id", builder.flakeId);
		Params.put("allow_ring_fenced", true);
		Params.put("allow_bonus", true);
		Params.put("ring_fenced_amount", "0");
		Params.put("bonus_amount", "0");
		Params.put("external_balance_change", builder.externalBalanceChange);
		
		Params = formatParams(Params, builder.transactionType);
	
	}
	
	//TODO remove this constructor once the builder is in full use
	public AdjustBalanceReq(TransactionType transactionType,
			long bet365TransactionId,
			long source_bet365_games_transaction_id,
			String realAmount,
			String totalAmount,
			long gameRoundId,
			int userId,
			int regulatedGameId,
			int cmscoreGameId,
			int partnerId,
			int providerRegionId,
			long flakeId,
			String partnerTransactionId,
			int actionTypeId) {
		
		BalanceRequest.setFlakeId(flakeId);
		String partnerTimestampUtc = "2020-09-22T14:54:33.86Z";
		int productId = 4;
		String token = "private token";
		
		Params.put("bet365_transaction_id", bet365TransactionId);
		Params.put("source_bet365_games_transaction_id", source_bet365_games_transaction_id);
		Params.put("real_amount", realAmount);
		Params.put("total_amount", totalAmount);
		Params.put("currency_id", 1);
		Params.put("bonus_game_type", "G");
		Params.put("user_id", userId);
		Params.put("cmscore_game_id", cmscoreGameId);
		Params.put("regulated_game_id", regulatedGameId);
		Params.put("transaction_type_id", transactionType.getValue());
		Params.put("partner_transaction_id", partnerTransactionId);
		Params.put("partner_timestamp_utc", partnerTimestampUtc);
		Params.put("partner_id", partnerId);
		Params.put("game_round_id", gameRoundId);
		Params.put("product_id", productId);
		Params.put("token", token);
		Params.put("action_type_id", actionTypeId);
		Params.put("provider_region_id", providerRegionId);
		Params.put("user_bonus_id", 0);
		Params.put("flake_id", flakeId);
		Params.put("allow_ring_fenced", true);
		Params.put("allow_bonus", true);
		Params.put("ring_fenced_amount", "0");
		Params.put("bonus_amount", "0");
		
		Params = formatParams(Params, transactionType);
		
	}
	
	public Map<String, Object> getParams() {
		return Params;
	}
	
	/**
	 * Based on transactionType remove not used Json properties.
	 * @param params
	 * @param transactionType
	 * @return
	 */
	public static Map<String, Object> formatParams(Map<String, Object> Params, TransactionType transactionType) {
		
		switch (transactionType) {
		case INSTANT_GAMES_STAKE:
			Params.remove("source_bet365_games_transaction_id");
			Params.remove("ring_fenced_amount");
			Params.remove("bonus_amount");
			Params.remove("user_bonus_id");
			break;
			
		case INSTANT_GAMES_RETURN:	
		case GAMING_PRIZE_AWARD:
			Params.remove("user_bonus_id");
			Params.remove("bet365_transaction_id");
			break;
			
		case STAKE:
		case FREE_SPIN_STAKE:
		case GOLDEN_CHIP_STAKE:
		case GAMING_STAKE:
		case TRANSFER_TO_PLAYTECH_BONUS_CASINO:
		case TRANSFER_TO_BINGO_BONUS_BALANCE:
		case TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO:
		case POKER_BUY_CHIPS:
		case POKER_TOURNAMENT_ENTRY:
		case POKER_TOURNAMENT_REBUY:
		case TRANSFER_TO_PLAYTECH_BONUS_POKER:
			Params.remove("source_bet365_games_transaction_id");
			Params.remove("ring_fenced_amount");
			Params.remove("bonus_amount");
			break;
			
		case VOID_STAKE:
		case VOID_GAMING_STAKE:
		case VOID_POKER_BUY_CHIPS:
		case VOID_POKER_TOURNAMENT_ENTRY:
		case VOID_POKER_TOURNAMENT_REBUY:
		case VOID_INSTANT_GAMES_STAKE:
			Params.remove("bet365_transaction_id");
			Params.remove("allow_ring_fenced");
			Params.remove("allow_bonus");
			break;
			
		case RETURN:
		case FREE_SPIN_RETURN:
		case GOLDEN_CHIP_RETURN:
		case GAMING_RETURN:
		case TRANSFER_FROM_BINGO_BONUS_BALANCE:
		case TRANSFER_FROM_PLAYTECH_BONUS_CASINO:
		case TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO:
		case POKER_SELL_CHIPS:
		case POKER_TOURNAMENT_WIN:
		case TRANSFER_FROM_PLAYTECH_BONUS_POKER:
			Params.remove("bet365_transaction_id");
			break;
		default:
			break;
		}
		
		return Params;
	}

	public static class Builder{
		
		private String id;
		private String token;
		private TransactionType transactionType;
		private long bet365TransactionId;
		private Long sourceBet365GamesTransactionId;
		private String realAmount;
		private String totalAmount;
		private Long gameRoundId;
		private Integer userId;
		private Integer regulatedGameId;
		private Integer cmscoreGameId;
		private Integer partnerId;
		private Integer currencyId;
		private Integer providerRegionId;
		private int productId;
		private Long flakeId;
		private String partnerTransactionId;
		private String partnerTimestampUtc;
		private Integer actionTypeId;
		private Integer userBonusId;
		private Map<String, Object> externalBalanceChange;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder transactionType(TransactionType transactionType) {
			this.transactionType = transactionType;
			return this;
		}

		public Builder bet365TransactionId(long bet365TransactionId) {
			this.bet365TransactionId = bet365TransactionId;
			return this;
		}

		public Builder sourceBet365GamesTransactionIid(Long sourceBet365GamesTransactionId) {
			this.sourceBet365GamesTransactionId = sourceBet365GamesTransactionId;
			return this;
			
		}

		public Builder realAmount(String realAmount) {
			this.realAmount = realAmount;
			return this;
		}

		public Builder totalAmount(String totalAmount) {
			this.totalAmount = totalAmount;
			return this;
		}

		public Builder gameRoundId(Long gameRoundId) {
			this.gameRoundId = gameRoundId;
			return this;
		}

		public Builder userId(Integer userId) {
			this.userId = userId;
			return this;
		}

		public Builder regulatedGameId(Integer regulatedGameId) {
			this.regulatedGameId = regulatedGameId;
			return this;
		}
		
		public Builder token(String token) {
			this.token = token;
			return this;
		}
		
		public Builder currencyId(Integer currencyId) {
			this.currencyId = currencyId;
			return this;
		}

		public Builder cmscoreGameId(Integer cmscoreGameId) {
			this.cmscoreGameId = cmscoreGameId;
			return this;
		}

		public Builder partnerId(Integer partnerId) {
			this.partnerId = partnerId;
			return this;
		}

		public Builder providerRegionId(Integer providerRegionId) {
			this.providerRegionId = providerRegionId;
			return this;
		}

		public Builder flakeId(Long flakeId) {
			this.flakeId = flakeId;
			return this;
		}

		public Builder partnerTransactionId(String partnerTransactionId) {
			this.partnerTransactionId = partnerTransactionId;
			return this;
		}
		
		public Builder partnerTimestampUtc(String partnerTimestampUtc) {
			this.partnerTimestampUtc = partnerTimestampUtc;
			return this;
		}

		public Builder actionTypeId(Integer actionTypeId) {
			this.actionTypeId = actionTypeId;
			return this;
		}
		
		public Builder userBonusId(Integer userBonusId) {
			this.userBonusId = userBonusId;
			return this;
		}
		
		public Builder externalBalanceChange(String ring_fenced_amount, String bonus_amount) {
			externalBalanceChange = new HashMap<>();
			externalBalanceChange.put("ring_fenced_amount", ring_fenced_amount);
			externalBalanceChange.put("bonus_amount", bonus_amount);
			return this;
		}
		
		public Builder productId(int productId) {
			this.productId = productId;
			return this;
		}

		public Builder defaults() {
			
			this.id = "defaultId";
			this.transactionType = TransactionType.STAKE;
			this.bet365TransactionId = 0;
			this.sourceBet365GamesTransactionId = 0l;
			this.realAmount = "0.00";
			this.totalAmount = "-1.00";
			this.gameRoundId = 1L;
			this.regulatedGameId = 6403;
			this.token = "private token";
			this.currencyId = 1;
			this.partnerId = 100;
			this.cmscoreGameId = 2885;
			this.flakeId = FlakeGenerator.nextId(Constants.nodeId);
			this.partnerTransactionId = "Transaction" + flakeId;
			this.actionTypeId = 1;
			this.providerRegionId = 20;
			this.userId = UsersId.GO_SVC_TESTS03;
			this.productId = 4;
			this.partnerTimestampUtc = "2020-09-22T14:54:33.86Z";
			this.userBonusId = 0;
			
			return this;			
		}

		public AdjustBalanceReq build() {
			return new AdjustBalanceReq(this);
		}
	}
}
