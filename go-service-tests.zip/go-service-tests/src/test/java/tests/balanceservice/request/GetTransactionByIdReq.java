package tests.balanceservice.request;

import java.math.BigInteger;

public class GetTransactionByIdReq {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String Method = "GetTransactionById";
	@SuppressWarnings("unused")
	private GetTransactionByIdParams Params;
	
	/**
	 * 
	 * @param getBet365_games_transaction_id when insert record(new transaction is created) this id is populated in the response,
	 * so it can be get from there
	 */
	public GetTransactionByIdReq(String id, BigInteger getBet365_games_transaction_id) {
		this.id = id;
		Params = new GetTransactionByIdParams(getBet365_games_transaction_id);
	}
	
	class GetTransactionByIdParams {
		
		@SuppressWarnings("unused")
		private BigInteger id;
		
		public GetTransactionByIdParams(BigInteger getBet365_games_transaction_id) {
			this.id = getBet365_games_transaction_id;
		}
	}
}
