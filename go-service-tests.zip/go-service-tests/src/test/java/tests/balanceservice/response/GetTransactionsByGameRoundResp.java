package tests.balanceservice.response;

import java.util.ArrayList;
import java.util.List;

import common.enumsconstants.Errors;
import domain.ErrorResponse;
import tests.balanceservice.request.AdjustBalanceReq;
import tests.balanceservice.responseobjects.TransactionResult;

public class GetTransactionsByGameRoundResp extends ErrorResponse {
	
	@SuppressWarnings("unused")
	private String id;
	private List<TransactionResult> result;
	
	public GetTransactionsByGameRoundResp(String id, AdjustBalanceReq request, TransactionRecord transaction) {
		this.id = id;
		result = new ArrayList<TransactionResult>();
		result.add(new TransactionResult(request, transaction));
	}
	
	public GetTransactionsByGameRoundResp (Errors error) {
		super(error);
	}
}
