package tests.balanceservice.response;

import common.enumsconstants.Errors;
import tests.balanceservice.request.AdjustBalanceReq;

public class GetTransactionByIdResp extends TransactionRecord {
	
	public GetTransactionByIdResp(AdjustBalanceReq request, TransactionRecord transaction) {
		super(request, transaction);
	}
	
	public GetTransactionByIdResp(Errors error) {
		super(error);
	}

}
