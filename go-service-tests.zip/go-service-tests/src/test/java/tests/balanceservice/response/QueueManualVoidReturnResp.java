package tests.balanceservice.response;

import common.enumsconstants.Errors;
import domain.ErrorResponse;

//TODO this use of inheritance looks suspicious. The implied IsA relationship would mean that the response is always an error
public class QueueManualVoidReturnResp extends ErrorResponse {
	
	@SuppressWarnings("unused")
	private String id = null;
	@SuppressWarnings("unused")
	private String result;
	
	public QueueManualVoidReturnResp(String result) {
		this.result = result;
	}
	
	public QueueManualVoidReturnResp(Errors error) {
		super(error);
	}
}
