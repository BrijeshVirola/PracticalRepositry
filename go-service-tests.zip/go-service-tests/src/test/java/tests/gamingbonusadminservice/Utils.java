package tests.gamingbonusadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import common.DatabaseQueries;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusadminservice.enums.GamingBonusAdminEndpoints;
import tests.gamingbonusadminservice.request.SpecificBonusCancelByAdminCommandReq;

public class Utils {
	
	public static void cancelLastBonusIdOfUser(Integer userId) {
		
		Integer userBonusId1 =  DatabaseQueries.getLastUserBonusIdFromUserBonus(userId);
		if (userBonusId1 != null) {
			SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
					.defaults()
					.userId(userId)
					.userBonusId(userBonusId1)
					.build();
			
			ResultOKResp actCancelBonusResp =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandSuccess);

			ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
					.defaults()
					.build();
			assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
		}
	}
}
