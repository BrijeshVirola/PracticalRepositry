package tests.gamingbonusadminservice.request;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class GetUsersForBonusActionsCommandReq {
	
	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private Params params;

	private GetUsersForBonusActionsCommandReq(Builder builder) {
		Id = builder.Id;
		Method = builder.Method;
		params = new Params(builder);
	}
	
	public static class Builder {
		
		private String Id;
		private String Method;
		private BigInteger bonustemplate_id;
		private Integer version_id;
		private Boolean include_offered;
		private List<Integer> user_ids;
		private Boolean remove_all;
		
		public Builder defaults() {
			Id = "defaultTestId";
			Method = "getusersforbonusactionscommand";
			bonustemplate_id = new BigInteger("418");
			version_id = 850;
			include_offered = true;
			user_ids = new ArrayList<>();
			remove_all = false;
			return this;
		}
		
		public Builder id(String id) {
			this.Id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.Method = method;
			return this;
		}
		
		public Builder bonusTemplateId(BigInteger bonustemplateId) {
			this.bonustemplate_id = bonustemplateId;
			return this;
		}
		
		public Builder versionId(Integer version_id) {
			this.version_id = version_id;
			return this;
		}
		
		public Builder includeOffered(Boolean includeOffered) {
			this.include_offered = includeOffered;
			return this;
		}
		
		public Builder addUserId(Integer userId) {
			user_ids.add(userId);
			return this;
		}
		
		public Builder removeAll(Boolean removeAll) {
			this.remove_all = removeAll;
			return this;
		}
		
		public GetUsersForBonusActionsCommandReq build() {
			return new GetUsersForBonusActionsCommandReq(this);
		}
	}
	
	private class Params {
		
		@SuppressWarnings("unused")
		private BigInteger bonustemplate_id;
		@SuppressWarnings("unused")
		private Integer version_id;
		@SuppressWarnings("unused")
		private Boolean include_offered;
		@SuppressWarnings("unused")
		private List<Integer> user_ids;
		@SuppressWarnings("unused")
		private Boolean remove_all;
		
		public Params(Builder builder) {
			bonustemplate_id = builder.bonustemplate_id;
			version_id = builder.version_id;
			include_offered = builder.include_offered;
			user_ids = builder.user_ids;
			remove_all = builder.remove_all;
		}
	}
}
