package tests.gamingbonusadminservice.request;

public class ActiveDepositBonusQueryCommandReq {
	
	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private Params params;

	private ActiveDepositBonusQueryCommandReq(Builder builder) {
		Id = builder.Id;
		Method = builder.Method;
		params = new Params(builder);
	}
	
	public static class Builder {
		
		private String Id;
		private String Method;
		private Integer user_id;
		private Integer product_id;
		
		public Builder defaults() {
			Id = "defaultTestId";
			Method = "activedepositbonusquerycommand";
			user_id = 1;
			product_id = 1;
			return this;
		}
		
		public Builder id(String id) {
			this.Id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.Method = method;
			return this;
		}
		
		public Builder userId(Integer userId) {
			user_id = userId;
			return this;
		}
		
		public Builder productId(Integer productId) {
			product_id = productId;
			return this;
		}
		
		public ActiveDepositBonusQueryCommandReq build() {
			return new ActiveDepositBonusQueryCommandReq(this);
		}
	}
	
	private class Params {
		
		@SuppressWarnings("unused")
		private Integer user_id;
		@SuppressWarnings("unused")
		private Integer product_id;
		
		public Params(Builder builder) {
			user_id = builder.user_id;
			product_id = builder.product_id;
		}
	}
}
