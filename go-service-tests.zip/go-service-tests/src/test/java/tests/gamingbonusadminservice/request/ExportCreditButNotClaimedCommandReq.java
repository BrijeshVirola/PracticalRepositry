package tests.gamingbonusadminservice.request;

import java.math.BigInteger;

public class ExportCreditButNotClaimedCommandReq {
	
	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private Params params;

	private ExportCreditButNotClaimedCommandReq(Builder builder) {
		Id = builder.Id;
		Method = builder.Method;
		params = new Params(builder);
	}
	
	public void removeParams() {
		params = null;
	}
	
	public static class Builder {
		
		private String Id;
		private String Method;
		private BigInteger bonustemplate_id;
		
		public Builder defaults() {
			Id = "defaultTestId";
			Method = "exportcreditbutnotclaimedcommand";
			bonustemplate_id = new BigInteger("1");
			return this;
		}
		
		public Builder id(String id) {
			this.Id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.Method = method;
			return this;
		}
		
		public Builder bonustemplateId(BigInteger bonustemplateId) {
			bonustemplate_id = bonustemplateId;
			return this;
		}
		
		public ExportCreditButNotClaimedCommandReq build() {
			return new ExportCreditButNotClaimedCommandReq(this);
		}
	}
	
	private class Params {
		
		@SuppressWarnings("unused")
		private BigInteger bonustemplate_id;
		
		public Params(Builder builder) {
			bonustemplate_id = builder.bonustemplate_id;
		}
	}
}
