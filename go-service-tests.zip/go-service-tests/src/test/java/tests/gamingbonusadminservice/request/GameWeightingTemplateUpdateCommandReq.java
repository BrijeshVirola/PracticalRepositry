package tests.gamingbonusadminservice.request;

import java.util.ArrayList;
import java.util.List;

import tests.gamingbonusadminservice.requestobjects.GameWeight;

public class GameWeightingTemplateUpdateCommandReq {
	
	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private Params params;

	private GameWeightingTemplateUpdateCommandReq(Builder builder) {
		Id = builder.Id;
		Method = builder.Method;
		params = new Params(builder);
	}
	
	public static class Builder {
		
		private String Id;
		private String Method;
		private Integer gameweighttemplate_id;
		private List<GameWeight> gameWeights;
		
		public Builder defaults() {
			Id = "defaultTestId";
			Method = "gameweightingtemplateupdatecommand";
			gameweighttemplate_id = 15;
			gameWeights = new ArrayList<>();
			return this;
		}
		
		public Builder id(String id) {
			this.Id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.Method = method;
			return this;
		}
		
		public Builder gameweighttemplateId(Integer gameweighttemplateId) {
			gameweighttemplate_id = gameweighttemplateId;
			return this;
		}
		
		public Builder addGameWeight(GameWeight gameWeight) {
			gameWeights.add(gameWeight);
			return this;
		}
		
		public GameWeightingTemplateUpdateCommandReq build() {
			return new GameWeightingTemplateUpdateCommandReq(this);
		}
	}
	
	private class Params {
		
		@SuppressWarnings("unused")
		private Integer gameweighttemplate_id;
		@SuppressWarnings("unused")
		private List<GameWeight> gameWeights;
		
		public Params(Builder builder) {
			gameweighttemplate_id = builder.gameweighttemplate_id;
			gameWeights = builder.gameWeights;
		}
	}
}
