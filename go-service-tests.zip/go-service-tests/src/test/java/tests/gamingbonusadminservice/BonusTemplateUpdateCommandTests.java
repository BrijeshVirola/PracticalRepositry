package tests.gamingbonusadminservice;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import common.DatabaseQueries;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusadminservice.enums.GamingBonusAdminEndpoints;
import tests.gamingbonusadminservice.request.BonusTemplateUpdateCommandReq;
import tests.gamingbonusadminservice.requestobjects.BonusAffiliateCodes;
import tests.gamingbonusadminservice.requestobjects.BonusCurrencyAmount;

public class BonusTemplateUpdateCommandTests extends BaseClassSetup {

	BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
			.defaults()
			.maximumBonus(1300)
			.build();

	//TODO: To complete the case when stored procedure is created in https://jira/browse/PRJSAK-2269
	//Need to delete the bonusTemapleVersionId row from BonusTemplateVersion table every time
	@Test(description = "Make a request to bonusTemplateUpdateCommand. Cash bonus positive Scenario.")
	public void bonusTemplateUpdateCommand_Cash_Bonus_Positive_Scenario() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Boolean bonusTemplateVersionIdExists;
		Integer bonusTemapleVersionId = 34;

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(481)
				.historyId(1)
				.versionId(bonusTemapleVersionId)
				.templateVersion(2)
				.addRegulatedZone(1)
				.addCountry(234)
				.addCountry(222)
				.addCountry(244)
				.addCountry(197)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.build();

		ResultOKResp actualResponse = BaseRequest.post(
				request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);

		bonusTemplateVersionIdExists = DatabaseQueries.verifyIfExistsBonusTemplateVersionId(bonusTemapleVersionId);

		assertThat("Check if bonusTemplateVersionId exists:", bonusTemplateVersionIdExists, equalTo(true));
	}

	//TODO: To complete the case when stored procedure is created in https://jira/browse/PRJSAK-2269
	//Need to delete the bonusTemapleVersionId row from BonusTemplateVersion table every time
	@Test(description = "Make a request to bonusTemplateUpdateCommand. Pre-wager positive Scenario.")
	public void bonusTemplateUpdateCommand_Pre_Wager_Positive_Scenario() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Boolean bonusTemplateVersionIdExists;
		Integer bonusTemapleVersionId = 36;

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.id(id)
				.gameweighttemplateId(1)
				.wageringRequirementMultiplier(1)
				.bonustemplateId(484)
				.bonustypeId(5)
				.expiryInHours(720)
				.versionId(bonusTemapleVersionId)
				.templateVersion(2)
				.addRegulatedZone(1)
				.historyId(3)
				.addCountry(234)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.build();

		ResultOKResp actualResponse = BaseRequest.post(
				request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);

		bonusTemplateVersionIdExists = DatabaseQueries.verifyIfExistsBonusTemplateVersionId(bonusTemapleVersionId);

		assertThat("Check if bonusTemplateVersionId exists:", bonusTemplateVersionIdExists, equalTo(true));
	}

	//TODO: To complete the case when stored procedure is created in https://jira/browse/PRJSAK-2269
	//Need to delete the bonusTemapleVersionId row from BonusTemplateVersion table every time
	@Test(description = "Make a request to bonusTemplateUpdateCommand. After-wager positive Scenario.")
	public void bonusTemplateUpdateCommand_After_Wager_Positive_Scenario() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Boolean bonusTemplateVersionIdExists;
		Integer bonusTemapleVersionId = 37;

		BonusCurrencyAmount currencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.maximumBonus(1300)
				.minimumToQualify(10)
				.subsequentBonusAmount(20)
				.wageringRequirement(50)
				.build();

		BonusAffiliateCodes bonusAffiliateCodes = new BonusAffiliateCodes.Builder()
				.defaults()
				.addAffiliateCode("test")
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustypeId(4)
				.gameweighttemplateId(1)
				.wageringRequirementMultiplier(1)
				.bonusAffiliateCodes(bonusAffiliateCodes)
				.bonustemplateId(485)
				.showinaccountmanager(true)
				.depositMatched(true)
				.useRingfencing(true)
				.newPlayerBonus(true)
				.isAffiliateBonus(true)
				.hasSubsequentBonus(true)
				.triggerSubsequentBonusOnComplete(true)
				.subsequentBonusTemplateId(467)
				.subsequentBonusType(4)
				.expiryInHours(720)
				.versionId(bonusTemapleVersionId)
				.templateVersion(2)
				.addRegulatedZone(1)
				.historyId(4)
				.addCountry(234)
				.addBonusCurrencyamount(currencyAmount)
				.build();

		ResultOKResp actualResponse = BaseRequest.post(
				request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);

		bonusTemplateVersionIdExists = DatabaseQueries.verifyIfExistsBonusTemplateVersionId(bonusTemapleVersionId);

		assertThat("Check if bonusTemplateVersionId exists:", bonusTemplateVersionIdExists, equalTo(true));
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Bonus template id missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusTemplateUpdateCommand_Bonus_Template_Id_Missing(String bonusTemplateIdProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer bonusTemplateId = bonusTemplateIdProvider.equals("null") ? null : Integer.parseInt(bonusTemplateIdProvider);


		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustemplateId(bonusTemplateId)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: bonustemplate_id")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Bonus type id missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusTemplateUpdateCommand_Bonus_Type_Id_Missing(String bonusTypeIdProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer bonusTypeId = bonusTypeIdProvider.equals("null") ? null : Integer.parseInt(bonusTypeIdProvider);


		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(bonusTypeId)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: bonustype_id")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Product id missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusTemplateUpdateCommand_Product_Id_Missing(String productIdProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer productId = productIdProvider.equals("null") ? null : Integer.parseInt(productIdProvider);


		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.productId(productId)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: product_id")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Created date missing.")
	public void bonusTemplateUpdateCommand_Created_Date_Missing() throws InterruptedException {

		String id = UUID.randomUUID().toString();


		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.createdDate(null)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing parameter: createddate")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Start date missing.")
	public void bonusTemplateUpdateCommand_Start_Date_Missing() throws InterruptedException {

		String id = UUID.randomUUID().toString();


		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.startDate(null)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing parameter: startdate")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Regulated zones missing.")
	public void bonusTemplateUpdateCommand_Regulated_Zones_Missing() throws InterruptedException {

		String id = UUID.randomUUID().toString();


		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.id(id)
				.addCountry(234)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing parameter: regulatedzones")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Regulated zones invalid.")
	public void bonusTemplateUpdateCommand_Regulated_Zones_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.id(id)
				.addCountry(234)
				.addRegulatedZone(0)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Invalid regulatedzones")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Countries missing.")
	public void bonusTemplateUpdateCommand_Countries_Missing() throws InterruptedException {

		String id = UUID.randomUUID().toString();


		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.id(id)
				.addRegulatedZone(1)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing parameter: countries")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Countries invalid.")
	public void bonusTemplateUpdateCommand_Countries_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();


		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.id(id)
				.addRegulatedZone(1)
				.addCountry(0)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Invalid countries")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Template name missing.",
			dataProviderClass = DataProviders.class, dataProvider = "nullEmptyString")
	public void bonusTemplateUpdateCommand_Missing_Template_Name(String templateNameProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		String templateName = templateNameProvider.equals("null") ? null : templateNameProvider;

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.id(id)
				.addRegulatedZone(1)
				.addCountry(234)
				.templateName(templateName)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing parameter: templatename")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. History created date missing.")
	public void bonusTemplateUpdateCommand_Missing_History_Created_Date() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.id(id)
				.addRegulatedZone(1)
				.addCountry(234)
				.historyCreatedDate(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing parameter: history_createddate")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. End date missing.")
	public void bonusTemplateUpdateCommand_End_Date_Missing() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.addRegulatedZone(1)
				.addCountry(234)
				.endDate(null)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing parameter: enddate")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Priority invalid.")
	public void bonusTemplateUpdateCommand_Priority_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.addRegulatedZone(1)
				.addCountry(234)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.priority(-1)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Invalid parameter: priority")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Start date after end date.")
	public void bonusTemplateUpdateCommand_Start_Date_After_End_Date() throws InterruptedException {

		String id = UUID.randomUUID().toString();


		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.addRegulatedZone(1)
				.addCountry(234)
				.startDate("2021-11-30T10:50:00.000Z")
				.endDate("2021-11-29T10:50:00.000Z")
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Invalid parameter: enddate. Startdate after enddate")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. gameweighttemplate_id missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusTemplateUpdateCommand_Gameweighttemplate_id_Missing_Invalid(String gameweighttemplateIdProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer gameweighttemplateId = gameweighttemplateIdProvider.equals("null") ? null : Integer.parseInt(gameweighttemplateIdProvider);

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(gameweighttemplateId)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: gameweighttemplate_id")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Invalid newplayerbonus.")
	public void bonusTemplateUpdateCommand_NewPlayerBonus_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.newPlayerBonus(true)
				.addRegulatedZone(1)
				.addCountry(234)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Invalid newplayerbonus: Not valid for cash bonuses")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Template version missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusTemplateUpdateCommand_Template_Version_Missing_Invalid(String templateVersionProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer templateVersion = templateVersionProvider.equals("null") ? null : Integer.parseInt(templateVersionProvider);

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.templateVersion(templateVersion)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: templateversion")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Version created date missing or invalid.")
	public void bonusTemplateUpdateCommand_Version_Created_Date_Missing_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.versionCreatedDate(null)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing parameter: version_createddate")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. wageringrequirementtype_id missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusTemplateUpdateCommand_Wageringrequirementtype_id_Missing_Invalid(String wageringrequirementtypeidProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer wageringrequirementtype_id = wageringrequirementtypeidProvider.equals("null") ? null : Integer.parseInt(wageringrequirementtypeidProvider);

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.wageringrequirementtypeId(wageringrequirementtype_id)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: wageringrequirementtype_id")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. wageringrequirementmultiplier missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusTemplateUpdateCommand_Wageringrequirementmultiplier_Missing_Invalid1(String wageringRequirementMultiplierProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer wageringRequirementMultiplier = wageringRequirementMultiplierProvider.equals("null") ? null : Integer.parseInt(wageringRequirementMultiplierProvider);

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.wageringRequirementMultiplier(wageringRequirementMultiplier)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: wageringrequirementmultiplier")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. expiryinhours missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusTemplateUpdateCommand_Expiryinhours_Missing_Invalid(String expiryInHoursProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer expiryInHours = expiryInHoursProvider.equals("null") ? null : Integer.parseInt(expiryInHoursProvider);

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.wageringRequirementMultiplier(1)
				.expiryInHours(expiryInHours)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: expiryinhours")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. promotiontermstoken missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullEmptyString")
	public void bonusTemplateUpdateCommand_Promotiontermstoken_Missing_Invalid(String promotiontermstokenProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		String promotiontermstoken = promotiontermstokenProvider.equals("null") ? null : promotiontermstokenProvider;

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.promotionTermsToken(promotiontermstoken)
				.wageringRequirementMultiplier(1)
				.expiryInHours(720)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: promotiontermstoken")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. bonuspercentage missing or invalid.")
	public void bonusTemplateUpdateCommand_Bonuspercentage_Missing_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.maximumBonus(1300)
				.minimumToQualify(10)
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(5)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.wageringRequirementMultiplier(1)
				.expiryInHours(720)
				.bonusPercentage(-1)
				.depositMatched(true)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: bonuspercentage")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. ringfencedpercentage missing or invalid.")
	public void bonusTemplateUpdateCommand_Ringfencedpercentage_Missing_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.maximumBonus(1300)
				.minimumToQualify(10)
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(5)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.wageringRequirementMultiplier(1)
				.expiryInHours(720)
				.useRingfencing(true)
				.ringfencedPercentage(-1)
				.depositMatched(true)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: ringfencedpercentage")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. claimperiodinhours missing or invalid.")
	public void bonusTemplateUpdateCommand_Claimperiodinhours_Missing_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(3)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.claimPeriodInHours(-1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: claimperiodinhours")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. bonuscurrencyamounts missing or invalid.")
	public void bonusTemplateUpdateCommand_Bonuscurrencyamounts_Missing_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(3)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: bonuscurrencyamounts")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. subsequentbonustemplate_id missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusTemplateUpdateCommand_Subsequentbonustemplate_id_Missing_Invalid(String subsequentBonusTemplateIdProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer subsequentBonusTemplateId = subsequentBonusTemplateIdProvider.equals("null") ? null : Integer.parseInt(subsequentBonusTemplateIdProvider);

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.hasSubsequentBonus(true)
				.gameweighttemplateId(1)
				.wageringRequirementMultiplier(1)
				.triggerSubsequentBonusOnComplete(true)
				.subsequentBonusTemplateId(subsequentBonusTemplateId)
				.subsequentBonusType(4)
				.expiryInHours(720)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: subsequentbonustemplate_id")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. subsequentbonustype missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusTemplateUpdateCommand_Subsequentbonustype_Missing_Invalid(String subsequentbonustypeProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer subsequentbonustype = subsequentbonustypeProvider.equals("null") ? null : Integer.parseInt(subsequentbonustypeProvider);

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.hasSubsequentBonus(true)
				.gameweighttemplateId(1)
				.wageringRequirementMultiplier(1)
				.triggerSubsequentBonusOnComplete(true)
				.subsequentBonusTemplateId(1)
				.subsequentBonusType(subsequentbonustype)
				.expiryInHours(720)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: subsequentbonustype")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. subsequentbonustriggeringevent missing or invalid.")
	public void bonusTemplateUpdateCommand_Subsequentbonustriggeringevent_Missing_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.hasSubsequentBonus(true)
				.gameweighttemplateId(1)
				.wageringRequirementMultiplier(1)
				.subsequentBonusTemplateId(1)
				.subsequentBonusType(4)
				.expiryInHours(720)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid subsequentbonustriggeringevent. Select at least one triggering event")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. subsequentbonusamount invalid.")
	public void bonusTemplateUpdateCommand_subsequentbonusamount_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.maximumBonus(1300)
				.subsequentBonusAmount(1001)
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.hasSubsequentBonus(true)
				.gameweighttemplateId(1)
				.wageringRequirementMultiplier(1)
				.subsequentBonusTemplateId(452)
				.triggerSubsequentBonusOnComplete(true)
				.subsequentBonusType(4)
				.expiryInHours(720)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Invalid subsequentbonusamount: SubsequentBonusAmount is greater than maximum bonus amount of the subsequent bonus.")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. currency_Id missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusTemplateUpdateCommand_Currency_Id_Missing(String currencyIdProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer currencyId = currencyIdProvider.equals("null") ? null : Integer.parseInt(currencyIdProvider);

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.currencyId(currencyId)
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.addRegulatedZone(1)
				.addCountry(234)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: currency_id")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Maximumbonus missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusTemplateUpdateCommand_Maximumbonus_Missing(String maximumBonusProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer maximumBonus = maximumBonusProvider.equals("null") ? null : Integer.parseInt(maximumBonusProvider);

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.maximumBonus(maximumBonus)
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.addRegulatedZone(1)
				.addCountry(234)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: maximumbonus")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. minimumtoqualify not valid for cash bonuses.")
	public void bonusTemplateUpdateCommand_Minimumtoqualify_Not_Valid_For_Cash_Bonuses() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.maximumBonus(1300)
				.minimumToQualify(10)
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(3)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.wageringRequirementMultiplier(1)
				.expiryInHours(720)
				.depositMatched(true)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Invalid minimumtoqualify: Not valid for cash bonuses")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Minimumtoqualify missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusTemplateUpdateCommand_Minimumtoqualify_Missing(String minimumtoqualifyProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer minimumtoqualify = minimumtoqualifyProvider.equals("null") ? null : Integer.parseInt(minimumtoqualifyProvider);

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.minimumToQualify(minimumtoqualify)
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(5)
				.addRegulatedZone(1)
				.gameweighttemplateId(1)
				.addCountry(234)
				.depositMatched(true)
				.wageringRequirementMultiplier(1)
				.expiryInHours(720)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/Invalid minimumtoqualify")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. subsequentbonusamount missing/invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusTemplateUpdateCommand_subsequentbonusamount_Missing_Invalid(String subsequentbonusamountProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer subsequentbonusamount = subsequentbonusamountProvider.equals("null") ? null : Integer.parseInt(subsequentbonusamountProvider);

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.maximumBonus(1300)
				.subsequentBonusAmount(subsequentbonusamount)
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.hasSubsequentBonus(true)
				.gameweighttemplateId(1)
				.wageringRequirementMultiplier(1)
				.subsequentBonusTemplateId(1)
				.triggerSubsequentBonusOnComplete(true)
				.subsequentBonusType(4)
				.expiryInHours(720)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/Invalid subsequentbonusamount")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. wageringrequirement not valid for cash bonuses.")
	public void bonusTemplateUpdateCommand_Wageringrequirement_Not_Valid_For_Cash_Bonuses() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.maximumBonus(1300)
				.wageringRequirement(10)
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(3)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.wageringRequirementMultiplier(1)
				.expiryInHours(720)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Invalid wageringrequirement: Not valid for cash bonuses")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. maxbet not valid for cash bonuses.")
	public void bonusTemplateUpdateCommand_Maxbet_Not_Valid_For_Cash_Bonuses() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.maximumBonus(1300)
				.maxBet(20)
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(3)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.wageringRequirementMultiplier(1)
				.expiryInHours(720)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Invalid maxbet: Not valid for cash bonuses")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. wageringrequirement missing/invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusTemplateUpdateCommand_Wageringrequirement_Missing_Invalid(String wageringrequirementProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer wageringrequirement = wageringrequirementProvider.equals("null") ? null : Integer.parseInt(wageringrequirementProvider);

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.maximumBonus(1300)
				.wageringRequirement(wageringrequirement)
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(5)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.wageringRequirementMultiplier(1)
				.wageringrequirementtypeId(2)
				.expiryInHours(720)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/Invalid wageringrequirement")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. thresholdlimit not valid for after-wager bonuses.")
	public void bonusTemplateUpdateCommand_Thresholdlimit_Not_Valid_For_After_Wager_Bonuses() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.thresholdLimit(10)
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.wageringRequirementMultiplier(1)
				.expiryInHours(720)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Invalid thresholdlimit: Not valid for after-wager bonuses")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. maxbet missing or invalid.")
	public void bonusTemplateUpdateCommand_Maxbet_Missing_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.maxBet(-1)
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustemplateId(485)
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.wageringRequirementMultiplier(1)
				.expiryInHours(720)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid maxbet")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. maxbet_percentage missing or invalid.")
	public void bonusTemplateUpdateCommand_Maxbet_percentage_Missing_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustemplateId(485)
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.wageringRequirementMultiplier(1)
				.expiryInHours(720)
				.maxbetPercentage(-1)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid maxbet percentage")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. thresholdlimit missing or invalid.")
	public void bonusTemplateUpdateCommand_Thresholdlimit_Missing_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.thresholdLimit(-1)
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustemplateId(485)
				.bonustypeId(5)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.wageringRequirementMultiplier(1)
				.expiryInHours(720)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/Invalid thresholdlimit")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Affiliate created date missing or invalid.")
	public void bonusTemplateUpdateCommand_Affiliate_Created_Date_Missing_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.build();

		BonusAffiliateCodes bonusAffiliateCode = new BonusAffiliateCodes.Builder()
				.defaults()
				.addAffiliateCode("test")
				.createdDate(null)
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustemplateId(485)
				.bonustypeId(5)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.bonusAffiliateCodes(bonusAffiliateCode)
				.wageringRequirementMultiplier(1)
				.isAffiliateBonus(true)
				.expiryInHours(720)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing parameter: bonusaffiliatecodes/createddate")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Affiliate codes missing or invalid.")
	public void bonusTemplateUpdateCommand_Affiliate_Code_Missing_Invalid() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.build();

		BonusAffiliateCodes bonusAffiliateCode = new BonusAffiliateCodes.Builder()
				.defaults()
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustemplateId(485)
				.bonustypeId(5)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.bonusAffiliateCodes(bonusAffiliateCode)
				.wageringRequirementMultiplier(1)
				.isAffiliateBonus(true)
				.expiryInHours(720)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing parameter: bonusaffiliatecodes/affiliatecodes")
				.code(1003)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusTemplateUpdateCommand. Insert bonus template failed.")
	public void bonusTemplateUpdateCommand_Insert_Failed() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusCurrencyAmount bonusCurrencyAmount = new BonusCurrencyAmount.Builder()
				.defaults()
				.build();

		BonusTemplateUpdateCommandReq request = new BonusTemplateUpdateCommandReq.Builder()
				.defaults()
				.bonustemplateId(485)
				.bonustypeId(4)
				.addRegulatedZone(1)
				.addCountry(234)
				.gameweighttemplateId(1)
				.addBonusCurrencyamount(bonusCurrencyAmount)
				.wageringRequirementMultiplier(1)
				.expiryInHours(720)
				.id(id)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.bonusTemplateUpdateCommandError);
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Insert bonus template failed")
				.code(1002)
				.build();
		assertReflectionEquals(expectedResponse, actualResponse);	
	}
}
