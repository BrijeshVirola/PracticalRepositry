package tests.gamingbonusadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.UUID;

import org.testng.Reporter;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusadminservice.enums.GamingBonusAdminEndpoints;
import tests.gamingbonusadminservice.request.AddCreditedUsersCommandReq;
import tests.gamingbonusadminservice.request.BonusClaimByAdminCommandReq;
import tests.gamingbonusadminservice.request.ExportCreditButNotClaimedCommandReq;
import tests.gamingbonusadminservice.request.GetUsersForBonusActionsCommandReq;
import tests.gamingbonusadminservice.request.SpecificBonusCancelByAdminCommandReq;
import tests.gamingbonusadminservice.requestobjects.UserBonus;
import tests.gamingbonusadminservice.response.ExportCreditButNotClaimedCommandResp;
import tests.gamingbonusadminservice.response.GetUsersForBonusActionsCommandResp;
import tests.gamingbonusadminservice.responseobjects.ExportCreditButNotClaimedCommandResult;

public class ExportcreditButNotClaimedCommandTests extends BaseClassSetup {

	@Test(description = "Make a request to exportcreditbutnotclaimedcommand. Cash End to end Scenario.")
	public void exportCreditButNotClaimedCommand_Cash_End_To_End_Scenario() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		String historyToken = UUID.randomUUID().toString();
		Integer userId = 4685399;
		String username = "GO_SVC_TESTS55";
		BigInteger bonustemplateId = new BigInteger("516");
		Integer versionId = 1061;
		BigDecimal amount = new BigDecimal("1.2");

		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(amount)
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.historyToken(historyToken)
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);

		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		Reporter.log("02. Get userbonusId using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq getUsersForBonusActionsReq = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(id)
				.bonusTemplateId(bonustemplateId)
				.versionId(versionId)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actGetUsersForBonusActionsResp = BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actGetUsersForBonusActionsResp.getUserbonusId();

		Reporter.log("05. Check that there is bonus data for the user using exportcreditbutnotclaimedcommand.");
		ExportCreditButNotClaimedCommandReq exportReq = new ExportCreditButNotClaimedCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(bonustemplateId)
				.build();

		ExportCreditButNotClaimedCommandResp exportResp =  BaseRequest.post(exportReq, GamingBonusAdminEndpoints.exportCreditButNotClaimedCommandSuccess);

		ExportCreditButNotClaimedCommandResult expResult = new ExportCreditButNotClaimedCommandResult.Builder()
				.defaults()
				.userId(userId)
				.username(username)
				.amount(amount.toString())
				.templateName("Go Services Cash Casino - exportclaimedbyversionco")
				.startDateUtc("2021-12-13T15:15:00Z")
				.build();

		ExportCreditButNotClaimedCommandResp expectedExportResp = new ExportCreditButNotClaimedCommandResp.Builder()
				.defaults()
				.id(id)
				.addResult(expResult)
				.build();

		assertReflectionEquals(expectedExportResp, exportResp);	

		Reporter.log("06. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}

	@Test(description = "Make a request to exportcreditbutnotclaimedcommand. Pre wager End to end Scenario.")
	public void exportCreditButNotClaimedCommand_Pre_Wager_End_To_End_Scenario() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		String historyToken = UUID.randomUUID().toString();
		Integer userId = 4685399;
		String username = "GO_SVC_TESTS55";
		BigInteger bonustemplateId = new BigInteger("521");
		Integer versionId = 1066;
		BigDecimal amount = new BigDecimal("0.15");

		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(amount)
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.historyToken(historyToken)
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);

		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		Reporter.log("02. Get userbonusId using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq getUsersForBonusActionsReq = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(id)
				.bonusTemplateId(bonustemplateId)
				.versionId(versionId)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actGetUsersForBonusActionsResp = BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actGetUsersForBonusActionsResp.getUserbonusId();

		Reporter.log("05. Check that there is bonus data for the user using exportcreditbutnotclaimedcommand.");
		ExportCreditButNotClaimedCommandReq exportReq = new ExportCreditButNotClaimedCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(bonustemplateId)
				.build();

		ExportCreditButNotClaimedCommandResp exportResp =  BaseRequest.post(exportReq, GamingBonusAdminEndpoints.exportCreditButNotClaimedCommandSuccess);

		ExportCreditButNotClaimedCommandResult expResult = new ExportCreditButNotClaimedCommandResult.Builder()
				.defaults()
				.userId(userId)
				.username(username)
				.amount(amount.toString())
				.templateName("Go Services exportcreditbutnotclaimedcommand")
				.startDateUtc("2021-12-15T16:50:00Z")
				.build();

		ExportCreditButNotClaimedCommandResp expectedExportResp = new ExportCreditButNotClaimedCommandResp.Builder()
				.defaults()
				.id(id)
				.addResult(expResult)
				.build();

		assertReflectionEquals(expectedExportResp, exportResp);	

		Reporter.log("06. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}

	@Test(description = "Make a request to exportcreditbutnotclaimedcommand. After wager End to end Scenario.")
	public void exportCreditButNotClaimedCommand_After_Wager_End_To_End_Scenario() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		String historyToken = UUID.randomUUID().toString();
		Integer userId = 4685399;
		String username = "GO_SVC_TESTS55";
		BigInteger bonustemplateId = new BigInteger("520");
		Integer versionId = 1065;
		BigDecimal amount = new BigDecimal("0.15");

		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(amount)
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.historyToken(historyToken)
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);

		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		Reporter.log("02. Get userbonusId using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq getUsersForBonusActionsReq = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(id)
				.bonusTemplateId(bonustemplateId)
				.versionId(versionId)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actGetUsersForBonusActionsResp = BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actGetUsersForBonusActionsResp.getUserbonusId();

		Reporter.log("05. Check that there is bonus data for the user using exportcreditbutnotclaimedcommand.");
		ExportCreditButNotClaimedCommandReq exportReq = new ExportCreditButNotClaimedCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(bonustemplateId)
				.build();

		ExportCreditButNotClaimedCommandResp exportResp =  BaseRequest.post(exportReq, GamingBonusAdminEndpoints.exportCreditButNotClaimedCommandSuccess);

		ExportCreditButNotClaimedCommandResult expResult = new ExportCreditButNotClaimedCommandResult.Builder()
				.defaults()
				.userId(userId)
				.username(username)
				.amount(amount.toString())
				.templateName("Go Services - exportcreditbutnotclaimedcommand")
				.startDateUtc("2021-12-15T16:40:00Z")
				.build();

		ExportCreditButNotClaimedCommandResp expectedExportResp = new ExportCreditButNotClaimedCommandResp.Builder()
				.defaults()
				.id(id)
				.addResult(expResult)
				.build();

		assertReflectionEquals(expectedExportResp, exportResp);	

		Reporter.log("06. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}

	@Test(description = "Make a request to exportCreditButNotClaimedCommand. Several results.")
	public void exportCreditButNotClaimedCommand_Several_Results() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer userId1 = 4686064;
		Integer userId2 = 4686074;
		BigInteger bonusTemplateId = new BigInteger("522");
		
		Reporter.log("01. Precondition - Remove the last bonus user using specificbonuscancelbyadmincommand for user: " + userId1);
		Utils.cancelLastBonusIdOfUser(userId1);
		
		Reporter.log("02. Precondition - Remove the last bonus user using specificbonuscancelbyadmincommand for user: " + userId2);
		Utils.cancelLastBonusIdOfUser(userId2);
		
		Reporter.log("03. Credit user " + userId1 + " using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId1)
				.bonustemplateId(bonusTemplateId)
				.amount(new BigDecimal("1.36"))
				.historyToken(UUID.randomUUID().toString())
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);
		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	
		
		Reporter.log("04. Credit user " + userId2 + " using addCreditedUsersCommand");
		userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId2)
				.bonustemplateId(bonusTemplateId)
				.amount(new BigDecimal("0.12"))
				.historyToken(UUID.randomUUID().toString())
				.build();

		addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);
		expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		Reporter.log("05. Check that several results are returned using exportcreditbutnotclaimedcommand");
		ExportCreditButNotClaimedCommandReq exportReq = new ExportCreditButNotClaimedCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(new BigInteger("522"))
				.build();

		ExportCreditButNotClaimedCommandResp exportResp =  BaseRequest.post(exportReq, GamingBonusAdminEndpoints.exportCreditButNotClaimedCommandSuccess);

		ExportCreditButNotClaimedCommandResult expResult1 = new ExportCreditButNotClaimedCommandResult.Builder()
				.defaults()
				.userId(userId1)
				.username("GO_SVC_TESTS56")
				.amount("1.36")
				.templateName("Go Services Cash Casino - exportclaimedbyversionco")
				.startDateUtc("2021-12-16T10:15:00Z")
				.build();

		ExportCreditButNotClaimedCommandResult expResult2 = new ExportCreditButNotClaimedCommandResult.Builder()
				.defaults()
				.userId(4686074)
				.username("GO_SVC_TESTS57")
				.amount("0.12")
				.templateName("Go Services Cash Casino - exportclaimedbyversionco")
				.startDateUtc("2021-12-16T10:15:00Z")
				.build();

		ExportCreditButNotClaimedCommandResp expectedExportResp = new ExportCreditButNotClaimedCommandResp.Builder()
				.defaults()
				.id(id)
				.addResult(expResult1)
				.addResult(expResult2)
				.build();

		assertReflectionEquals(expectedExportResp, exportResp);	
	}

	@Test(description = "Make a request to exportcreditbutnotclaimedcommand. Credited and Claimed bonus.")
	public void exportCreditButNotClaimedCommand_Credited_And_Claimed_Bonus() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		String historyToken = UUID.randomUUID().toString();
		Integer userId = 4686109;
		String username = "GO_SVC_TESTS58";
		BigInteger bonustemplateId = new BigInteger("523");
		Integer versionId = 1068;
		BigDecimal amount = new BigDecimal("1.2");

		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(amount)
				.historyToken(historyToken)
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);

		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		Reporter.log("02. Get userbonusId using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq getUsersForBonusActionsReq = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(id)
				.bonusTemplateId(bonustemplateId)
				.versionId(versionId)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actGetUsersForBonusActionsResp = BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actGetUsersForBonusActionsResp.getUserbonusId();

		Reporter.log("05. Check that there is bonus data for the user using exportcreditbutnotclaimedcommand.");
		ExportCreditButNotClaimedCommandReq exportReq = new ExportCreditButNotClaimedCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(bonustemplateId)
				.build();

		ExportCreditButNotClaimedCommandResp exportResp =  BaseRequest.post(exportReq, GamingBonusAdminEndpoints.exportCreditButNotClaimedCommandSuccess);

		ExportCreditButNotClaimedCommandResult expResult = new ExportCreditButNotClaimedCommandResult.Builder()
				.defaults()
				.userId(userId)
				.username(username)
				.amount(amount.toString())
				.templateName("Go Services Cash Casino - exportclaimedbyversionco")
				.startDateUtc("2021-12-16T10:45:00Z")
				.build();

		ExportCreditButNotClaimedCommandResp expectedExportResp = new ExportCreditButNotClaimedCommandResp.Builder()
				.defaults()
				.id(id)
				.addResult(expResult)
				.build();

		assertReflectionEquals(expectedExportResp, exportResp);	


		Reporter.log("06. Claim the bonus");
		BonusClaimByAdminCommandReq bonusClaimReq = new BonusClaimByAdminCommandReq.Builder()
				.defaults()
				.id(id)
				.userBonusId(userbonusId)
				.userId(userId)
				.build();

		ResultOKResp actResultOKResp = BaseRequest.post(bonusClaimReq, GamingBonusAdminEndpoints.bonusClaimByAdminCommandSuccess);
		ResultOKResp expResultOKResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();
		assertReflectionEquals(expResultOKResp, actResultOKResp);	


		Reporter.log("07. Check that there is no bonus data for the user using exportcreditbutnotclaimedcommand.");
		CustomErrorResponse errorResp =  BaseRequest.post(exportReq, GamingBonusAdminEndpoints.exportCreditButNotClaimedCommandError);

		CustomErrorResponse expErrorResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("No data was found for passed Bonus Template Id")
				.code(1001)
				.build();

		assertReflectionEquals(expErrorResp, errorResp);	
	}

	@Test(description = "Make a request to exportcreditbutnotclaimedcommand. Missing/Invalid bonustemplate_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void exportCreditButNotClaimedCommand_Missing_Invalid_Bonus_Template_Id(String nullZero) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		BigInteger bonustemplateId = nullZero.equals("null") ? null : new BigInteger(nullZero);

		ExportCreditButNotClaimedCommandReq exportReq = new ExportCreditButNotClaimedCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(bonustemplateId)
				.build();

		CustomErrorResponse resp =  BaseRequest.post(exportReq, GamingBonusAdminEndpoints.exportCreditButNotClaimedCommandError);

		CustomErrorResponse expResp = new CustomErrorResponse.Builder().defaults()
				.message("Missing/Invalid parameter: bonustemplate_id")
				.code(1003)
				.id(id)
				.build();

		assertReflectionEquals(expResp, resp);	
	}

	@Test(description = "Make a request to exportCreditButNotClaimedCommand. No data found.")
	public void exportCreditButNotClaimedCommand_No_Data_Found() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		ExportCreditButNotClaimedCommandReq exportReq = new ExportCreditButNotClaimedCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(new BigInteger("1"))
				.build();

		CustomErrorResponse resp =  BaseRequest.post(exportReq, GamingBonusAdminEndpoints.exportCreditButNotClaimedCommandError);

		CustomErrorResponse expResp = new CustomErrorResponse.Builder().defaults()
				.message("No data was found for passed Bonus Template Id")
				.code(1001)
				.id(id)
				.build();

		assertReflectionEquals(expResp, resp);	
	}

	@Test(description = "Make a request to exportCreditButNotClaimedCommand. Incorrect method.")
	public void exportCreditButNotClaimedCommand_Incorrect_Method() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		ExportCreditButNotClaimedCommandReq exportReq = new ExportCreditButNotClaimedCommandReq.Builder()
				.defaults()
				.id(id)
				.method("INCORRCT_METHOD")
				.build();

		CustomErrorResponse resp =  BaseRequest.post(exportReq, GamingBonusAdminEndpoints.exportCreditButNotClaimedCommandError);

		CustomErrorResponse expResp = new CustomErrorResponse.Builder().defaults()
				.message("Incorrect method in request")
				.code(6)
				.id(null)
				.build();

		assertReflectionEquals(expResp, resp);	
	}

	@Test(description = "Make a request to exportCreditButNotClaimedCommand. Missing method.")
	public void exportCreditButNotClaimedCommand_Missing_Method() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		ExportCreditButNotClaimedCommandReq exportReq = new ExportCreditButNotClaimedCommandReq.Builder()
				.defaults()
				.id(id)
				.method(null)
				.build();

		CustomErrorResponse resp =  BaseRequest.post(exportReq, GamingBonusAdminEndpoints.exportCreditButNotClaimedCommandError);

		CustomErrorResponse expResp = new CustomErrorResponse.Builder().defaults()
				.message("Method missing from request")
				.code(5)
				.id(null)
				.build();

		assertReflectionEquals(expResp, resp);	
	}

	@Test(description = "Make a request to exportCreditButNotClaimedCommand. Missing params.")
	public void exportCreditButNotClaimedCommand_Missing_Params() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		ExportCreditButNotClaimedCommandReq exportReq = new ExportCreditButNotClaimedCommandReq.Builder()
				.defaults()
				.id(id)
				.build();
		exportReq.removeParams();

		CustomErrorResponse resp =  BaseRequest.post(exportReq, GamingBonusAdminEndpoints.exportCreditButNotClaimedCommandError);

		CustomErrorResponse expResp = new CustomErrorResponse.Builder().defaults()
				.message("Params missing from request")
				.code(5)
				.id(null)
				.build();

		assertReflectionEquals(expResp, resp);	
	}

	@Test(description = "Make a request to exportCreditButNotClaimedCommand. Bonustemplate_id above max value.")
	public void exportCreditButNotClaimedCommand_Bonustemplate_Id_Above_Max() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		ExportCreditButNotClaimedCommandReq exportReq = new ExportCreditButNotClaimedCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(new BigInteger("2147483648"))
				.build();

		CustomErrorResponse resp =  BaseRequest.post(exportReq, GamingBonusAdminEndpoints.exportCreditButNotClaimedCommandError);

		CustomErrorResponse expResp = new CustomErrorResponse.Builder().defaults()
				.message("Couldn't unmarshal params into target type : json: cannot unmarshal number"
						+ " 2147483648 into Go struct field Request.bonustemplate_id of type int32")
				.code(4)
				.id(null)
				.build();

		assertReflectionEquals(expResp, resp);	
	}
}
