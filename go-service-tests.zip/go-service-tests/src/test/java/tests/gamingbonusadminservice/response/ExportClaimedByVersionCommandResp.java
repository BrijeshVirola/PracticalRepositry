package tests.gamingbonusadminservice.response;

import java.util.ArrayList;
import java.util.List;

import tests.gamingbonusadminservice.responseobjects.ExportClaimedByVersionCommandResult;

public class ExportClaimedByVersionCommandResp {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private List<ExportClaimedByVersionCommandResult> result;
	
	public ExportClaimedByVersionCommandResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public static class Builder {
		
		private String id;
		private List<ExportClaimedByVersionCommandResult> result;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addResult(ExportClaimedByVersionCommandResult result) {
			this.result.add(result);
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultTestId";
			this.result = new ArrayList<>();
			
			return this;
		}
		
		public ExportClaimedByVersionCommandResp build() {
			return new ExportClaimedByVersionCommandResp(this);
		}
	}
}
