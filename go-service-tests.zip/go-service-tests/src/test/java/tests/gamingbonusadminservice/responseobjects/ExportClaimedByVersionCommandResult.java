package tests.gamingbonusadminservice.responseobjects;

public class ExportClaimedByVersionCommandResult {
	
	Integer user_id;
	String username;
	String amount;
	String currency;
	String templatename;
	Integer templateversion;
	String startdateutc;
	
	private ExportClaimedByVersionCommandResult(Builder builder) {
		user_id = builder.user_id;
		username = builder.username;
		amount = builder.amount;
		currency = builder.currency;
		templatename = builder.templatename;
		templateversion = builder.templateversion;
		startdateutc = builder.startdateutc;
	}
	
	public static class Builder {
		
		Integer user_id;
		String username;
		String amount;
		String currency;
		String templatename;
		Integer templateversion;
		String startdateutc;
		
		public Builder username(String username) {
			this.username = username;
			return this;
		}
		
		public Builder userId(Integer userId) {
			user_id = userId;
			return this;
		}
		
		public Builder templateName(String templateName) {
			this.templatename = templateName;
			return this;
		}
		
		public Builder startDateUtc(String startDateUtc) {
			this.startdateutc = startDateUtc;
			return this;
		}
		
		public Builder amount(String amount) {
			this.amount = amount;
			return this;
		}
		
		public Builder templateVersion(Integer templateVersion) {
			this.templateversion = templateVersion;
			return this;
		}
		
		public Builder currency(String currency) {
			this.currency = currency;
			return this;
		}
		
		public Builder defaults() {
			user_id = 4454479;
			username = "vzuat1com";
			amount = "1";
			currency = "GBP";
			templatename = "Test Template Name";
			templateversion = 1;
			startdateutc = "2021-12-02T08:45:00Z";
			return this;
		}
		
		public ExportClaimedByVersionCommandResult build() {
			return new ExportClaimedByVersionCommandResult(this);
		}
	}
}
