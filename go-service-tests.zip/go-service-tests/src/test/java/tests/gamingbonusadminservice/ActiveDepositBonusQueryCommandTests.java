package tests.gamingbonusadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import tests.gamingbonusadminservice.enums.GamingBonusAdminEndpoints;
import tests.gamingbonusadminservice.request.ActiveDepositBonusQueryCommandReq;
import tests.gamingbonusadminservice.response.ActiveDepositBonusQueryCommandResp;

public class ActiveDepositBonusQueryCommandTests extends BaseClassSetup {

	@DataProvider
	public Object[][] bonuses() {
		return new Object[][] {
			{4664780, 1, false},
			{4664780, 2, true},
			{4664780, 3, false},
			{4664780, 4, true},
			{4664780, 25, false},
			{4664780, 45, false},
			{4664780, 7, false},
			{4664969, 2, false},
			{4664969, 4, false}
		};
	}

	@Test(description = "Make a request to activedepositbonusquerycommand. Positive Scenario.", dataProvider = "bonuses")
	public void activeDepositBonusQueryCommand_Positive_Scenario(
			Integer userId, Integer productId, Boolean exists) throws InterruptedException {

		String id = UUID.randomUUID().toString();

		ActiveDepositBonusQueryCommandReq request = new ActiveDepositBonusQueryCommandReq.Builder()
				.defaults()
				.id(id)
				.userId(userId)
				.productId(productId)
				.build();

		ActiveDepositBonusQueryCommandResp actualResponse = BaseRequest.post(
				request, GamingBonusAdminEndpoints.activeDepositBonusQueryCommandSuccess);


		ActiveDepositBonusQueryCommandResp expectedResponse = new ActiveDepositBonusQueryCommandResp.Builder()
				.defaults()
				.id(id)
				.exists(exists)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to activedepositbonusquerycommand. User id missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void activeDepositBonusQueryCommand_User_Id_Missing(String userIdProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer userId = userIdProvider.equals("null") ? null : Integer.parseInt(userIdProvider);


		ActiveDepositBonusQueryCommandReq request = new ActiveDepositBonusQueryCommandReq.Builder()
				.defaults()
				.id(id)
				.userId(userId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.activeDepositBonusQueryCommandError);


		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing parameter: user_id")
				.code(1003)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to activedepositbonusquerycommand. Product id missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void activeDepositBonusQueryCommand_Product_Id_Missing(String productIdProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer productId = productIdProvider.equals("null") ? null : Integer.parseInt(productIdProvider);


		ActiveDepositBonusQueryCommandReq request = new ActiveDepositBonusQueryCommandReq.Builder()
				.defaults()
				.id(id)
				.productId(productId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.activeDepositBonusQueryCommandError);


		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: product_id")
				.code(1003)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}
}
