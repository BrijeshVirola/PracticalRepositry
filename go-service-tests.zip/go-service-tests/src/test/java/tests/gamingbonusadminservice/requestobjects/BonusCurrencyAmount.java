package tests.gamingbonusadminservice.requestobjects;

public class BonusCurrencyAmount {
	
	Integer currency_id;
	Integer maximumbonus;
	Integer minimumtoqualify;
	Integer thresholdlimit;
	Integer maxbet;
	Integer subsequentbonusamount;
	Integer wageringrequirement;
	Integer maxbet_percentage; 
	
	private BonusCurrencyAmount(Builder builder) {
		currency_id = builder.currency_id;
		maximumbonus = builder.maximumbonus;
		minimumtoqualify = builder.minimumtoqualify;
		thresholdlimit = builder.thresholdlimit;
		maxbet = builder.maxbet;
		subsequentbonusamount = builder.subsequentbonusamount;
		wageringrequirement = builder.wageringrequirement;
	}
	
	public static class Builder {
		
		Integer currency_id;
		Integer maximumbonus;
		Integer minimumtoqualify;
		Integer wageringrequirement;
		Integer thresholdlimit;
		Integer maxbet;
		Integer subsequentbonusamount;
		
		public Builder wageringRequirement(Integer wageringRequirement) {
			wageringrequirement = wageringRequirement;
			return this;
		}
		
		public Builder currencyId(Integer currencyId) {
			currency_id = currencyId;
			return this;
		}
		
		public Builder maximumBonus(Integer maximumBonus) {
			maximumbonus = maximumBonus;
			return this;
		}
		
		public Builder minimumToQualify(Integer minimumToQualify) {
			minimumtoqualify = minimumToQualify;
			return this;
		}
		
		public Builder thresholdLimit(Integer thresholdLimit) {
			thresholdlimit = thresholdLimit;
			return this;
		}
		
		public Builder maxBet(Integer maxBet) {
			maxbet = maxBet;
			return this;
		}
		
		public Builder subsequentBonusAmount(Integer subsequentBonusAmount) {
			subsequentbonusamount = subsequentBonusAmount;
			return this;
		}
		
		public Builder defaults() {
			currency_id = 1;
			maximumbonus = 1000;
			thresholdlimit = null;
			maxbet = null;
			subsequentbonusamount = null;
			minimumtoqualify = null;
			wageringrequirement = null;
			return this;
		}
		
		public BonusCurrencyAmount build() {
			return new BonusCurrencyAmount(this);
		}
	}
}
