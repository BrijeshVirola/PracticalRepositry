package tests.gamingbonusadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.UUID;

import org.testng.Reporter;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusadminservice.enums.GamingBonusAdminEndpoints;
import tests.gamingbonusadminservice.request.AddCreditedUsersCommandReq;
import tests.gamingbonusadminservice.request.GetUsersForBonusActionsCommandReq;
import tests.gamingbonusadminservice.request.SpecificBonusCancelByAdminCommandReq;
import tests.gamingbonusadminservice.requestobjects.UserBonus;
import tests.gamingbonusadminservice.response.GetUsersForBonusActionsCommandResp;
import tests.gamingbonusadminservice.responseobjects.UserBonusAction;

public class AddCreditedUsersCommandTests extends BaseClassSetup {

	@Test(description = "Make a request to addCreditedUsersCommand. Positive Scenario.")
	public void addCreditedUsersCommand_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(1)
				.bonustemplateId(new BigInteger("1"))
				.amount(new BigDecimal("0.1"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.historyToken("195e5674-9301-44c1-b16e-5d3ea9e759ed")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);


		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	
	}

	@Test(description = "Make a request to addCreditedUsersCommand. End to end Scenario.")
	public void addCreditedUsersCommand_End_To_End_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String historyToken = UUID.randomUUID().toString();
		Integer userId = 4659688;
		String username = "GO_SVC_TESTS37";
		BigInteger bonustemplateId = new BigInteger("467");
		Integer versionId = 999;

		Reporter.log("01. Check that there is no bonus data for the user.");
		GetUsersForBonusActionsCommandReq getUsersForBonusActionsReq = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.bonusTemplateId(bonustemplateId)
				.versionId(versionId)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		CustomErrorResponse actNoDataResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);

		CustomErrorResponse expNoDataResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("No data was found for passed parameters")
				.code(1001)
				.build();

		assertReflectionEquals(expNoDataResp, actNoDataResp);	

		Reporter.log("02. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("0.2"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.historyToken(historyToken)
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);


		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		Reporter.log("03. Check that bonus is credited using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandResp actGetUsersForBonusActionsResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actGetUsersForBonusActionsResp.getUserbonusId();

		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username(username)
				.userId(userId)
				.userbonusId(userbonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(20)
				.versionId(0)
				.currency("GBP")
				.build();

		GetUsersForBonusActionsCommandResp expGetUsersForBonusActionsResp = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonusAction(expUserBonusAction)
				.build();

		assertReflectionEquals(expGetUsersForBonusActionsResp, actGetUsersForBonusActionsResp);	

		Reporter.log("04. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}

	@Test(description = "Make a request to addCreditedUsersCommand. Missing parameter creditedby.",
			dataProviderClass = DataProviders.class, dataProvider = "nullEmptyString")
	public void addCreditedUsersCommand_Missing_Credited_By(String creditedByProvider) throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String creditedBy = creditedByProvider.equals("null") ? null : creditedByProvider;

		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby(creditedBy)
				.build();

		CustomErrorResponse actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandError);

		CustomErrorResponse expAddCreditResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing parameter: creditedby")
				.code(1003)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	
	}

	@Test(description = "Make a request to addCreditedUsersCommand. Missing parameter userbonuses.")
	public void addCreditedUsersCommand_Missing_User_Bonuses() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandError);

		CustomErrorResponse expAddCreditResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing parameter: userbonuses")
				.code(1003)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	
	}

	@Test(description = "Make a request to addCreditedUsersCommand. Wrong history token.")
	public void addCreditedUsersCommand_Wrong_History_Token() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.historyToken("wrongToken")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.build();

		CustomErrorResponse actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandError);

		CustomErrorResponse expAddCreditResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Error received while crediting user bonuses")
				.code(1002)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	
	}

	@Test(description = "Make a request to addCreditedUsersCommand. Missing parameter user_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void addCreditedUsersCommand_Missing_User_Id(String userIdProvider) throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = userIdProvider.equals("null") ? null : Integer.parseInt(userIdProvider);

		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.build();

		CustomErrorResponse actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandError);

		CustomErrorResponse expAddCreditResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing/Invalid parameter: user_id")
				.code(1003)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	
	}

	@Test(description = "Make a request to addCreditedUsersCommand. Missing parameter bonustemplate_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void addCreditedUsersCommand_Missing_Bonustemplate_Id(String bonusTemplateIdProvider) throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		BigInteger bonusTemplateId = bonusTemplateIdProvider.equals("null") ? null : new BigInteger(bonusTemplateIdProvider);

		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.bonustemplateId(bonusTemplateId)
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.build();

		CustomErrorResponse actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandError);

		CustomErrorResponse expAddCreditResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing/Invalid parameter: bonustemplate_id")
				.code(1003)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	
	}

	@Test(description = "Make a request to addCreditedUsersCommand. Missing parameter historytoken.",
			dataProviderClass = DataProviders.class, dataProvider = "nullEmptyString")
	public void addCreditedUsersCommand_Missing_History_Token(String historyTokenProvider) throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String historyToken = historyTokenProvider.equals("null") ? null : historyTokenProvider;

		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.historyToken(historyToken)
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.build();

		CustomErrorResponse actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandError);

		CustomErrorResponse expAddCreditResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing parameter: historytoken")
				.code(1003)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	
	}
}
