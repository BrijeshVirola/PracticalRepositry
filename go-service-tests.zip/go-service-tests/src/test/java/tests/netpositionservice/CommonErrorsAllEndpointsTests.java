package tests.netpositionservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.enumsconstants.ServiceErrors;
import domain.BaseRequest;
import domain.ErrorResponse;
import io.restassured.response.Response;

public class CommonErrorsAllEndpointsTests extends BaseClassSetup {

	@DataProvider(name = "getEndpoints")
	private Object[] getEndpoints() {
		return new Object[] { "startsession", "getnetposition", "handletransactions"};
	}

	@Test(description = "Make a request with GET instead of POST method - Error code 1", dataProvider = "getEndpoints")
	public void get_Method_Instead_Of_Post(String method) {

		Response response = BaseRequest.callEmptyBodyRequest(method , true,
				true, false);

		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.NOT_HTTP_POST);

		assertReflectionEquals(expError, actError);
	}

	@Test(description = "Make a request with no content type header - Error code 2", dataProvider = "getEndpoints")
	public void header_Content_Type_Not_Set(String method) {

		Response response = BaseRequest.callEmptyBodyRequest(method, true,
				false, true);

		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.THE_CONTENT_TYPE_HEADER_WAS_MISSING_OR_INVALID);

		assertReflectionEquals(expError, actError);
	}

	@Test(description = "Make a request wihtout Accept Header - Error code 3", dataProvider = "getEndpoints")
	public void header_Accept_Not_Set(String method) {

		Response response = BaseRequest.callEmptyBodyRequest(method, false,
				true, true);

		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.THE_ACCEPT_HEADER_WAS_MISSING_OR_INVALID);

		assertReflectionEquals(expError, actError);
	}

	@Test(description = "Make a request with no json in the body - Error code 4", dataProvider = "getEndpoints")
	public void no_Json(String method) {

		Response response = BaseRequest.callNoJsonRequest(method, true,
				true, true);
		response.then().statusCode(200);

		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.NO_JSON_REQUEST);

		assertReflectionEquals(expError, actError);
	}

	@Test(description = "Make a request with empty json in the body - Error code 5", dataProvider = "getEndpoints")
	public void json_Body_Empty(String method) {

		Response response = BaseRequest.callEmptyBodyRequest(method, true,
				true, true);

		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.EMPTY_JSON_BODY_REQUEST);

		assertReflectionEquals(expError, actError);
	}

}
