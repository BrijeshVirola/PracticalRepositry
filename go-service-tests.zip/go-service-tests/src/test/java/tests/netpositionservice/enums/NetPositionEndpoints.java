package tests.netpositionservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.common.response.ResultOKResp;
import tests.netpositionservice.response.GetNetPositionResp;

public enum NetPositionEndpoints implements ResponseEndpoints {

	startSessionSuccess(ResultOKResp.class, "StartSession"),
	startSessionError(CustomErrorResponse.class, "StartSession"),
	getNetPositionSuccess(GetNetPositionResp.class, "GetNetPosition"),
	getNetPositionError(CustomErrorResponse.class, "GetNetPosition"),
	handleTransactionsSuccess(ResultOKResp.class, "HandleTransactions"),
	handleTransactionsError(CustomErrorResponse.class, "HandleTransactions");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> NetPositionEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
