package tests.netpositionservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.netpositionservice.enums.NetPositionEndpoints;
import tests.netpositionservice.request.GetNetPositionReq;
import tests.netpositionservice.request.StartSessionReq;
import tests.netpositionservice.response.GetNetPositionResp;
public class GetNetPositionTests extends BaseClassSetup{

	@Test(description = "Make a request to GetNetPosition. Positive scenario.")
	public void getNetPosition_Positive_Scenario() throws InterruptedException {
		Instant sessionCreationTime = Instant.now();
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		StartSessionReq sessionRequest = new StartSessionReq.Builder()
				.defaults()
				.userId(UsersId.GO_SVC_TESTS03)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualSessionResponse =  BaseRequest.post(sessionRequest, NetPositionEndpoints.startSessionSuccess);

		ResultOKResp expectedSessionResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedSessionResponse, actualSessionResponse);	

		String idForRequestToBeEchoedBackInResponseId2 = UUID.randomUUID().toString();

		GetNetPositionReq netPositionRequest = new GetNetPositionReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId2)
				.userId(UsersId.GO_SVC_TESTS03)
				.build();

		GetNetPositionResp actualNetPositionResponse =  BaseRequest.post(netPositionRequest, NetPositionEndpoints.getNetPositionSuccess);

		Instant actionsCompleteTime = Instant.now();
		long timeSinceSessionCreated = Duration.between(sessionCreationTime, actionsCompleteTime).toMillis();

		Integer durationInMilliseconds = actualNetPositionResponse.getDurationInMilliseconds(); 
		Assert.assertTrue(durationInMilliseconds >= 0, "secs_since_login was less than zero");
		Assert.assertTrue(durationInMilliseconds <= timeSinceSessionCreated, "secs_since_login exceeded time since session was created");
		Assert.assertEquals(actualNetPositionResponse.getNetPositionAmount(), "0");
		Assert.assertEquals(actualNetPositionResponse.getRegulatedGameId(), 97998);
	}

	@Test(description = "Make a request to getNetPosition. Session not created.")
	public void getNetPosition_MissingSessionDetails() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		Integer userWithoutASession = 20972;

		GetNetPositionReq request = new GetNetPositionReq.Builder()
				.defaults()
				.userId(userWithoutASession)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, NetPositionEndpoints.getNetPositionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Session not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getNetPosition. Missing user_id parameter.")
	public void getNetPosition_Missing_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetNetPositionReq request = new GetNetPositionReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, NetPositionEndpoints.getNetPositionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getNetPosition. Wrong method.")
	public void getNetPositon_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetNetPositionReq request = new GetNetPositionReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, NetPositionEndpoints.getNetPositionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
