package main

import (
    "testing"
)

func TestService(t *testing.T){
    main()
}

